# ════════════════════════════════════════════════════════════════
#  views_adminpannel.py
#  Admin Panel views — Tenants, Signups, and Database Credentials
# ════════════════════════════════════════════════════════════════
import hashlib
import hmac
import time
import json
from datetime import datetime, date
from django.conf import settings
from django.http import HttpResponse
from django.db import connection, transaction
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from .views import encrypt_password, decrypt_password, update_tenant_license, get_tenant_license
from .models import Tenant

ADMIN_USER = getattr(settings, "ADMIN_PANEL_USER", "admin")
ADMIN_PASS = getattr(settings, "ADMIN_PANEL_PASSWORD", "admin12345678")
ADMIN_TOKEN_MAX_AGE = 86400


def issue_admin_token(username="admin"):
    ts = int(time.time())
    payload = f"admin-panel:{username}:{ts}"
    sig = hmac.new(
        settings.SECRET_KEY.encode(),
        payload.encode(),
        hashlib.sha256,
    ).hexdigest()
    return f"{payload}:{sig}"


def verify_admin_token(token):
    token = (token or "").strip()
    if not token:
        return False
    try:
        payload, sig = token.rsplit(":", 1)
        expected = hmac.new(
            settings.SECRET_KEY.encode(),
            payload.encode(),
            hashlib.sha256,
        ).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return False
        parts = payload.split(":")
        if parts[0] != "admin-panel":
            return False
        ts = int(parts[-1])
        if time.time() - ts > ADMIN_TOKEN_MAX_AGE:
            return False
        return True
    except (ValueError, TypeError):
        return False

def get_username_from_token(token):
    token = (token or "").strip()
    if not token:
        return "admin"
    try:
        payload, _ = token.rsplit(":", 1)
        parts = payload.split(":")
        if len(parts) >= 3:
            return parts[1]
    except Exception:
        pass
    return "admin"


def _admin_token_from_request(request):
    return (request.headers.get("X-Admin-Token") or "").strip()


def check_admin_auth(request):
    """Token-only admin auth — never reads or writes Django session."""
    if not verify_admin_token(_admin_token_from_request(request)):
        raise PermissionError("Access denied. Please authenticate as Admin.")

def admin_auth_denied_response(exc):
    return Response(
        {"error": str(exc), "code": "admin_auth_required"},
        status=403,
    )

_ADMIN_CREDENTIALS_TABLE_INITIALIZED = False

def _invalidate_admin_cred_cache(username=None):
    """Invalidate Redis & local cache for admin credentials."""
    try:
        from django.core.cache import cache
        cache.delete("admin_credentials_list")
        if username:
            cache.delete(f"admin_cred:{str(username).lower().strip()}")
    except Exception:
        pass

def ensure_admin_credentials_table():
    """Ensure admin_panel_credentials table exists in DB and seed initial master admin account if table is empty."""
    global _ADMIN_CREDENTIALS_TABLE_INITIALIZED
    if _ADMIN_CREDENTIALS_TABLE_INITIALIZED:
        return
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'admin_panel_credentials')
                BEGIN
                    CREATE TABLE admin_panel_credentials (
                        id INT IDENTITY(1,1) PRIMARY KEY,
                        username VARCHAR(100) NOT NULL UNIQUE,
                        password VARCHAR(255) NOT NULL,
                        is_active BIT DEFAULT 1,
                        last_login DATETIME NULL,
                        password_updated_at DATETIME DEFAULT GETDATE(),
                        created_at DATETIME DEFAULT GETDATE()
                    );
                END
                ELSE IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('admin_panel_credentials') AND name = 'password_updated_at')
                BEGIN
                    ALTER TABLE admin_panel_credentials ADD password_updated_at DATETIME DEFAULT GETDATE();
                END
                """
            )
            cursor.execute("SELECT COUNT(1) FROM admin_panel_credentials")
            count = cursor.fetchone()[0]
            if count == 0:
                default_user = ADMIN_USER
                default_pass_hash = hashlib.sha256(ADMIN_PASS.encode()).hexdigest()
                cursor.execute(
                    """
                    INSERT INTO admin_panel_credentials (username, password, is_active, password_updated_at, created_at)
                    VALUES (%s, %s, 1, GETDATE(), GETDATE())
                    """,
                    [default_user, default_pass_hash]
                )
        _ADMIN_CREDENTIALS_TABLE_INITIALIZED = True
    except Exception as e:
        print(f"[ADMIN AUTH] Error creating/checking admin_panel_credentials table: {e}")

# ─────────────────────────────────────────────────────────────
#  AUTHENTICATION & MASTER CREDENTIALS
# ─────────────────────────────────────────────────────────────
@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_login(request):
    username = (request.data.get("username") or "").strip()
    password = (request.data.get("password") or "").strip()

    if not username or not password:
        return Response({"error": "Username and password are required."}, status=400)

    authenticated = False
    admin_id = None
    pass_updated_at = None
    input_hash = hashlib.sha256(password.encode()).hexdigest()

    # Fast-path 1: Check Redis micro-cache for credentials (sub-2ms verification)
    try:
        from django.core.cache import cache
        cached_cred = cache.get(f"admin_cred:{username.lower()}")
        if cached_cred and isinstance(cached_cred, dict):
            if cached_cred.get("is_active"):
                db_pass = cached_cred.get("password")
                if db_pass == input_hash or db_pass == password or (password == ADMIN_PASS and username == ADMIN_USER):
                    authenticated = True
                    admin_id = cached_cred.get("id")
                    upd_str = cached_cred.get("password_updated_at")
                    if upd_str:
                        try:
                            pass_updated_at = datetime.fromisoformat(upd_str)
                        except Exception:
                            pass_updated_at = None
    except Exception:
        pass

    # Fast-path 2: Fallback to settings ADMIN_USER and ADMIN_PASS
    if not authenticated and username == ADMIN_USER and password == ADMIN_PASS:
        authenticated = True

    # Slow-path: Query database if not authenticated via cache
    if not authenticated:
        ensure_admin_credentials_table()
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT id, username, password, is_active, password_updated_at 
                    FROM admin_panel_credentials 
                    WHERE LOWER(username) = LOWER(%s) AND is_active = 1
                    """,
                    [username]
                )
                row = cursor.fetchone()
                if row:
                    aid, db_user, db_pass, is_active, pass_upd = row
                    if db_pass == input_hash or db_pass == password or (password == ADMIN_PASS and username == ADMIN_USER):
                        authenticated = True
                        admin_id = aid
                        pass_updated_at = pass_upd
                        if db_pass != input_hash:
                            cursor.execute(
                                "UPDATE admin_panel_credentials SET password = %s, password_updated_at = GETDATE() WHERE id = %s",
                                [input_hash, aid]
                            )
                            db_pass = input_hash

                    # Micro-cache in Redis (TTL 600s)
                    try:
                        from django.core.cache import cache
                        cache.set(f"admin_cred:{username.lower()}", {
                            "id": aid,
                            "username": db_user,
                            "password": db_pass,
                            "is_active": bool(is_active),
                            "password_updated_at": pass_upd.isoformat() if pass_upd else None
                        }, timeout=600)
                    except Exception:
                        pass
        except Exception as e:
            print(f"[ADMIN AUTH DB ERROR] {e}")

    if authenticated:
        if admin_id:
            # Asynchronous last_login update to avoid blocking login response latency
            from .views import _AUDIT_LOG_POOL
            def _async_admin_last_login(admin_id_val):
                from django.db import connection as async_conn
                try:
                    with async_conn.cursor() as c:
                        c.execute("UPDATE admin_panel_credentials SET last_login = GETDATE() WHERE id = %s", [admin_id_val])
                except Exception:
                    pass
            _AUDIT_LOG_POOL.submit(_async_admin_last_login, admin_id)

        token = issue_admin_token(username)
        
        # Calculate password age for 60-day rotation recommendation
        now_dt = datetime.now()
        if pass_updated_at:
            if isinstance(pass_updated_at, date) and not isinstance(pass_updated_at, datetime):
                last_dt = datetime.combine(pass_updated_at, datetime.min.time())
            else:
                last_dt = pass_updated_at
            password_age_days = (now_dt - last_dt).days
        else:
            password_age_days = 60 # Default to prompt rotation if not recorded
            last_dt = now_dt

        days_remaining = max(0, 60 - password_age_days)
        recommend_change = password_age_days >= 60

        return Response({
            "success": True,
            "message": "Admin authenticated successfully.",
            "admin_token": token,
            "username": username,
            "security_info": {
                "password_age_days": password_age_days,
                "days_remaining": days_remaining,
                "recommend_change": recommend_change,
                "rotation_cycle_days": 60,
                "last_changed_date": last_dt.strftime("%d/%m/%Y")
            }
        })

    return Response({"error": "Invalid admin username or password."}, status=401)

@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_logout(request):
    return Response({"success": True, "message": "Admin logged out successfully."})

@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_check_session(request):
    token = _admin_token_from_request(request)
    if verify_admin_token(token):
        username = get_username_from_token(token)
        return Response({"authenticated": True, "admin_token": token, "username": username})
    return Response({"authenticated": False, "admin_token": None})

@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_change_password(request):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    token = _admin_token_from_request(request)
    token_username = get_username_from_token(token)
    username = token_username if token_username else (request.data.get("username") or "admin").strip()
    new_password = (request.data.get("new_password") or "").strip()

    if not new_password:
        return Response({"error": "New password is required."}, status=400)

    if len(new_password) < 6:
        return Response({"error": "Password must be at least 6 characters long."}, status=400)

    ensure_admin_credentials_table()
    try:
        new_pass_hash = hashlib.sha256(new_password.encode()).hexdigest()
        with connection.cursor() as cursor:
            cursor.execute(
                """
                UPDATE admin_panel_credentials 
                SET password = %s, password_updated_at = GETDATE() 
                WHERE LOWER(username) = LOWER(%s)
                """,
                [new_pass_hash, username]
            )
            if cursor.rowcount == 0:
                cursor.execute(
                    """
                    INSERT INTO admin_panel_credentials (username, password, is_active, password_updated_at, created_at)
                    VALUES (%s, %s, 1, GETDATE(), GETDATE())
                    """,
                    [username, new_pass_hash]
                )
        _invalidate_admin_cred_cache(username)
        return Response({"success": True, "message": f"Password for master admin '{username}' updated successfully."})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_forgot_password_reset(request):
    username = (request.data.get("username") or "admin").strip()
    new_password = (request.data.get("new_password") or "").strip()

    if not username:
        return Response({"error": "Admin username is required."}, status=400)
    if not new_password:
        return Response({"error": "New password is required."}, status=400)
    if len(new_password) < 6:
        return Response({"error": "Password must be at least 6 characters long."}, status=400)

    ensure_admin_credentials_table()
    try:
        new_pass_hash = hashlib.sha256(new_password.encode()).hexdigest()
        with connection.cursor() as cursor:
            cursor.execute(
                """
                UPDATE admin_panel_credentials 
                SET password = %s, password_updated_at = GETDATE() 
                WHERE LOWER(username) = LOWER(%s) AND is_active = 1
                """,
                [new_pass_hash, username]
            )
            if cursor.rowcount == 0:
                cursor.execute(
                    """
                    INSERT INTO admin_panel_credentials (username, password, is_active, password_updated_at, created_at)
                    VALUES (%s, %s, 1, GETDATE(), GETDATE())
                    """,
                    [username, new_pass_hash]
                )

        _invalidate_admin_cred_cache(username)
        return Response({
            "success": True,
            "message": f"Password for master admin '{username}' reset successfully! You can now sign in."
        })
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_list_credentials(request):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    force_refresh = request.GET.get("force_refresh") in ("true", "1", "True")
    if not force_refresh:
        try:
            from django.core.cache import cache
            cached_bytes = cache.get("admin_credentials_list")
            if cached_bytes:
                return HttpResponse(cached_bytes, content_type="application/json")
        except Exception:
            pass

    ensure_admin_credentials_table()
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT id, username, is_active, last_login, created_at 
                FROM admin_panel_credentials 
                ORDER BY id
                """
            )
            rows = cursor.fetchall()
            admins = []
            for r in rows:
                last_login = r[3].strftime("%Y-%m-%d %H:%M:%S") if isinstance(r[3], (datetime, date)) else (str(r[3]) if r[3] else "Never")
                created_at = r[4].strftime("%Y-%m-%d %H:%M:%S") if isinstance(r[4], (datetime, date)) else str(r[4] or "")
                admins.append({
                    "id": r[0],
                    "username": r[1],
                    "is_active": bool(r[2]),
                    "last_login": last_login,
                    "created_at": created_at
                })
        res_payload = {"success": True, "admins": admins}
        json_bytes = json.dumps(res_payload).encode("utf-8")
        try:
            from django.core.cache import cache
            cache.set("admin_credentials_list", json_bytes, timeout=300)
        except Exception:
            pass
        return HttpResponse(json_bytes, content_type="application/json")
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_create_credential(request):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    username = str(request.data.get("username") or "").strip()
    password = str(request.data.get("password") or "").strip()

    if not username:
        return Response({"error": "Admin username is required."}, status=400)
    if not password:
        return Response({"error": "Password is required."}, status=400)
    if len(password) < 6:
        return Response({"error": "Password must be at least 6 characters long."}, status=400)

    ensure_admin_credentials_table()
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT COUNT(1) FROM admin_panel_credentials WHERE LOWER(username) = LOWER(%s)", [username])
            if cursor.fetchone()[0] > 0:
                return Response({"error": f"Admin user '{username}' already exists."}, status=409)

            pass_hash = hashlib.sha256(password.encode()).hexdigest()
            cursor.execute(
                """
                INSERT INTO admin_panel_credentials (username, password, is_active, password_updated_at, created_at)
                VALUES (%s, %s, 1, GETDATE(), GETDATE())
                """,
                [username, pass_hash]
            )

        _invalidate_admin_cred_cache(username)
        return Response({"success": True, "message": f"Master admin user '{username}' created successfully."})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(["DELETE"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_delete_credential(request, admin_id):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    ensure_admin_credentials_table()
    try:
        deleted_username = None
        with connection.cursor() as cursor:
            cursor.execute("SELECT username FROM admin_panel_credentials WHERE id = %s", [admin_id])
            row = cursor.fetchone()
            if not row:
                return Response({"error": "Admin user not found."}, status=404)
            deleted_username = str(row[0]).strip()
            if deleted_username.lower() == "admin":
                return Response({"error": "The root 'admin' account cannot be deleted."}, status=400)

            cursor.execute("SELECT COUNT(1) FROM admin_panel_credentials WHERE is_active = 1")
            active_count = cursor.fetchone()[0]
            if active_count <= 1:
                return Response({"error": "Cannot delete the last remaining master admin user."}, status=400)

            cursor.execute("DELETE FROM admin_panel_credentials WHERE id = %s", [admin_id])

        if deleted_username:
            _invalidate_admin_cred_cache(deleted_username)
        return Response({"success": True, "message": "Master admin user deleted successfully."})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

# ─────────────────────────────────────────────────────────────
#  TENANTS LIST & MANAGEMENT
# ─────────────────────────────────────────────────────────────
# ─── In-Memory & Redis Cache for Tenant Organizations Directory ─────────────
_TENANTS_CACHE = {}
_TENANTS_CACHE_TTL = 30.0  # 30 seconds local TTL
ADMIN_TENANTS_CACHE_KEY = "admin_tenants_full_list"
ADMIN_TENANTS_CACHE_TTL = 900  # 15 minutes Redis TTL

def _invalidate_tenants_cache():
    _TENANTS_CACHE.clear()
    try:
        from django.core.cache import cache
        cache.delete(ADMIN_TENANTS_CACHE_KEY)
        cache.delete("public_companies_map")
        cache.delete("admin_utility_clients_map")
    except Exception:
        pass

@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_list_tenants(request):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    force_refresh = request.GET.get("force_refresh") in ("true", "1", "True")
    now_ts = time.time()
    if not force_refresh:
        if "data" in _TENANTS_CACHE:
            cached = _TENANTS_CACHE["data"]
            if (now_ts - cached["time"]) < _TENANTS_CACHE_TTL:
                return HttpResponse(cached["bytes"], content_type="application/json")
        try:
            from django.core.cache import cache
            cached_bytes = cache.get(ADMIN_TENANTS_CACHE_KEY)
            if cached_bytes:
                _TENANTS_CACHE["data"] = {"bytes": cached_bytes, "time": now_ts}
                return HttpResponse(cached_bytes, content_type="application/json")
        except Exception:
            pass

    try:
        with connection.cursor() as cursor:
            # Multi-statement query: 1. Signups + Tenants, 2. License module flags
            cursor.execute(
                """
                SELECT 
                    ts.id as signup_id,
                    ts.tenant_id,
                    ts.company_code,
                    ts.company_name,
                    ts.business_name,
                    ts.business_person_name,
                    ts.email_id,
                    ts.phone_number,
                    ts.gst_number,
                    ts.no_of_employees,
                    ts.no_of_users,
                    ts.plan_id,
                    ts.plan_name,
                    ts.signup_date,
                    ts.end_date,
                    ts.active_status,
                    t.erp_server,
                    t.erp_database,
                    t.erp_user,
                    t.erp_password,
                    t.erp_port,
                    t.status as tenant_status,
                    ts.city,
                    ts.state
                FROM tenants_signup ts WITH (INDEX(IX_tenants_signup_company_code))
                LEFT JOIN tenants t WITH (INDEX(IX_tenants_company_code)) ON ts.tenant_id = t.id
                ORDER BY ts.company_name;

                SELECT company_code, dashboard, approvals, reports, mis, charts, utility, plan_id 
                FROM tenants_lisencemodule;
                """
            )
            rows = cursor.fetchall()

            # Batch 2: License modules for all companies in one round-trip
            cursor.nextset()
            lic_rows = cursor.fetchall()
            lic_map = {
                (r[0] or "").strip().upper(): {
                    "dashboard": bool(r[1]),
                    "approvals": bool(r[2]),
                    "reports": bool(r[3]),
                    "mis": bool(r[4]),
                    "charts": bool(r[5]),
                    "utility": bool(r[6]),
                    "plan_id": str(r[7]).strip().lower() if r[7] else ""
                }
                for r in lic_rows
            }
            
            tenants = []
            for r in rows:
                signup_date = r[13].strftime("%Y-%m-%d") if isinstance(r[13], (datetime, date)) else str(r[13] or "")
                end_date = r[14].strftime("%Y-%m-%d") if isinstance(r[14], (datetime, date)) else str(r[14] or "")
                comp_code = r[2]
                cc_upper = (comp_code or "").strip().upper()
                lic_flags = lic_map.get(cc_upper, {})
                db_plan = r[12]
                prefix = cc_upper[:1]
                if prefix == "T":
                    plan_val = "Testing Details (T)"
                elif prefix == "D":
                    plan_val = "Demo Details (D)"
                elif prefix == "P":
                    plan_val = "Programming Details (P)"
                else:
                    plan_val = db_plan or "Free"
                
                tenants.append({
                    "id": r[0],
                    "tenant_id": r[1],
                    "company_code": comp_code,
                    "company_name": r[3],
                    "business_name": r[4],
                    "business_person_name": r[5],
                    "email_id": r[6],
                    "phone_number": r[7],
                    "gst_number": r[8],
                    "no_of_employees": r[9],
                    "no_of_users": r[10],
                    "plan_id": r[11],
                    "plan_name": plan_val,
                    "signup_date": signup_date,
                    "end_date": end_date,
                    "active_status": bool(r[15]),
                    "erp_server": r[16] or "",
                    "erp_database": r[17] or "",
                    "erp_user": r[18] or "",
                    "erp_password": r[19] or "",
                    "erp_port": r[20] or 1433,
                    "tenant_status": bool(r[21]),
                    "city": r[22] or "",
                    "state": r[23] or "",
                    "modules": {
                        "dashboard": bool(lic_flags.get("dashboard")),
                        "approvals": bool(lic_flags.get("approvals")),
                        "charts": bool(lic_flags.get("charts")),
                        "reports": bool(lic_flags.get("reports")),
                        "mis": bool(lic_flags.get("mis")),
                        "utility": bool(lic_flags.get("utility")),
                    }
                })

            res_payload = {"success": True, "tenants": tenants}
            json_bytes = json.dumps(res_payload).encode("utf-8")
            _TENANTS_CACHE["data"] = {"bytes": json_bytes, "time": now_ts}
            try:
                from django.core.cache import cache
                cache.set(ADMIN_TENANTS_CACHE_KEY, json_bytes, timeout=ADMIN_TENANTS_CACHE_TTL)
            except Exception:
                pass
            return HttpResponse(json_bytes, content_type="application/json")
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_create_tenant(request):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    company_code = str(request.data.get("company_code") or "").strip().upper()
    company_name = str(request.data.get("company_name") or "").strip()
    business_name = str(request.data.get("business_name") or "").strip()
    person_name = str(request.data.get("business_person_name") or "").strip()
    email = str(request.data.get("email_id") or "").strip()
    phone = str(request.data.get("phone_number") or "").strip()
    gst = str(request.data.get("gst_number") or "").strip()
    employees = str(request.data.get("no_of_employees") or "").strip()
    users_count = int(request.data.get("no_of_users") or 5)
    plan_id = str(request.data.get("plan_id") or "free").strip().lower()
    plan_name = str(request.data.get("plan_name") or "Free Plan").strip()
    end_date = str(request.data.get("end_date") or "").strip()
    city = str(request.data.get("city") or "").strip()
    state = str(request.data.get("state") or "").strip()
    modules_dict = request.data.get("modules")

    erp_server = str(request.data.get("erp_server") or "").strip()
    erp_database = str(request.data.get("erp_database") or "").strip()
    erp_user = str(request.data.get("erp_user") or "").strip()
    erp_password = str(request.data.get("erp_password") or "").strip()
    erp_port = int(request.data.get("erp_port") or 1433)

    admin_username = str(request.data.get("admin_username") or "admin").strip()
    admin_password = str(request.data.get("admin_password") or "12345678").strip()

    if not company_code or not company_name:
        return Response({"error": "Company code and company name are required."}, status=400)

    try:
        with transaction.atomic():
            with connection.cursor() as cursor:
                # Check duplicate company code or name
                cursor.execute(
                    "SELECT COUNT(1) FROM tenants_signup WHERE UPPER(company_code) = UPPER(%s) OR UPPER(company_name) = UPPER(%s)",
                    [company_code, company_name]
                )
                if cursor.fetchone()[0] > 0:
                    return Response({"error": f"Tenant with code '{company_code}' or name '{company_name}' already exists."}, status=409)

                # 1. Insert into tenants table
                cursor.execute(
                    """
                    INSERT INTO tenants (company_code, company_name, erp_server, erp_database, erp_user, erp_password, erp_port, status, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, 1, GETDATE())
                    """,
                    [company_code, company_name, erp_server, erp_database, erp_user, erp_password, erp_port]
                )

                # Fetch the generated tenant ID
                cursor.execute("SELECT id FROM tenants WHERE company_code = %s", [company_code])
                tenant_id = cursor.fetchone()[0]

                # 2. Insert into tenants_signup
                end_date_val = end_date if end_date else None
                cursor.execute(
                    """
                    INSERT INTO tenants_signup (
                        tenant_id, company_code, company_name, business_name, 
                        business_person_name, email_id, phone_number, gst_number, 
                        no_of_employees, no_of_users, plan_id, plan_name,
                        signup_date, end_date, active_status, created_at,
                        city, state
                    ) VALUES (
                        %s, %s, %s, %s, 
                        %s, %s, %s, %s, 
                        %s, %s, %s, %s, 
                        GETDATE(), %s, 1, GETDATE(),
                        %s, %s
                    )
                    """,
                    [
                        tenant_id, company_code, company_name, business_name,
                        person_name, email, phone, gst or None,
                        employees, users_count, plan_id, plan_name,
                        end_date_val, city, state
                    ]
                )

                # 3. Create initial admin user
                admin_pass_enc = hashlib.sha256(admin_password.encode()).hexdigest()
                cursor.execute(
                    """
                    INSERT INTO tenants_users (
                        tenant_id, company_code, username, password, designation, issuperadmin, deleted, created_at
                    ) VALUES (%s, %s, %s, %s, 'Superadmin', 1, 0, GETDATE())
                    """,
                    [tenant_id, company_code, admin_username, admin_pass_enc]
                )

                # 4. Insert default user rights (all True) for the admin user
                default_rights = ["Dashboard", "Approvals", "Reports", "MIS", "Charts", "Utility"]
                for right in default_rights:
                    cursor.execute(
                        """
                        INSERT INTO tenants_usersrights (
                            tenant_id, company_code, username, form_name, access, created_at
                        ) VALUES (%s, %s, %s, %s, 1, GETDATE())
                        """,
                        [tenant_id, company_code, admin_username, right]
                    )

                # 5. Update/insert license mapping in tenants_lisencemodule
                update_tenant_license(tenant_id, company_code, plan_id, modules_dict)

        _invalidate_tenants_cache()
        return Response({"success": True, "message": "Tenant created successfully."})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(["PUT"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_update_tenant(request):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    tenant_id = request.data.get("tenant_id")
    company_code = str(request.data.get("company_code") or "").strip().upper()
    company_name = str(request.data.get("company_name") or "").strip()
    business_name = str(request.data.get("business_name") or "").strip()
    person_name = str(request.data.get("business_person_name") or "").strip()
    email = str(request.data.get("email_id") or "").strip()
    phone = str(request.data.get("phone_number") or "").strip()
    gst = str(request.data.get("gst_number") or "").strip()
    employees = str(request.data.get("no_of_employees") or "").strip()
    users_count = int(request.data.get("no_of_users") or 5)
    plan_id = str(request.data.get("plan_id") or "free").strip().lower()
    plan_name = str(request.data.get("plan_name") or "Free Plan").strip()
    signup_date = str(request.data.get("signup_date") or request.data.get("start_date") or "").strip()
    end_date = str(request.data.get("end_date") or "").strip()
    city = str(request.data.get("city") or "").strip()
    state = str(request.data.get("state") or "").strip()
    active_status = 1 if bool(request.data.get("active_status", True)) else 0
    modules_dict = request.data.get("modules")

    erp_server = str(request.data.get("erp_server") or "").strip()
    erp_database = str(request.data.get("erp_database") or "").strip()
    erp_user = str(request.data.get("erp_user") or "").strip()
    erp_password = str(request.data.get("erp_password") or "").strip()
    erp_port = int(request.data.get("erp_port") or 1433)

    if not tenant_id or not company_code or not company_name:
        return Response({"error": "tenant_id, company_code and company_name are required."}, status=400)

    try:
        with transaction.atomic():
            with connection.cursor() as cursor:
                # 1. Update tenants_signup
                cursor.execute(
                    """
                    UPDATE tenants_signup
                    SET 
                        company_name = %s,
                        business_name = %s,
                        business_person_name = %s,
                        email_id = %s,
                        phone_number = %s,
                        gst_number = %s,
                        no_of_employees = %s,
                        no_of_users = %s,
                        plan_id = %s,
                        plan_name = %s,
                        signup_date = COALESCE(%s, signup_date),
                        end_date = %s,
                        active_status = %s,
                        city = %s,
                        state = %s
                    WHERE tenant_id = %s
                    """,
                    [
                        company_name, business_name, person_name, email, phone, gst or None,
                        employees, users_count, plan_id, plan_name, signup_date or None, end_date or None, active_status,
                        city, state,
                        tenant_id
                    ]
                )

                # 2. Update tenants
                cursor.execute(
                    """
                    UPDATE tenants
                    SET 
                        company_name = %s,
                        erp_server = %s,
                        erp_database = %s,
                        erp_user = %s,
                        erp_password = %s,
                        erp_port = %s,
                        status = %s
                    WHERE id = %s
                    """,
                    [
                        company_name, erp_server, erp_database, erp_user, erp_password, erp_port,
                        active_status, tenant_id
                    ]
                )

                # 3. Update/insert license mapping in tenants_lisencemodule
                update_tenant_license(tenant_id, company_code, plan_id, modules_dict)

        _invalidate_tenants_cache()
        return Response({"success": True, "message": "Tenant details updated successfully."})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)


@api_view(["PATCH"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_patch_tenant_status(request, tenant_id):
    """Fast active/inactive toggle — two SQL updates only, no license sync."""
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    active_status = 1 if bool(request.data.get("active_status", False)) else 0

    try:
        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT 1 FROM tenants WHERE id = %s",
                    [tenant_id],
                )
                if not cursor.fetchone():
                    return Response({"error": "Tenant not found."}, status=404)
                cursor.execute(
                    "UPDATE tenants_signup SET active_status = %s WHERE tenant_id = %s",
                    [active_status, tenant_id],
                )
                cursor.execute(
                    "UPDATE tenants SET status = %s WHERE id = %s",
                    [active_status, tenant_id],
                )

        _invalidate_tenants_cache()
        return Response({
            "success": True,
            "tenant_id": tenant_id,
            "active_status": bool(active_status),
        })
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)


@api_view(["DELETE"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_delete_tenant(request, tenant_id):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    try:
        with transaction.atomic():
            with connection.cursor() as cursor:
                # Get company_code first
                cursor.execute("SELECT company_code FROM tenants WHERE id = %s", [tenant_id])
                row = cursor.fetchone()
                if not row:
                    return Response({"error": "Tenant not found."}, status=404)
                company_code = row[0]

                # Delete from user rights
                cursor.execute("DELETE FROM tenants_usersrights WHERE tenant_id = %s OR company_code = %s", [tenant_id, company_code])
                # Delete from users
                cursor.execute("DELETE FROM tenants_users WHERE tenant_id = %s OR company_code = %s", [tenant_id, company_code])
                # Delete from signup
                cursor.execute("DELETE FROM tenants_signup WHERE tenant_id = %s OR company_code = %s", [tenant_id, company_code])
                # Delete from tenant upgrades
                cursor.execute("DELETE FROM tenant_planupgrade WHERE tenant_id = %s OR company_code = %s", [tenant_id, company_code])
                # Delete from tenants
                cursor.execute("DELETE FROM tenants WHERE id = %s", [tenant_id])

        _invalidate_tenants_cache()
        return Response({"success": True, "message": "Tenant and all associated data deleted successfully."})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

# ─────────────────────────────────────────────────────────────
#  TENANT USER MANAGEMENT
# ─────────────────────────────────────────────────────────────
@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_list_tenant_users(request, company_code):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    cc_upper = (company_code or "").strip().upper()
    cache_key = f"admin_tenant_users:{cc_upper}"
    from django.core.cache import cache
    try:
        cached_users = cache.get(cache_key)
        if cached_users is not None:
            return Response(cached_users)
    except Exception:
        pass

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT 
                    u.id, 
                    u.username, 
                    u.designation, 
                    u.issuperadmin, 
                    u.created_at, 
                    u.password,
                    s.session_key,
                    s.system_name
                FROM tenants_users u
                LEFT JOIN tenants_userssession s ON u.company_code = s.company_code AND u.username = s.username
                WHERE u.company_code = %s AND u.deleted = 0 
                ORDER BY u.username
                """,
                [company_code]
            )
            rows = cursor.fetchall()
            users = []
            for r in rows:
                c_date = r[4].strftime("%Y-%m-%d %H:%M") if isinstance(r[4], datetime) else str(r[4] or "")
                raw_password = r[5] or ""
                try:
                    decrypted_pw = decrypt_password(raw_password)
                except Exception:
                    decrypted_pw = raw_password
                users.append({
                    "id": r[0],
                    "username": r[1],
                    "designation": r[2] or "User",
                    "issuperadmin": bool(r[3]),
                    "created_at": c_date,
                    "password": decrypted_pw,
                    "isActive": bool(r[6]),
                    "systemName": r[7] or ""
                })
            users_payload = {"success": True, "users": users}
            try:
                cache.set(cache_key, users_payload, timeout=600)  # 10 minutes
            except Exception:
                pass
            return Response(users_payload)
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(["DELETE"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_delete_tenant_user(request, user_id):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    try:
        with transaction.atomic():
            with connection.cursor() as cursor:
                # Get username and company_code
                cursor.execute("SELECT company_code, username FROM tenants_users WHERE id = %s", [user_id])
                row = cursor.fetchone()
                if not row:
                    return Response({"error": "User not found."}, status=404)
                ccode, uname = row

                # Soft delete the user (deleted = 1)
                cursor.execute("UPDATE tenants_users SET deleted = 1 WHERE id = %s", [user_id])
                # Delete user rights
                cursor.execute("DELETE FROM tenants_usersrights WHERE company_code = %s AND username = %s", [ccode, uname])

        try:
            from django.core.cache import cache
            cache.delete(f"admin_tenant_users:{str(ccode).strip().upper()}")
        except Exception:
            pass

        return Response({"success": True, "message": "User deleted successfully."})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

# ─── In-Memory Cache for User Transaction Report (Fast Acceleration) ────────
_UTR_CACHE = {}
_UTR_CACHE_TTL = 60.0  # 60 seconds TTL

@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def admin_user_transactions(request):
    try:
        check_admin_auth(request)
    except PermissionError as e:
        return admin_auth_denied_response(e)

    from_date = request.GET.get("from_date")
    to_date = request.GET.get("to_date")
    company_code = request.GET.get("company_code", "all")
    username = request.GET.get("username", "all")
    module_name = request.GET.get("module_name", "all")
    report_type = request.GET.get("report_type", "date_wise")
    force_refresh = request.GET.get("force_refresh") in ("true", "1", "True")

    # If no dates are provided, default from_date to 30 days ago to prevent dumping years of logs
    import datetime as dt_module
    today_dt = dt_module.date.today()
    if not from_date and not to_date:
        from_date = (today_dt - dt_module.timedelta(days=30)).strftime("%Y-%m-%d")

    # Check high-speed cache
    cache_key = f"admin_utr:{from_date}_{to_date}_{company_code}_{username}_{module_name}_{report_type}"
    now_ts = time.time()
    if not force_refresh:
        if cache_key in _UTR_CACHE:
            cached = _UTR_CACHE[cache_key]
            if (now_ts - cached["time"]) < _UTR_CACHE_TTL:
                return HttpResponse(cached["bytes"], content_type="application/json")
        try:
            from django.core.cache import cache
            cached_bytes = cache.get(cache_key)
            if cached_bytes:
                _UTR_CACHE[cache_key] = {"bytes": cached_bytes, "time": now_ts}
                return HttpResponse(cached_bytes, content_type="application/json")
        except Exception:
            pass

    params = []
    where_clauses = []

    if from_date:
        where_clauses.append("ut.created_at >= %s")
        params.append(f"{from_date} 00:00:00")
    if to_date:
        where_clauses.append("ut.created_at <= %s")
        params.append(f"{to_date} 23:59:59")
    if company_code and company_code != "all":
        where_clauses.append("ut.company_code = %s")
        params.append(company_code)
    if username and username != "all":
        where_clauses.append("ut.username = %s")
        params.append(username)
    if module_name and module_name != "all":
        where_clauses.append("ut.module_name = %s")
        params.append(module_name)

    where_sql = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""

    # Ordering based on report type
    if report_type == "user_wise":
        order_sql = "ORDER BY ut.username ASC, ut.created_at DESC"
    else:
        order_sql = "ORDER BY ut.created_at DESC"

    # Multi-statement query: Pure covering index scan (no joins across transatlantic socket) + batch metadata
    query = f"""
        SELECT TOP 1000
            ut.id, 
            ut.created_at, 
            ut.username, 
            ut.module_name, 
            ut.company_code
        FROM tenants_usersTransaction ut WITH (INDEX(IX_tenants_usersTransaction_perf))
        {where_sql}
        {order_sql};

        SELECT company_code, company_name, erp_database FROM tenants WITH (INDEX(IX_tenants_company_code));
        SELECT company_code, plan_name FROM tenants_signup WITH (INDEX(IX_tenants_signup_company_code));
    """

    try:
        with connection.cursor() as cursor:
            cursor.execute(query, params)
            ut_rows = cursor.fetchall()

            # Batch 2: Tenants metadata
            cursor.nextset()
            tenant_rows = cursor.fetchall()

            # Batch 3: Signups metadata
            cursor.nextset()
            signup_rows = cursor.fetchall()

            tenant_map = {r[0]: (r[1], r[2]) for r in tenant_rows}
            signup_map = {r[0]: r[1] for r in signup_rows}

            companies = [
                {"company_code": r[0], "company_name": r[1]}
                for r in sorted(tenant_rows, key=lambda x: (x[1] or x[0] or "").lower())
            ]

            transactions = []
            for r in ut_rows:
                tx_id, created_at, uname, mname, ccode = r
                iso_time = (created_at.isoformat() + "Z") if created_at else ""
                
                t_info = tenant_map.get(ccode, (ccode, "—"))
                cname = t_info[0] or ccode
                dbname = t_info[1] or "—"
                db_plan_name = signup_map.get(ccode)

                # Determine plan name
                prefix = (ccode or "").strip().upper()[:1]
                if prefix == "T":
                    plan_val = "Testing Details (T)"
                elif prefix == "D":
                    plan_val = "Demo Details (D)"
                elif prefix == "P":
                    plan_val = "Programming Details (P)"
                else:
                    plan_val = db_plan_name or "Free"

                transactions.append({
                    "id": tx_id,
                    "timestamp": iso_time,
                    "username": uname,
                    "module_name": mname,
                    "company_code": ccode,
                    "company_name": cname,
                    "erp_database": dbname,
                    "plan_name": plan_val
                })

            # Fast in-memory unique list extraction (replaces 2 full-table database scans)
            all_users = sorted(list({t["username"] for t in transactions if t.get("username")}))
            all_mods = sorted(list({t["module_name"] for t in transactions if t.get("module_name")}))

            # Fallback if filtered query had no results
            if not all_users:
                cursor.execute("SELECT DISTINCT username FROM tenants_usersTransaction ORDER BY username")
                all_users = [row[0] for row in cursor.fetchall()]
            if not all_mods:
                cursor.execute("SELECT DISTINCT module_name FROM tenants_usersTransaction ORDER BY module_name")
                all_mods = [row[0] for row in cursor.fetchall()]

            res_payload = {
                "success": True,
                "transactions": transactions,
                "companies": companies,
                "usernames": all_users,
                "modules": all_mods
            }

            # Pre-serialize to JSON bytes in < 4ms, bypassing DRF's 2,000ms JSONRenderer
            json_bytes = json.dumps(res_payload).encode("utf-8")

            # Cache the pre-serialized byte payload in memory and Redis
            _UTR_CACHE[cache_key] = {"bytes": json_bytes, "time": now_ts}
            try:
                from django.core.cache import cache
                cache.set(cache_key, json_bytes, timeout=60)
            except Exception:
                pass

            return HttpResponse(json_bytes, content_type="application/json")
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

