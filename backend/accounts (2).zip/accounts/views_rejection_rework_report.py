# ════════════════════════════════════════════
#  views_rejection_rework_report.py
#  Plant Performance — Rejection & Rework from inspection tables
#  (patterns aligned with views_qualityanalysis.py)
# ════════════════════════════════════════════

from datetime import datetime, date

from .views import table_exists
from .views_efficiency_report import (
    _parse_bool_param,
    _month_label_from_date,
    _months_in_range,
    _month_labels_for_payload,
    _efficiency_query_date_range,
)


def _is_vendor_job(dtype_val):
    d = str(dtype_val or "").lower().strip()
    return any(k in d for k in ("vendor", "sub contract", "subcontract", "outside", "job work"))


def _map_rej_type_ui(insp_source, is_vendor_job=False):
    if insp_source == "Supplier":
        return "Supplier Rej"
    if insp_source == "Final Insp":
        return "Final Insp Rej"
    if insp_source == "Job Order":
        return "Vendor Rej" if is_vendor_job else "In-house Rej"
    if insp_source == "Intermediate":
        return "In-house Rej"
    return "In-house Rej"


def _map_rework_group_ui(insp_source, is_vendor_job=False):
    if insp_source == "Final Insp":
        return "Final Insp"
    if insp_source == "Job Order":
        return "Vendor"
    if insp_source == "Intermediate":
        return "In-House"
    if insp_source == "Customer":
        return "Customer Rework"
    return "In-House"


def _part_rate_expr(part_col, process_col):
    return f"""(
        ISNULL((
            SELECT TOP 1
                CASE
                    WHEN WM.Rmuom = 'NOS' THEN ISNULL(RMR.BaseRate, 0)
                    WHEN WM.Rmuom = 'KGS' THEN CAST(ISNULL(WM.WtQty, 0) AS FLOAT) * ISNULL(RMR.BaseRate, 0)
                    WHEN WM.Rmuom = 'MTRS' THEN (CAST(ISNULL(WM.TotMmLength, 0) AS FLOAT) / 1000.0) * ISNULL(RMR.BaseRate, 0)
                    ELSE 0
                END
            FROM WithMatMas WM
            OUTER APPLY (
                SELECT TOP 1 CAST(CBD.BaseRate AS FLOAT) AS BaseRate
                FROM Commer_BaseRateDet CBD
                INNER JOIN Commer_Mas CM ON CBD.cmno = CM.cmno
                WHERE CBD.PartNo = WM.RmName AND ISNULL(CBD.deleted, 0) = 0 AND ISNULL(CM.deleted, 0) = 0 AND CM.btype = 'Raw Material'
                ORDER BY CBD.BReffdt DESC
            ) RMR
            WHERE WM.PartNo = {part_col} AND ISNULL(WM.deleted, 0) = 0
            ORDER BY WM.PartNo
        ), 0)
        +
        ISNULL((
            SELECT TOP 1
                CASE
                    WHEN ISNULL(TotalProcCount, 0) > 0 AND TotalProcCount = ValidProcRateCount AND ISNULL(ProcessRate, 0) > 0 THEN ProcessRate
                    ELSE ISNULL((SELECT TOP 1 CAST(CBD.BaseRate AS FLOAT) FROM Commer_BaseRateDet CBD WHERE CBD.PartNo = {part_col} AND ISNULL(CBD.deleted, 0) = 0 ORDER BY CBD.BReffdt DESC), 0)
                END
            FROM (
                SELECT
                    (SELECT COUNT(*) FROM ProcessSeqDet PSD WHERE PSD.partno = {part_col} AND ISNULL(PSD.deleted, 0) = 0 AND PSD.seq <= ISNULL(CurrSeq.seq, 999999)) AS TotalProcCount,
                    (SELECT COUNT(*) FROM ProcessSeqDet PSD CROSS APPLY (SELECT TOP 1 Rate FROM Commer_ProcDet WHERE PartNo = PSD.partno AND Process = PSD.process AND ISNULL(deleted, 0) = 0 AND ISNULL(Rate, 0) > 0) C WHERE PSD.partno = {part_col} AND ISNULL(PSD.deleted, 0) = 0 AND PSD.seq <= ISNULL(CurrSeq.seq, 999999)) AS ValidProcRateCount,
                    (SELECT SUM(CAST(ISNULL(C.Rate, 0) AS FLOAT)) FROM ProcessSeqDet PSD OUTER APPLY (SELECT TOP 1 Rate FROM Commer_ProcDet WHERE PartNo = PSD.partno AND Process = PSD.process AND ISNULL(deleted, 0) = 0 ORDER BY PartNo) C WHERE PSD.partno = {part_col} AND ISNULL(PSD.deleted, 0) = 0 AND PSD.seq <= ISNULL(CurrSeq.seq, 999999)) AS ProcessRate
                FROM (SELECT 1 AS D) DUMMY
                OUTER APPLY (SELECT TOP 1 seq FROM ProcessSeqDet WHERE partno = {part_col} AND process = {process_col} AND ISNULL(deleted, 0) = 0 ORDER BY seq DESC) CurrSeq
            ) T
        ), 0)
    )"""


def _cust_expr_injob(mas_alias="m", det_alias="d"):
    return f"""COALESCE(
        (SELECT TOP 1 CM.CName FROM CustMast CM WHERE CM.Id = {mas_alias}.cid AND ISNULL(CM.deleted, 0) = 0),
        (SELECT TOP 1 CAM.CorpName FROM CustAliasMast CAM WHERE CAM.Id = {mas_alias}.cid AND ISNULL(CAM.deleted, 0) = 0),
        (SELECT TOP 1 CM_WM.CName FROM WithMatMas WM_P INNER JOIN CustMast CM_WM ON WM_P.Cid = CM_WM.Id WHERE WM_P.PartNo = {det_alias}.partno AND ISNULL(WM_P.Deleted, 0) = 0 AND ISNULL(CM_WM.deleted, 0) = 0),
        (SELECT TOP 1 CAM_WM.CorpName FROM WithMatMas WM_P INNER JOIN CustAliasMast CAM_WM ON WM_P.Cid = CAM_WM.Id WHERE WM_P.PartNo = {det_alias}.partno AND ISNULL(WM_P.Deleted, 0) = 0 AND ISNULL(CAM_WM.deleted, 0) = 0),
        (SELECT TOP 1 CM_CJ.CName FROM CustJobRawMat CJ_P INNER JOIN CustMast CM_CJ ON CJ_P.cid = CM_CJ.Id WHERE CJ_P.partno = {det_alias}.partno AND ISNULL(CJ_P.deleted, 0) = 0 AND ISNULL(CM_CJ.deleted, 0) = 0),
        (SELECT TOP 1 CAM_CJ.CorpName FROM CustJobRawMat CJ_P INNER JOIN CustAliasMast CAM_CJ ON CJ_P.cid = CAM_CJ.Id WHERE CJ_P.partno = {det_alias}.partno AND ISNULL(CJ_P.deleted, 0) = 0 AND ISNULL(CAM_CJ.deleted, 0) = 0),
        (SELECT TOP 1 CM_PM.CName FROM ProductMast PM_P INNER JOIN CustMast CM_PM ON PM_P.Cid = CM_PM.Id WHERE PM_P.PartNo = {det_alias}.partno AND ISNULL(PM_P.Deleted, 0) = 0 AND ISNULL(CM_PM.deleted, 0) = 0),
        (SELECT TOP 1 CAM_PM.CorpName FROM ProductMast PM_P INNER JOIN CustAliasMast CAM_PM ON PM_P.Cid = CAM_PM.Id WHERE PM_P.PartNo = {det_alias}.partno AND ISNULL(PM_P.Deleted, 0) = 0 AND ISNULL(CAM_PM.deleted, 0) = 0),
        (SELECT TOP 1 CM_PRM.CName FROM ProdMast PRM_P INNER JOIN CustMast CM_PRM ON PRM_P.CId = CM_PRM.Id WHERE PRM_P.Partno = {det_alias}.partno AND ISNULL(PRM_P.Deleted, 0) = 0 AND ISNULL(CM_PRM.deleted, 0) = 0),
        (SELECT TOP 1 CAM_PRM.CorpName FROM ProdMast PRM_P INNER JOIN CustAliasMast CAM_PRM ON PRM_P.CId = CAM_PRM.Id WHERE PRM_P.Partno = {det_alias}.partno AND ISNULL(PRM_P.Deleted, 0) = 0 AND ISNULL(CAM_PRM.deleted, 0) = 0),
        N'—'
    )"""


def _cust_expr_part(partno_col):
    return f"""COALESCE(
        (SELECT TOP 1 CM_WM.CName FROM WithMatMas WM_P INNER JOIN CustMast CM_WM ON WM_P.Cid = CM_WM.Id WHERE WM_P.PartNo = {partno_col} AND ISNULL(WM_P.Deleted, 0) = 0 AND ISNULL(CM_WM.deleted, 0) = 0),
        (SELECT TOP 1 CAM_WM.CorpName FROM WithMatMas WM_P INNER JOIN CustAliasMast CAM_WM ON WM_P.Cid = CAM_WM.Id WHERE WM_P.PartNo = {partno_col} AND ISNULL(WM_P.Deleted, 0) = 0 AND ISNULL(CAM_WM.deleted, 0) = 0),
        (SELECT TOP 1 CM_CJ.CName FROM CustJobRawMat CJ_P INNER JOIN CustMast CM_CJ ON CJ_P.cid = CM_CJ.Id WHERE CJ_P.partno = {partno_col} AND ISNULL(CJ_P.deleted, 0) = 0 AND ISNULL(CM_CJ.deleted, 0) = 0),
        (SELECT TOP 1 CAM_CJ.CorpName FROM CustJobRawMat CJ_P INNER JOIN CustAliasMast CAM_CJ ON CJ_P.cid = CAM_CJ.Id WHERE CJ_P.partno = {partno_col} AND ISNULL(CJ_P.deleted, 0) = 0 AND ISNULL(CAM_CJ.deleted, 0) = 0),
        (SELECT TOP 1 CM_PM.CName FROM ProductMast PM_P INNER JOIN CustMast CM_PM ON PM_P.Cid = CM_PM.Id WHERE PM_P.PartNo = {partno_col} AND ISNULL(PM_P.Deleted, 0) = 0 AND ISNULL(CM_PM.deleted, 0) = 0),
        (SELECT TOP 1 CAM_PM.CorpName FROM ProductMast PM_P INNER JOIN CustAliasMast CAM_PM ON PM_P.Cid = CAM_PM.Id WHERE PM_P.PartNo = {partno_col} AND ISNULL(PM_P.Deleted, 0) = 0 AND ISNULL(CAM_PM.deleted, 0) = 0),
        (SELECT TOP 1 CM_PRM.CName FROM ProdMast PRM_P INNER JOIN CustMast CM_PRM ON PRM_P.CId = CM_PRM.Id WHERE PRM_P.Partno = {partno_col} AND ISNULL(PRM_P.Deleted, 0) = 0 AND ISNULL(CM_PRM.deleted, 0) = 0),
        (SELECT TOP 1 CAM_PRM.CorpName FROM ProdMast PRM_P INNER JOIN CustAliasMast CAM_PRM ON PRM_P.CId = CAM_PRM.Id WHERE PRM_P.Partno = {partno_col} AND ISNULL(PRM_P.Deleted, 0) = 0 AND ISNULL(CAM_PRM.deleted, 0) = 0),
        (SELECT TOP 1 cust_c.CName FROM Commer_Mas com_c INNER JOIN CustMast cust_c ON com_c.cid = cust_c.Id WHERE com_c.PartNo = {partno_col} AND ISNULL(com_c.deleted, 0) = 0 AND ISNULL(cust_c.deleted, 0) = 0),
        (SELECT TOP 1 cust_ca.CorpName FROM Commer_Mas com_ca INNER JOIN CustAliasMast cust_ca ON com_ca.cid = cust_ca.Id WHERE com_ca.PartNo = {partno_col} AND ISNULL(com_ca.deleted, 0) = 0 AND ISNULL(cust_ca.deleted, 0) = 0),
        N'—'
    )"""


def _part_name_expr(tbl_alias):
    return f"""COALESCE(
        NULLIF(LTRIM(RTRIM({tbl_alias}.description)), ''),
        (SELECT TOP 1 Description FROM WithMatMas WHERE PartNo = {tbl_alias}.partno AND ISNULL(Deleted, 0) = 0 AND Description IS NOT NULL AND LTRIM(RTRIM(Description)) <> ''),
        (SELECT TOP 1 description FROM CustJobRawMat WHERE partno = {tbl_alias}.partno AND ISNULL(deleted, 0) = 0 AND description IS NOT NULL AND LTRIM(RTRIM(description)) <> ''),
        (SELECT TOP 1 Description FROM ProductMast WHERE PartNo = {tbl_alias}.partno AND ISNULL(Deleted, 0) = 0 AND Description IS NOT NULL AND LTRIM(RTRIM(Description)) <> ''),
        (SELECT TOP 1 ItemName FROM ProdMast WHERE Partno = {tbl_alias}.partno AND ISNULL(Deleted, 0) = 0 AND ItemName IS NOT NULL AND LTRIM(RTRIM(ItemName)) <> ''),
        N''
    )"""


def _fetch_all_customers(cursor):
    customers = []
    if table_exists(cursor, "CustMast") or table_exists(cursor, "CustAliasMast"):
        try:
            cursor.execute("""
                SELECT DISTINCT LTRIM(RTRIM(CName)) AS CustomerName FROM CustMast WHERE ISNULL(deleted, 0) = 0 AND CName IS NOT NULL AND LTRIM(RTRIM(CName)) <> ''
                UNION
                SELECT DISTINCT LTRIM(RTRIM(CorpName)) AS CustomerName FROM CustAliasMast WHERE ISNULL(deleted, 0) = 0 AND CorpName IS NOT NULL AND LTRIM(RTRIM(CorpName)) <> ''
                ORDER BY CustomerName
            """)
            customers = [r[0] for r in cursor.fetchall() if r[0]]
        except Exception:
            customers = []
    return customers


def _fetch_quality_inspection_rows(cursor, start_date, end_date):
    """Unified inspection rows with rejection + rework qty from ERP tables."""
    if not all(
        table_exists(cursor, t)
        for t in (
            "InJob_Mas",
            "InJob_Det",
            "InterInspectionEntry",
            "FinalInspectionEntry",
        )
    ):
        return []

    has_process_det = table_exists(cursor, "ProcessDet")
    has_final_rej_org = table_exists(cursor, "FinalInspRejectionEntryOrg")
    has_inter_rej = table_exists(cursor, "Insp_RejectionEntry")

    pd_join = (
        "LEFT JOIN ProcessDet pd ON d.process = pd.pcode AND ISNULL(pd.deleted, 0) = 0"
        if has_process_det
        else ""
    )
    pd_join_i = (
        "LEFT JOIN ProcessDet pd ON i.process = pd.pcode AND ISNULL(pd.deleted, 0) = 0"
        if has_process_det
        else ""
    )
    pd_join_f = (
        "LEFT JOIN ProcessDet pd ON f.process = pd.pcode AND ISNULL(pd.deleted, 0) = 0"
        if has_process_det
        else ""
    )
    process_inj = "ISNULL(pd.process, ISNULL(d.process, N''))" if has_process_det else "ISNULL(d.process, N'')"
    process_int = "ISNULL(pd.process, ISNULL(i.process, N''))" if has_process_det else "ISNULL(i.process, N'')"
    process_fin = "ISNULL(pd.process, ISNULL(f.process, N''))" if has_process_det else "ISNULL(f.process, N'')"

    cust_inj = _cust_expr_injob("m", "d")
    cust_int = _cust_expr_part("i.partno")
    cust_fin = _cust_expr_part("f.partno")

    rate_inj = _part_rate_expr("d.partno", process_inj)
    rate_int = _part_rate_expr("i.partno", process_int)
    rate_fin = _part_rate_expr("f.partno", process_fin)

    part_name_inj = _part_name_expr("d")
    part_name_int = _part_name_expr("i")
    part_name_fin = _part_name_expr("f")

    reason_inj = """ISNULL((
        SELECT STUFF((
            SELECT ', ' + r.rejection
            FROM RejDetail_Table rd
            INNER JOIN Rejection r ON rd.RejCode = r.rcode
            WHERE rd.ins_Dc = m.inspno AND rd.PartNo = d.partno AND ISNULL(rd.deleted, 0) = 0
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
    ), N'')"""

    reason_int = """COALESCE(
        NULLIF((
            SELECT STUFF((
                SELECT ', ' + ir.rejection
                FROM Insp_RejectionEntry ir
                WHERE ir.inter_inspno = i.inter_inspno AND ISNULL(ir.deleted, 0) = 0
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
        ), ''),
        (
            SELECT STUFF((
                SELECT ', ' + r.rejection
                FROM RejDetail_Table rd
                INNER JOIN Rejection r ON rd.RejCode = r.rcode
                WHERE rd.ins_Dc = i.inter_inspno AND rd.PartNo = i.partno AND ISNULL(rd.deleted, 0) = 0
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
        ),
        N''
    )""" if has_inter_rej else """ISNULL((
        SELECT STUFF((
            SELECT ', ' + r.rejection
            FROM RejDetail_Table rd
            INNER JOIN Rejection r ON rd.RejCode = r.rcode
            WHERE rd.ins_Dc = i.inter_inspno AND rd.PartNo = i.partno AND ISNULL(rd.deleted, 0) = 0
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
    ), N'')"""

    reason_fin = """COALESCE(
        NULLIF((
            SELECT STUFF((
                SELECT ', ' + fr.rejection
                FROM FinalInspRejectionEntryOrg fr
                WHERE fr.finspno = f.finspno AND ISNULL(fr.deleted, 0) = 0
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
        ), ''),
        (
            SELECT STUFF((
                SELECT ', ' + r.rejection
                FROM RejDetail_Table rd
                INNER JOIN Rejection r ON rd.RejCode = r.rcode
                WHERE rd.ins_Dc = f.finspno AND rd.PartNo = f.partno AND ISNULL(rd.deleted, 0) = 0
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
        ),
        N''
    )""" if has_final_rej_org else """ISNULL((
        SELECT STUFF((
            SELECT ', ' + r.rejection
            FROM RejDetail_Table rd
            INNER JOIN Rejection r ON rd.RejCode = r.rcode
            WHERE rd.ins_Dc = f.finspno AND rd.PartNo = f.partno AND ISNULL(rd.deleted, 0) = 0
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
    ), N'')"""

    rej_qty_fin = """CAST(ISNULL((
        SELECT SUM(ISNULL(fr.qty, 0))
        FROM FinalInspRejectionEntryOrg fr
        WHERE fr.finspno = f.finspno AND ISNULL(fr.deleted, 0) = 0
    ), ISNULL(f.rejqty, 0)) AS FLOAT)""" if has_final_rej_org else "CAST(ISNULL(f.rejqty, 0) AS FLOAT)"

    rej_qty_int = """CAST(CASE 
        WHEN EXISTS (SELECT 1 FROM Insp_RejectionEntry WHERE inter_inspno = i.inter_inspno AND ISNULL(deleted, 0) = 0)
        THEN ISNULL((
            SELECT SUM(ISNULL(r.qty, 0))
            FROM Insp_RejectionEntry r
            WHERE r.inter_inspno = i.inter_inspno AND ISNULL(r.deleted, 0) = 0
        ), 0)
        ELSE ISNULL(i.rejqty, 0) + ISNULL(i.matrejqty, 0)
    END AS FLOAT)""" if has_inter_rej else "CAST(ISNULL(i.rejqty, 0) + ISNULL(i.matrejqty, 0) AS FLOAT)"

    rework_reason_inj = """ISNULL((
        SELECT STUFF((
            SELECT ', ' + rw.rework
            FROM JobInspRWDetail rw
            WHERE rw.Ins_No = m.inspno AND rw.PartNo = d.partno
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
    ), N'')"""

    rework_reason_int = """ISNULL((
        SELECT STUFF((
            SELECT ', ' + rw.rework
            FROM Insp_ReworkEntry rw
            WHERE rw.inter_inspno = i.inter_inspno AND rw.PartNo = i.partno AND ISNULL(rw.deleted, 0) = 0
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
    ), N'')"""

    rework_reason_fin = """ISNULL((
        SELECT STUFF((
            SELECT ', ' + rw.rework
            FROM FinalInspReworkEntryOrg rw
            WHERE rw.finspno = f.finspno AND rw.partno = f.partno AND ISNULL(rw.deleted, 0) = 0
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')
    ), N'')"""

    vendor_flag = """
        CASE
            WHEN LOWER(LTRIM(RTRIM(ISNULL(m.dtype, N'')))) LIKE N'%vendor%'
              OR LOWER(LTRIM(RTRIM(ISNULL(m.dtype, N'')))) LIKE N'%sub%'
              OR LOWER(LTRIM(RTRIM(ISNULL(m.dtype, N'')))) LIKE N'%outside%'
            THEN 1 ELSE 0
        END
    """

    branches = [f"""
        SELECT
            CAST(m.inspdate AS DATE) AS EntryDate,
            N'Job Order' AS InspSource,
            {vendor_flag} AS IsVendorJob,
            {cust_inj} AS CustomerName,
            {cust_inj} AS VendorName,
            CAST(N'' AS NVARCHAR(256)) AS SupplierName,
            LTRIM(RTRIM(CAST(d.partno AS NVARCHAR(128)))) AS PartNo,
            LTRIM(RTRIM(CAST({part_name_inj} AS NVARCHAR(512)))) AS PartName,
            LTRIM(RTRIM(CAST({process_inj} AS NVARCHAR(256)))) AS ProcessLine,
            LTRIM(RTRIM(CAST(ISNULL(m.inspby, N'') AS NVARCHAR(256)))) AS OperatorName,
            LTRIM(RTRIM(CAST(ISNULL(m.inspby, N'') AS NVARCHAR(256)))) AS InspectorName,
            LTRIM(RTRIM(CAST(ISNULL(m.inspno, N'') AS NVARCHAR(64)))) AS InspNo,
            {reason_inj} AS Reason,
            CAST(ISNULL(d.matrej, 0) + ISNULL(d.macrej, 0) AS FLOAT) AS RejQty,
            CAST(ISNULL((SELECT SUM(ISNULL(rw.Qty, 0)) FROM JobInspRWDetail rw WHERE rw.Ins_No = m.inspno AND rw.PartNo = d.partno), 0) AS FLOAT) AS ReworkQty,
            CAST(ISNULL(d.jobqty, 0) AS FLOAT) AS InspQty,
            CAST(ISNULL({rate_inj}, 0) AS FLOAT) AS UnitRate,
            {rework_reason_inj} AS ReworkReason
        FROM InJob_Mas m
        INNER JOIN InJob_Det d ON m.inspno = d.inspno
        {pd_join}
        WHERE ISNULL(m.deleted, 0) = 0 AND ISNULL(d.deleted, 0) = 0
          AND CAST(m.inspdate AS DATE) BETWEEN ? AND ?
          AND (
              CAST(ISNULL(d.matrej, 0) + ISNULL(d.macrej, 0) AS FLOAT) > 0
              OR ISNULL((SELECT SUM(ISNULL(rw.Qty, 0)) FROM JobInspRWDetail rw WHERE rw.Ins_No = m.inspno AND rw.PartNo = d.partno), 0) > 0
          )
    """, f"""
        SELECT
            CAST(i.inter_inspdate AS DATE) AS EntryDate,
            N'Intermediate' AS InspSource,
            CAST(0 AS INT) AS IsVendorJob,
            {cust_int} AS CustomerName,
            CAST(N'' AS NVARCHAR(256)) AS VendorName,
            CAST(N'' AS NVARCHAR(256)) AS SupplierName,
            LTRIM(RTRIM(CAST(i.partno AS NVARCHAR(128)))) AS PartNo,
            LTRIM(RTRIM(CAST({part_name_int} AS NVARCHAR(512)))) AS PartName,
            LTRIM(RTRIM(CAST({process_int} AS NVARCHAR(256)))) AS ProcessLine,
            LTRIM(RTRIM(CAST(ISNULL(i.inspby, N'') AS NVARCHAR(256)))) AS OperatorName,
            LTRIM(RTRIM(CAST(ISNULL(i.inspby, N'') AS NVARCHAR(256)))) AS InspectorName,
            LTRIM(RTRIM(CAST(ISNULL(i.inter_inspno, N'') AS NVARCHAR(64)))) AS InspNo,
            {reason_int} AS Reason,
            {rej_qty_int} AS RejQty,
            CAST(ISNULL((SELECT SUM(ISNULL(rw.qty, 0)) FROM Insp_ReworkEntry rw WHERE rw.inter_inspno = i.inter_inspno AND rw.PartNo = i.partno AND ISNULL(rw.deleted, 0) = 0), 0) AS FLOAT) AS ReworkQty,
            CAST(ISNULL(i.inspqty, 0) AS FLOAT) AS InspQty,
            CAST(ISNULL({rate_int}, 0) AS FLOAT) AS UnitRate,
            {rework_reason_int} AS ReworkReason
        FROM InterInspectionEntry i
        {pd_join_i}
        WHERE ISNULL(i.deleted, 0) = 0
          AND CAST(i.inter_inspdate AS DATE) BETWEEN ? AND ?
          AND (
              {rej_qty_int} > 0
              OR ISNULL((SELECT SUM(ISNULL(rw.qty, 0)) FROM Insp_ReworkEntry rw WHERE rw.inter_inspno = i.inter_inspno AND rw.PartNo = i.partno AND ISNULL(rw.deleted, 0) = 0), 0) > 0
          )
    """, f"""
        SELECT
            CAST(f.finspdate AS DATE) AS EntryDate,
            N'Final Insp' AS InspSource,
            CAST(0 AS INT) AS IsVendorJob,
            {cust_fin} AS CustomerName,
            CAST(N'' AS NVARCHAR(256)) AS VendorName,
            CAST(N'' AS NVARCHAR(256)) AS SupplierName,
            LTRIM(RTRIM(CAST(f.partno AS NVARCHAR(128)))) AS PartNo,
            LTRIM(RTRIM(CAST({part_name_fin} AS NVARCHAR(512)))) AS PartName,
            LTRIM(RTRIM(CAST({process_fin} AS NVARCHAR(256)))) AS ProcessLine,
            LTRIM(RTRIM(CAST(ISNULL(f.inspby, N'') AS NVARCHAR(256)))) AS OperatorName,
            LTRIM(RTRIM(CAST(ISNULL(f.inspby, N'') AS NVARCHAR(256)))) AS InspectorName,
            LTRIM(RTRIM(CAST(ISNULL(f.finspno, N'') AS NVARCHAR(64)))) AS InspNo,
            {reason_fin} AS Reason,
            {rej_qty_fin} AS RejQty,
            CAST(ISNULL((SELECT SUM(ISNULL(rw.qty, 0)) FROM FinalInspReworkEntryOrg rw WHERE rw.finspno = f.finspno AND rw.partno = f.partno AND ISNULL(rw.deleted, 0) = 0), 0) AS FLOAT) AS ReworkQty,
            CAST(ISNULL(f.totqty, 0) AS FLOAT) AS InspQty,
            CAST(ISNULL({rate_fin}, 0) AS FLOAT) AS UnitRate,
            {rework_reason_fin} AS ReworkReason
        FROM FinalInspectionEntry f
        {pd_join_f}
        WHERE ISNULL(f.deleted, 0) = 0
          AND CAST(f.finspdate AS DATE) BETWEEN ? AND ?
          AND (
              {rej_qty_fin} > 0
              OR ISNULL((SELECT SUM(ISNULL(rw.qty, 0)) FROM FinalInspReworkEntryOrg rw WHERE rw.finspno = f.finspno AND rw.partno = f.partno AND ISNULL(rw.deleted, 0) = 0), 0) > 0
          )
    """]

    supplier_rows = _fetch_supplier_iqc_rows(cursor, start_date, end_date)
    sql = "\n    UNION ALL\n".join(branches) + "\nORDER BY EntryDate, InspNo"
    params = []
    for _ in branches:
        params.extend([start_date, end_date])

    try:
        cursor.execute(sql, params)
        raw = cursor.fetchall() or []
    except Exception:
        return supplier_rows

    return list(raw) + supplier_rows


def _fetch_supplier_iqc_rows(cursor, start_date, end_date):
    """IQC / GRN supplier rejections → Supplier Rej rows."""
    if not all(table_exists(cursor, t) for t in ("grn_mas", "inspmas", "inspdet")):
        return []
    try:
        cust_iqc = """COALESCE(
            (SELECT TOP 1 CM.CName FROM CustMast CM WHERE CM.Id = GM.cid AND ISNULL(CM.deleted, 0) = 0),
            (SELECT TOP 1 CAM.CorpName FROM CustAliasMast CAM WHERE CAM.Id = GM.cid AND ISNULL(CAM.deleted, 0) = 0),
            N'—'
        )"""
        part_name_iqc = """COALESCE(
            NULLIF(LTRIM(RTRIM(D.description)), ''),
            (SELECT TOP 1 Description FROM WithMatMas WHERE PartNo = D.partno AND ISNULL(Deleted, 0) = 0 AND Description IS NOT NULL AND LTRIM(RTRIM(Description)) <> ''),
            (SELECT TOP 1 description FROM CustJobRawMat WHERE partno = D.partno AND ISNULL(deleted, 0) = 0 AND description IS NOT NULL AND LTRIM(RTRIM(description)) <> ''),
            (SELECT TOP 1 Description FROM ProductMast WHERE PartNo = D.partno AND ISNULL(Deleted, 0) = 0 AND Description IS NOT NULL AND LTRIM(RTRIM(Description)) <> ''),
            (SELECT TOP 1 ItemName FROM ProdMast WHERE Partno = D.partno AND ISNULL(Deleted, 0) = 0 AND ItemName IS NOT NULL AND LTRIM(RTRIM(ItemName)) <> ''),
            N''
        )"""
        sql = f"""
        SELECT
            CAST(IM.irdate AS DATE) AS EntryDate,
            N'Supplier' AS InspSource,
            CAST(0 AS INT) AS IsVendorJob,
            {cust_iqc} AS CustomerName,
            CAST(N'' AS NVARCHAR(256)) AS VendorName,
            {cust_iqc} AS SupplierName,
            LTRIM(RTRIM(CAST(ISNULL(D.partno, N'') AS NVARCHAR(128)))) AS PartNo,
            LTRIM(RTRIM(CAST({part_name_iqc} AS NVARCHAR(512)))) AS PartName,
            CAST(N'' AS NVARCHAR(256)) AS ProcessLine,
            CAST(N'' AS NVARCHAR(256)) AS OperatorName,
            CAST(N'' AS NVARCHAR(256)) AS InspectorName,
            LTRIM(RTRIM(CAST(ISNULL(D.irno, N'') AS NVARCHAR(64)))) AS InspNo,
            CAST(N'' AS NVARCHAR(512)) AS Reason,
            CAST(ISNULL(D.matrej, 0) + ISNULL(D.macrej, 0) AS FLOAT) AS RejQty,
            CAST(0 AS FLOAT) AS ReworkQty,
            CAST(ISNULL(D.inspqty, 0) AS FLOAT) AS InspQty,
            CAST(ISNULL((
                SELECT TOP 1 CAST(CBD.BaseRate AS FLOAT)
                FROM Commer_BaseRateDet CBD
                WHERE CBD.PartNo = D.partno AND ISNULL(CBD.deleted, 0) = 0
                ORDER BY CBD.BReffdt DESC
            ), 0) AS FLOAT) AS UnitRate,
            CAST(N'' AS NVARCHAR(512)) AS ReworkReason
        FROM grn_mas GM
        INNER JOIN inspmas IM ON GM.grnno = IM.grnno AND ISNULL(IM.deleted, 0) = 0
        INNER JOIN inspdet D ON IM.irno = D.irno AND ISNULL(D.deleted, 0) = 0
        WHERE ISNULL(GM.deleted, 0) = 0
          AND CAST(IM.irdate AS DATE) BETWEEN ? AND ?
          AND CAST(ISNULL(D.matrej, 0) + ISNULL(D.macrej, 0) AS FLOAT) > 0
        """
        cursor.execute(sql, [start_date, end_date])
        return cursor.fetchall() or []
    except Exception:
        return []


def _fetch_rejection_matrej_map(cursor):
    matrej_map = {}
    if cursor and table_exists(cursor, "Rejection"):
        try:
            cursor.execute("SELECT LTRIM(RTRIM(rejection)), ISNULL(matrej, 0) FROM Rejection WHERE ISNULL(deleted, 0) = 0")
            for r in cursor.fetchall() or []:
                if r[0]:
                    matrej_map[r[0].strip().upper()] = bool(r[1])
        except Exception:
            pass
    return matrej_map


def _row_to_dict(raw_row, matrej_map=None):
    (
        entry_date,
        insp_source,
        is_vendor_job,
        customer_name,
        vendor_name,
        supplier_name,
        part_no,
        part_name,
        process_line,
        operator_name,
        inspector_name,
        insp_no,
        reason,
        rej_qty,
        rework_qty,
        insp_qty,
        unit_rate,
        rework_reason,
    ) = raw_row[:18]

    is_vendor = bool(is_vendor_job)
    insp_src = str(insp_source or "").strip()
    rej_type = _map_rej_type_ui(insp_src, is_vendor)
    rework_group = _map_rework_group_ui(insp_src, is_vendor)

    rej_q = float(rej_qty or 0)
    rwk_q = float(rework_qty or 0)
    insp_q = float(insp_qty or 0)
    rate = float(unit_rate or 0)
    if rate <= 0:
        rate = 100.0

    date_str = ""
    month_label = "—"
    if entry_date:
        if hasattr(entry_date, "strftime"):
            date_str = entry_date.strftime("%Y-%m-%d")
            month_label = _month_label_from_date(entry_date)
        else:
            date_str = str(entry_date).strip()[:10]
            try:
                parsed = datetime.strptime(date_str, "%Y-%m-%d")
                month_label = _month_label_from_date(parsed)
            except Exception:
                pass

    rej_pct = round((rej_q / insp_q) * 100, 2) if insp_q > 0 and rej_q > 0 else 0.0
    rwk_pct = round((rwk_q / insp_q) * 100, 2) if insp_q > 0 and rwk_q > 0 else 0.0

    cust = str(customer_name or "—").strip() or "—"
    vendor = str(vendor_name or "").strip()
    supplier = str(supplier_name or "").strip()
    proc = str(process_line or "—").strip() or "—"
    oper = str(operator_name or "—").strip() or "—"
    insp = str(inspector_name or "—").strip() or "—"
    reason_s = str(reason or "").strip()
    rework_reason_s = str(rework_reason or "").strip()

    is_mat_rej = False
    if matrej_map and reason_s:
        reasons_list = [r.strip().upper() for r in reason_s.split(",") if r.strip()]
        for r_name in reasons_list:
            if matrej_map.get(r_name) is True:
                is_mat_rej = True
                break

    insp_label = {
        "Job Order": "Job order",
        "Intermediate": "Intermediate",
        "Final Insp": "Final Insp",
        "Supplier": "Supplier IQC",
    }.get(insp_src, insp_src)

    return {
        "date": date_str,
        "month": month_label,
        "inspSource": insp_src,
        "inspLabel": insp_label,
        "rejType": rej_type,
        "rejCategory": "Mat Rej" if is_mat_rej else "Mac Rej",
        "isMatRej": is_mat_rej,
        "reworkGroup": rework_group,
        "customer": cust,
        "vendor": vendor or cust,
        "supplier": supplier or vendor or cust,
        "partNo": str(part_no or "").strip(),
        "partName": str(part_name or "").strip(),
        "process": proc,
        "operator": oper,
        "inspector": insp,
        "inspNo": str(insp_no or "").strip(),
        "reason": reason_s,
        "reworkReason": rework_reason_s,
        "rejQty": round(rej_q, 2),
        "reworkQty": round(rwk_q, 2),
        "inspQty": round(insp_q, 2),
        "rejPct": rej_pct,
        "reworkPct": rwk_pct,
        "unitRate": round(rate, 2),
        "rejValue": round(rej_q * rate, 2),
        "reworkValue": round(rwk_q * rate, 2),
        "isVendorJob": is_vendor,
    }


def _compute_rejection_kpis(rows, start_date, end_date):
    scoped = [r for r in rows if r.get("rejQty", 0) > 0]
    if not scoped:
        return {"avgRejPct": 0, "totalRejQty": 0, "totalRejValue": 0, "rowCount": 0}

    total_rej = sum(float(r.get("rejQty") or 0) for r in scoped)
    total_insp = sum(float(r.get("inspQty") or 0) for r in scoped)
    total_val = sum(float(r.get("rejValue") or 0) for r in scoped)
    avg_pct = round((total_rej / total_insp) * 100, 2) if total_insp > 0 else 0.0

    return {
        "avgRejPct": avg_pct,
        "totalRejQty": round(total_rej, 2),
        "totalRejValue": round(total_val, 2),
        "rowCount": len(scoped),
    }


def _compute_rework_kpis(rows, start_date, end_date):
    scoped = [r for r in rows if r.get("reworkQty", 0) > 0]
    if not scoped:
        return {"avgReworkPct": 0, "totalReworkQty": 0, "totalReworkValue": 0, "rowCount": 0}

    total_rwk = sum(float(r.get("reworkQty") or 0) for r in scoped)
    total_insp = sum(float(r.get("inspQty") or 0) for r in scoped)
    total_val = sum(float(r.get("reworkValue") or 0) for r in scoped)
    avg_pct = round((total_rwk / total_insp) * 100, 2) if total_insp > 0 else 0.0

    return {
        "avgReworkPct": avg_pct,
        "totalReworkQty": round(total_rwk, 2),
        "totalReworkValue": round(total_val, 2),
        "rowCount": len(scoped),
    }


def _monthwise_rejection(rows, month_labels):
    rates, qtys = [], []
    for mo in month_labels:
        month_rows = [r for r in rows if r.get("month") == mo and r.get("rejQty", 0) > 0]
        if not month_rows:
            rates.append(0.0)
            qtys.append(0)
            continue
        total_rej = sum(float(r.get("rejQty") or 0) for r in month_rows)
        total_insp = sum(float(r.get("inspQty") or 0) for r in month_rows)
        rates.append(round((total_rej / total_insp) * 100, 2) if total_insp > 0 else 0.0)
        qtys.append(int(round(total_rej)))
    return {"labels": month_labels, "rates": rates, "qtys": qtys}


def _monthwise_rework(rows, month_labels):
    rates, qtys = [], []
    for mo in month_labels:
        month_rows = [r for r in rows if r.get("month") == mo and r.get("reworkQty", 0) > 0]
        if not month_rows:
            rates.append(0.0)
            qtys.append(0)
            continue
        total_rwk = sum(float(r.get("reworkQty") or 0) for r in month_rows)
        total_insp = sum(float(r.get("inspQty") or 0) for r in month_rows)
        rates.append(round((total_rwk / total_insp) * 100, 2) if total_insp > 0 else 0.0)
        qtys.append(int(round(total_rwk)))
    return {"labels": month_labels, "rates": rates, "qtys": qtys}


def _filter_options_from_rows(rows, reason_key="reason"):
    customers = sorted({r.get("customer") for r in rows if r.get("customer") and r["customer"] != "—"})
    part_nos = sorted({r.get("partNo") for r in rows if r.get("partNo")})
    
    reasons_set = set()
    for r in rows:
        val = r.get(reason_key)
        if val:
            for part in val.split(","):
                part = part.strip()
                if part:
                    reasons_set.add(part)
    reasons = sorted(reasons_set)
    
    return {"customers": customers, "partNos": part_nos, "reasons": reasons}


def build_rejection_compare_payload(cursor, start_date, end_date, load_full_fy=True):
    from .views import current_financial_year

    if load_full_fy:
        query_start, query_end = _efficiency_query_date_range(True, start_date, end_date)
    else:
        query_start, query_end = start_date, end_date

    raw_rows = _fetch_quality_inspection_rows(cursor, query_start, query_end)
    if not raw_rows and load_full_fy:
        fy_start, _fy_end = current_financial_year()
        prev_start = date(fy_start.year - 1, 4, 1)
        prev_end = date(fy_start.year, 3, 31)
        raw_rows = _fetch_quality_inspection_rows(cursor, prev_start, prev_end)
        if raw_rows:
            query_start, query_end = prev_start, prev_end

    matrej_map = _fetch_rejection_matrej_map(cursor)
    rows = [_row_to_dict(r, matrej_map) for r in raw_rows]
    month_labels = _month_labels_for_payload(rows, start_date, end_date, query_start, query_end)

    filter_opts = _filter_options_from_rows(rows, reason_key="reason")
    all_custs = _fetch_all_customers(cursor)
    if all_custs:
        filter_opts["customers"] = sorted(set(filter_opts.get("customers", [])).union(set(all_custs)))

    return {
        "from": str(start_date),
        "to": str(end_date),
        "queryFrom": str(query_start),
        "queryTo": str(query_end),
        "rows": rows,
        "monthLabels": month_labels,
        "monthwise": _monthwise_rejection(rows, month_labels),
        "kpis": _compute_rejection_kpis(rows, start_date, end_date),
        "filterOptions": filter_opts,
    }


def build_rework_compare_payload(cursor, start_date, end_date, load_full_fy=True):
    from .views import current_financial_year

    if load_full_fy:
        query_start, query_end = _efficiency_query_date_range(True, start_date, end_date)
    else:
        query_start, query_end = start_date, end_date

    raw_rows = _fetch_quality_inspection_rows(cursor, query_start, query_end)
    if not raw_rows and load_full_fy:
        fy_start, _fy_end = current_financial_year()
        prev_start = date(fy_start.year - 1, 4, 1)
        prev_end = date(fy_start.year, 3, 31)
        raw_rows = _fetch_quality_inspection_rows(cursor, prev_start, prev_end)
        if raw_rows:
            query_start, query_end = prev_start, prev_end

    matrej_map = _fetch_rejection_matrej_map(cursor)
    rows = [_row_to_dict(r, matrej_map) for r in raw_rows]
    month_labels = _month_labels_for_payload(rows, start_date, end_date, query_start, query_end)

    filter_opts = _filter_options_from_rows(rows, reason_key="reworkReason")
    all_custs = _fetch_all_customers(cursor)
    if all_custs:
        filter_opts["customers"] = sorted(set(filter_opts.get("customers", [])).union(set(all_custs)))

    return {
        "from": str(start_date),
        "to": str(end_date),
        "queryFrom": str(query_start),
        "queryTo": str(query_end),
        "rows": rows,
        "monthLabels": month_labels,
        "monthwise": _monthwise_rework(rows, month_labels),
        "kpis": _compute_rework_kpis(rows, start_date, end_date),
        "filterOptions": filter_opts,
    }
