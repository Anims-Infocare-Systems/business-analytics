from django.urls import path
from .views import (
    # Health & Authentication
    health_check, prewarm_connection, login_view, logout_view, heartbeat_view, log_transaction, get_company, public_companies_list,
    forgot_password_verify, forgot_password_reset,
    # Charts - Sabarish (Monthwise)
    po_vs_sales, customer_complaints, rejection_monthwise, rework_monthwise, mac_rejection_ppm, otd_report,
    # Purchase
    purchase_report_monthwise, supplier_rating_monthwise,
    # Vendor
    vendor_rejection_monthwise,
    # Operations
    overall_efficiency_monthwise, production_value_monthwise,
    # Production - Operator Efficiency & Machine Idle Time & Machine Efficiency
    get_operators, operator_efficiency, overall_operator_efficiency, machine_wise_idle_time, get_machines, machine_efficiency_monthwise,
    # Dashboard2 - Pranesh (Full Implementation)
    dashboard2_kpis, dashboard2_production_by_shift, dashboard2_idle_hours, dashboard2_downtime_by_reason, dashboard2_customer_complaints, dashboard2_po_pipeline, dashboard2_inspection_pending_snapshot, dashboard2_grn_pending_pipeline, dashboard2_iqc_rejections, dashboard2_otd, dashboard2_final_inspection_kpi, dashboard2_injob_inspection, dashboard2_inter_inspection, dashboard2_final_inspection_org_rej_rwk, dashboard2_top_defect_categories,
)
from .views_dashboard1 import (
    dashboard1_sales_kpi, dashboard1_purchase_kpi, dashboard1_production_kpi, dashboard1_quality_value_kpi, dashboard1_sales_projections, dashboard1_purchase_projections, dashboard1_oa_efficiency_weekly, dashboard1_quality_rejections_weekly,
)
from .views_plantperformance import (
    plant_performance_bundle, plant_performance_kpis, plant_performance_production_by_shift, plant_performance_idle_hours, plant_performance_downtime_by_reason, plant_performance_customer_complaints, plant_performance_po_pipeline, plant_performance_inspection_pending_snapshot, plant_performance_grn_pending_pipeline, plant_performance_iqc_rejections, plant_performance_otd, plant_performance_final_inspection_kpi, plant_performance_injob_inspection, plant_performance_inter_inspection, plant_performance_final_inspection_org_rej_rwk, plant_performance_top_defect_categories, plant_performance_customer_po_vs_sales, plant_performance_grn_value, plant_performance_fg_value, plant_performance_sales_analysis, plant_performance_purchase_value, plant_performance_efficiency, plant_performance_oee, plant_performance_rejection, plant_performance_rework, plant_performance_customer_complaint, plant_performance_capa, plant_performance_operator_efficiency, plant_performance_daily_production, plant_performance_production_value, plant_performance_machine_efficiency, plant_performance_supplier_rating, plant_performance_vendor_rating, plant_performance_target_vs_actual,
    supplier_rating_kpi_view, supplier_rating_chart_view, supplier_rating_registry_view, supplier_rating_actions_view,
    plant_performance_store_stock_value, plant_performance_target_criteria
)
from .views_eapproval import (
    eapproval_list, eapproval_stats, eapproval_detail, eapproval_approve, eapproval_modify, eapproval_save_comment, eapproval_delete_comment,
    eapproval_user_limits,
)
from .views_tapproval import (
    tapproval_list, tapproval_stats, tapproval_detail, tapproval_approve, tapproval_modify,
)
from .views_mapproval import (
    mapproval_list, mapproval_stats, mapproval_detail, mapproval_approve, mapproval_modify,
)
from .views_userrights import (
    user_rights_list, user_rights_me, user_rights_update, user_rights_bulk_save,
    user_rights_add_user, user_rights_delete, user_settings_date_presets,
)
from .views_sales_analysis import (
    sales_analysis_summary_strip, sales_analysis_grand_total, sales_analysis_weekly_trend, sales_analysis_revenue_charts,
    sales_analysis_month_summary, sales_analysis_invoice_details, sales_analysis_top_products,
    sales_analysis_monthly_sales_trend, sales_analysis_bill_type_revenue, sales_analysis_monthly_tax_trend,
    sales_analysis_future_projections, sales_analysis_plan_vs_actual, sales_analysis_po_ledger,
    sales_analysis_traceability, sales_analysis_avg_rate_cards, sales_analysis_part_rate_history,
)
from .views_idle_time_report import idle_time_report
from .views_efficiency_report import efficiency_report
from .views_production_analysis import (
    production_analysis_report, production_value_report, production_idle_breakdown, daily_production_details,
    machine_card_data, production_analysis_filters, production_mhr_inputs
)
from .views_purchaseanalysis import (
    purchase_analysis_summary, purchase_analysis_weekly_trend, purchase_analysis_charts, purchase_analysis_pipeline, purchase_analysis_po_details, purchase_analysis_grn_aging, purchase_analysis_month_summary, purchase_analysis_po_types, purchase_analysis_po_table, purchase_analysis_amended_po_table, purchase_analysis_short_close_table, purchase_analysis_price_trend_table, purchase_analysis_management_alerts, purchase_analysis_traceability_table, purchase_analysis_supplier_rating,
    purchase_analysis_fulfillment_schedule, purchase_analysis_average_purchase_value, purchase_analysis_advanced_purchase_analytics,
)
from .views_qualityanalysis import (
    quality_analysis_summary, quality_analysis_charts, quality_analysis_product_performance, quality_analysis_defect_causes, quality_analysis_records, quality_analysis_calibration, quality_analysis_insights,
    quality_analysis_supplier_rejections, quality_analysis_settings,
)
from .views_qualitytimeline import (
    quality_timeline_invoices_view,
    quality_timeline_search_view,
    quality_timeline_detail_view,
    quality_timeline_stage_view,
)
from .views_signup import signup_view
from .views_settings import settings_profile, settings_change_password, settings_upgrade_plan
from .views_adminpannel import (
    admin_login, admin_logout, admin_check_session, admin_change_password, admin_list_credentials, admin_create_credential, admin_delete_credential, admin_forgot_password_reset,
    admin_list_tenants, admin_create_tenant, admin_update_tenant, admin_patch_tenant_status, admin_delete_tenant,
    admin_list_tenant_users, admin_delete_tenant_user, admin_user_transactions
)
from .views_animsutility import admin_utility_clients, admin_utility_activity
from .views_notifications import (
    active_notifications, admin_list_notifications, admin_create_notification, admin_delete_notification
)


urlpatterns = [
    # ── Health & Authentication ────────────────────────────────────────
    path('health/', health_check, name='health_check'),
    path('prewarm/', prewarm_connection, name='prewarm_connection'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('heartbeat/', heartbeat_view, name='heartbeat'),
    path('log-transaction/', log_transaction, name='log_transaction'),

    path('company/<str:code>/', get_company, name='get_company'),
    path('companies/public/', public_companies_list, name='public_companies_list'),
    path('signup/', signup_view, name='signup'),
    path('forgot-password/verify/', forgot_password_verify, name='forgot_password_verify'),
    path('forgot-password/reset/', forgot_password_reset, name='forgot_password_reset'),
    path('settings/profile/', settings_profile, name='settings_profile'),
    path('settings/change-password/', settings_change_password, name='settings_change_password'),
    path('settings/upgrade-plan/', settings_upgrade_plan, name='settings_upgrade_plan'),

    # ── Charts (Sabarish - Monthwise) ─────────────────────────────────
    path('po-vs-sales/', po_vs_sales, name='po_vs_sales'),
    path('customer-complaints/', customer_complaints, name='customer_complaints'),
    path('quality/rejection-monthwise/', rejection_monthwise, name='rejection_monthwise'),
    path('quality/rework-monthwise/', rework_monthwise, name='rework_monthwise'),
    path('quality/mac-rejection-ppm/', mac_rejection_ppm, name='mac_rejection_ppm'),
    path('otd-report/', otd_report, name='otd_report'),

    # ── Purchase (Monthwise) ──────────────────────────────────────────
    path('purchase/report-monthwise/', purchase_report_monthwise, name='purchase_report_monthwise'),
    path('purchase/supplier-rating/', supplier_rating_monthwise, name='supplier_rating_monthwise'),

    # ── Vendor ────────────────────────────────────────────────────────
    path('vendor/rejection-monthwise/', vendor_rejection_monthwise, name='vendor_rejection_monthwise'),

    # ── Operations ────────────────────────────────────────────────────
    path('operations/overall-efficiency/', overall_efficiency_monthwise, name='overall_efficiency_monthwise'),
    path('operations/production-value/', production_value_monthwise, name='production_value_monthwise'),

    # ── Production - Operator & Machine ───────────────────────────────
    path('production/operators/', get_operators, name='get_operators'),
    path('production/operator-efficiency/', operator_efficiency, name='operator_efficiency'),
    path('production/overall-operator-efficiency/', overall_operator_efficiency, name='overall_operator_efficiency'),
    path('production/machine-idle-time/', machine_wise_idle_time, name='machine_wise_idle_time'),
    path('production/machines/', get_machines, name='get_machines'),
    path('production/machine-efficiency-monthwise/', machine_efficiency_monthwise, name='machine_efficiency_monthwise'),

    # ── Dashboard2 (Pranesh - Full Implementation) ────────────────────
    path('dashboard2/kpis/', dashboard2_kpis, name='dashboard2_kpis'),
    path('dashboard2/production-by-shift/', dashboard2_production_by_shift, name='dashboard2_production_by_shift'),
    path('dashboard2/idle-hours/', dashboard2_idle_hours, name='dashboard2_idle_hours'),
    path('dashboard2/downtime-by-reason/', dashboard2_downtime_by_reason, name='dashboard2_downtime_by_reason'),
    path('dashboard2/customer-complaints/', dashboard2_customer_complaints, name='dashboard2_customer_complaints'),
    path('dashboard2/po-pipeline/', dashboard2_po_pipeline, name='dashboard2_po_pipeline'),
    path('dashboard2/inspection-pending-snapshot/', dashboard2_inspection_pending_snapshot, name='dashboard2_inspection_pending_snapshot'),
    path('dashboard2/grn-pending-pipeline/', dashboard2_grn_pending_pipeline, name='dashboard2_grn_pending_pipeline'),
    path('dashboard2/iqc-rejections/', dashboard2_iqc_rejections, name='dashboard2_iqc_rejections'),
    path('dashboard2/otd/', dashboard2_otd, name='dashboard2_otd'),
    path('dashboard2/final-inspection-kpi/', dashboard2_final_inspection_kpi, name='dashboard2_final_inspection_kpi'),
    path('dashboard2/injob-inspection/', dashboard2_injob_inspection, name='dashboard2_injob_inspection'),
    path('dashboard2/inter-inspection/', dashboard2_inter_inspection, name='dashboard2_inter_inspection'),
    path('dashboard2/final-inspection-org-rej-rwk/', dashboard2_final_inspection_org_rej_rwk, name='dashboard2_final_inspection_org_rej_rwk'),
    path('dashboard2/top-defect-categories/', dashboard2_top_defect_categories, name='dashboard2_top_defect_categories'),

    # ── Plant Performance (Dashboard3) ────────────────────────────────
    path('plant-performance/bundle/', plant_performance_bundle, name='plant_performance_bundle'),
    path('plant-performance/kpis/', plant_performance_kpis, name='plant_performance_kpis'),
    path('plant-performance/production-by-shift/', plant_performance_production_by_shift, name='plant_performance_production_by_shift'),
    path('plant-performance/idle-hours/', plant_performance_idle_hours, name='plant_performance_idle_hours'),
    path('plant-performance/downtime-by-reason/', plant_performance_downtime_by_reason, name='plant_performance_downtime_by_reason'),
    path('plant-performance/customer-complaints/', plant_performance_customer_complaints, name='plant_performance_customer_complaints'),
    path('plant-performance/po-pipeline/', plant_performance_po_pipeline, name='plant_performance_po_pipeline'),
    path('plant-performance/inspection-pending-snapshot/', plant_performance_inspection_pending_snapshot, name='plant_performance_inspection_pending_snapshot'),
    path('plant-performance/grn-pending-pipeline/', plant_performance_grn_pending_pipeline, name='plant_performance_grn_pending_pipeline'),
    path('plant-performance/iqc-rejections/', plant_performance_iqc_rejections, name='plant_performance_iqc_rejections'),
    path('plant-performance/otd/', plant_performance_otd, name='plant_performance_otd'),
    path('plant-performance/final-inspection-kpi/', plant_performance_final_inspection_kpi, name='plant_performance_final_inspection_kpi'),
    path('plant-performance/injob-inspection/', plant_performance_injob_inspection, name='plant_performance_injob_inspection'),
    path('plant-performance/inter-inspection/', plant_performance_inter_inspection, name='plant_performance_inter_inspection'),
    path('plant-performance/final-inspection-org-rej-rwk/', plant_performance_final_inspection_org_rej_rwk, name='plant_performance_final_inspection_org_rej_rwk'),
    path('plant-performance/top-defect-categories/', plant_performance_top_defect_categories, name='plant_performance_top_defect_categories'),
    path('plant-performance/customer-po-vs-sales/', plant_performance_customer_po_vs_sales, name='plant_performance_customer_po_vs_sales'),
    path('plant-performance/grn-value/', plant_performance_grn_value, name='plant_performance_grn_value'),
    path('plant-performance/fg-value/', plant_performance_fg_value, name='plant_performance_fg_value'),
    path('plant-performance/sales-analysis/', plant_performance_sales_analysis, name='plant_performance_sales_analysis'),
    path('plant-performance/purchase-value/', plant_performance_purchase_value, name='plant_performance_purchase_value'),
    path('plant-performance/efficiency/', plant_performance_efficiency, name='plant_performance_efficiency'),
    path('plant-performance/oee/', plant_performance_oee, name='plant_performance_oee'),
    path('plant-performance/rejection/', plant_performance_rejection, name='plant_performance_rejection'),
    path('plant-performance/rework/', plant_performance_rework, name='plant_performance_rework'),
    path('plant-performance/customer-complaint/', plant_performance_customer_complaint, name='plant_performance_customer_complaint'),
    path('plant-performance/capa/', plant_performance_capa, name='plant_performance_capa'),
    path('plant-performance/operator-efficiency/', plant_performance_operator_efficiency, name='plant_performance_operator_efficiency'),
    path('plant-performance/daily-production/', plant_performance_daily_production, name='plant_performance_daily_production'),
    path('plant-performance/production-value/', plant_performance_production_value, name='plant_performance_production_value'),
    path('plant-performance/machine-efficiency/', plant_performance_machine_efficiency, name='plant_performance_machine_efficiency'),
    path('plant-performance/supplier-rating/', plant_performance_supplier_rating, name='plant_performance_supplier_rating'),
    path('plant-performance/vendor-rating/', plant_performance_vendor_rating, name='plant_performance_vendor_rating'),
    path('plant-performance/target-vs-actual/', plant_performance_target_vs_actual, name='plant_performance_target_vs_actual'),
    path('plant-performance/store-stock/', plant_performance_store_stock_value, name='plant_performance_store_stock_value'),
    path('plant-performance/target-criteria/', plant_performance_target_criteria, name='plant_performance_target_criteria'),
    path('plant-performance/supplier-rating/kpi/', supplier_rating_kpi_view, name='supplier_rating_kpi_view'),
    path('plant-performance/supplier-rating/chart/', supplier_rating_chart_view, name='supplier_rating_chart_view'),
    path('plant-performance/supplier-rating/registry/', supplier_rating_registry_view, name='supplier_rating_registry_view'),
    path('plant-performance/supplier-rating/actions/', supplier_rating_actions_view, name='supplier_rating_actions_view'),

    # ── Dashboard1 ────────────────────────────────────────────────────
    path('dashboard1/sales-kpi/', dashboard1_sales_kpi, name='dashboard1_sales_kpi'),
    path('dashboard1/purchase-kpi/', dashboard1_purchase_kpi, name='dashboard1_purchase_kpi'),
    path('dashboard1/production-kpi/', dashboard1_production_kpi, name='dashboard1_production_kpi'),
    path('dashboard1/quality-value-kpi/', dashboard1_quality_value_kpi, name='dashboard1_quality_value_kpi'),
    path('dashboard1/sales-projections/', dashboard1_sales_projections, name='dashboard1_sales_projections'),
    path('dashboard1/purchase-projections/', dashboard1_purchase_projections, name='dashboard1_purchase_projections'),
    path('dashboard1/oa-efficiency-weekly/', dashboard1_oa_efficiency_weekly, name='dashboard1_oa_efficiency_weekly'),
    path('dashboard1/quality-rejections-weekly/', dashboard1_quality_rejections_weekly, name='dashboard1_quality_rejections_weekly'),

    # ── Sales Analysis ────────────────────────────────────────────────
    path('sales-analysis/summary-strip/', sales_analysis_summary_strip, name='sales_analysis_summary_strip'),
    path('sales-analysis/grand-total/', sales_analysis_grand_total, name='sales_analysis_grand_total'),
    path('sales-analysis/weekly-trend/', sales_analysis_weekly_trend, name='sales_analysis_weekly_trend'),
    path('sales-analysis/revenue-charts/', sales_analysis_revenue_charts, name='sales_analysis_revenue_charts'),
    path('sales-analysis/month-summary/', sales_analysis_month_summary, name='sales_analysis_month_summary'),
    path('sales-analysis/invoice-details/', sales_analysis_invoice_details, name='sales_analysis_invoice_details'),
    path('sales-analysis/top-products/', sales_analysis_top_products, name='sales_analysis_top_products'),
    path('sales-analysis/monthly-sales-trend/', sales_analysis_monthly_sales_trend, name='sales_analysis_monthly_sales_trend'),
    path('sales-analysis/bill-type-revenue/', sales_analysis_bill_type_revenue, name='sales_analysis_bill_type_revenue'),
    path('sales-analysis/monthly-tax-trend/', sales_analysis_monthly_tax_trend, name='sales_analysis_monthly_tax_trend'),
    path('sales-analysis/future-projections/', sales_analysis_future_projections, name='sales_analysis_future_projections'),
    path('sales-analysis/plan-vs-actual/', sales_analysis_plan_vs_actual, name='sales_analysis_plan_vs_actual'),
    path('sales-analysis/po-ledger/', sales_analysis_po_ledger, name='sales_analysis_po_ledger'),
    path('sales-analysis/traceability/', sales_analysis_traceability, name='sales_analysis_traceability'),
    path('sales-analysis/avg-rate-cards/', sales_analysis_avg_rate_cards, name='sales_analysis_avg_rate_cards'),
    path('sales-analysis/part-rate-history/', sales_analysis_part_rate_history, name='sales_analysis_part_rate_history'),

    # ── Idle Time Report ──────────────────────────────────────────────
    path('idle-time-report/', idle_time_report, name='idle_time_report'),

    # ── Efficiency Report (MIS) ───────────────────────────────────────
    path('efficiency-report/', efficiency_report, name='efficiency_report'),

    # ── Production Analysis ───────────────────────────────────────────
    path('production-analysis-report/', production_analysis_report, name='production_analysis_report'),
    path('production-value-report/', production_value_report, name='production_value_report'),
    path('production-idle-breakdown/', production_idle_breakdown, name='production_idle_breakdown'),
    path('production-analysis/daily-details/', daily_production_details, name='daily_production_details'),
    path('production-analysis/filters/', production_analysis_filters, name='production_analysis_filters'),
    path('production-analysis/mhr-inputs/', production_mhr_inputs, name='production_mhr_inputs'),
    path('machines/<path:macno>/card/', machine_card_data, name='machine_card_data'),

    # ── Purchase Analysis ─────────────────────────────────────────────
    path('purchase-analysis/summary/', purchase_analysis_summary, name='purchase_analysis_summary'),
    path('purchase-analysis/weekly-trend/', purchase_analysis_weekly_trend, name='purchase_analysis_weekly_trend'),
    path('purchase-analysis/charts/', purchase_analysis_charts, name='purchase_analysis_charts'),
    path('purchase-analysis/pipeline/', purchase_analysis_pipeline, name='purchase_analysis_pipeline'),
    path('purchase-analysis/po-details/', purchase_analysis_po_details, name='purchase_analysis_po_details'),
    path('purchase-analysis/grn-aging/', purchase_analysis_grn_aging, name='purchase_analysis_grn_aging'),
    path('purchase-analysis/month-summary/', purchase_analysis_month_summary, name='purchase_analysis_month_summary'),
    path('purchase-analysis/po-types/', purchase_analysis_po_types, name='purchase_analysis_po_types'),
    path('purchase-analysis/po-table/', purchase_analysis_po_table, name='purchase_analysis_po_table'),
    path('purchase-analysis/amended-po-table/', purchase_analysis_amended_po_table, name='purchase_analysis_amended_po_table'),
    path('purchase-analysis/short-close-table/', purchase_analysis_short_close_table, name='purchase_analysis_short_close_table'),
    path('purchase-analysis/price-trend/', purchase_analysis_price_trend_table, name='purchase_analysis_price_trend_table'),
    path('purchase-analysis/management-alerts/', purchase_analysis_management_alerts, name='purchase_analysis_management_alerts'),
    path('purchase-analysis/traceability-table/', purchase_analysis_traceability_table, name='purchase_analysis_traceability_table'),
    path('purchase-analysis/supplier-rating/', purchase_analysis_supplier_rating, name='purchase_analysis_supplier_rating'),
    path('purchase-analysis/fulfillment-schedule/', purchase_analysis_fulfillment_schedule, name='purchase_analysis_fulfillment_schedule'),
    path('purchase-analysis/average-purchase-value/', purchase_analysis_average_purchase_value, name='purchase_analysis_average_purchase_value'),
    path('purchase-analysis/advanced-purchase-analytics/', purchase_analysis_advanced_purchase_analytics, name='purchase_analysis_advanced_purchase_analytics'),

    # ── Quality Analysis ──────────────────────────────────────────────
    path('quality-analysis/summary/', quality_analysis_summary, name='quality_analysis_summary'),
    path('quality-analysis/charts/', quality_analysis_charts, name='quality_analysis_charts'),
    path('quality-analysis/product-performance/', quality_analysis_product_performance, name='quality_analysis_product_performance'),
    path('quality-analysis/defect-causes/', quality_analysis_defect_causes, name='quality_analysis_defect_causes'),
    path('quality-analysis/records/', quality_analysis_records, name='quality_analysis_records'),
    path('quality-analysis/calibration/', quality_analysis_calibration, name='quality_analysis_calibration'),
    path('quality-analysis/insights/', quality_analysis_insights, name='quality_analysis_insights'),
    path('quality-analysis/supplier-rejections/', quality_analysis_supplier_rejections, name='quality_analysis_supplier_rejections'),
    path('quality-analysis/settings/', quality_analysis_settings, name='quality_analysis_settings'),

    # ── Quality Timeline / End-to-End Traceability ────────────────────
    path('quality-timeline/invoices/', quality_timeline_invoices_view, name='quality_timeline_invoices'),
    path('quality-timeline/invoices/search/', quality_timeline_search_view, name='quality_timeline_search'),
    path('quality-timeline/<str:invoice_no>/', quality_timeline_detail_view, name='quality_timeline_detail'),
    path('quality-timeline/<str:invoice_no>/stage/<int:stage_no>/', quality_timeline_stage_view, name='quality_timeline_stage'),
    # Aliases under quality-analysis
    path('quality-analysis/timeline/invoices/', quality_timeline_invoices_view, name='qa_timeline_invoices'),
    path('quality-analysis/timeline/invoices/search/', quality_timeline_search_view, name='qa_timeline_search'),
    path('quality-analysis/timeline/<str:invoice_no>/', quality_timeline_detail_view, name='qa_timeline_detail'),
    path('quality-analysis/timeline/<str:invoice_no>/stage/<int:stage_no>/', quality_timeline_stage_view, name='qa_timeline_stage'),

    # ── E-Approval Module ─────────────────────────────────────────────
    path('eapproval/list/', eapproval_list, name='eapproval_list'),
    path('eapproval/stats/', eapproval_stats, name='eapproval_stats'),
    path('eapproval/detail/', eapproval_detail, name='eapproval_detail'),
    path('eapproval/approve/', eapproval_approve, name='eapproval_approve'),
    path('eapproval/modify/', eapproval_modify, name='eapproval_modify'),
    path('eapproval/comment/', eapproval_save_comment, name='eapproval_save_comment'),
    path('eapproval/comment/delete/', eapproval_delete_comment, name='eapproval_delete_comment'),
    path('eapproval/user-limits/', eapproval_user_limits, name='eapproval_user_limits'),

    # ── T-Approval Module ─────────────────────────────────────────────
    path('tapproval/list/', tapproval_list, name='tapproval_list'),
    path('tapproval/stats/', tapproval_stats, name='tapproval_stats'),
    path('tapproval/detail/', tapproval_detail, name='tapproval_detail'),
    path('tapproval/approve/', tapproval_approve, name='tapproval_approve'),
    path('tapproval/modify/', tapproval_modify, name='tapproval_modify'),

    # ── M-Approval Module ─────────────────────────────────────────────
    path('mapproval/list/', mapproval_list, name='mapproval_list'),
    path('mapproval/stats/', mapproval_stats, name='mapproval_stats'),
    path('mapproval/detail/', mapproval_detail, name='mapproval_detail'),
    path('mapproval/approve/', mapproval_approve, name='mapproval_approve'),
    path('mapproval/modify/', mapproval_modify, name='mapproval_modify'),

    # ── User Rights ───────────────────────────────────────────────────
    path('user-rights/list/', user_rights_list, name='user_rights_list'),
    path('user-rights/me/', user_rights_me, name='user_rights_me'),
    path('user-rights/update/', user_rights_update, name='user_rights_update'),
    path('user-rights/bulk-save/', user_rights_bulk_save, name='user_rights_bulk_save'),
    path('user-rights/add-user/', user_rights_add_user, name='user_rights_add_user'),
    path('user-rights/delete/<int:user_id>/', user_rights_delete, name='user_rights_delete'),
    path('user-settings/date-presets/', user_settings_date_presets, name='user_settings_date_presets'),

    # ── Admin Panel ───────────────────────────────────────────────────
    path('admin/login/', admin_login, name='admin_login'),
    path('admin/logout/', admin_logout, name='admin_logout'),
    path('admin/check-session/', admin_check_session, name='admin_check_session'),
    path('admin/change-password/', admin_change_password, name='admin_change_password'),
    path('admin/forgot-password/reset/', admin_forgot_password_reset, name='admin_forgot_password_reset'),
    path('admin/credentials/', admin_list_credentials, name='admin_list_credentials'),
    path('admin/credentials/create/', admin_create_credential, name='admin_create_credential'),
    path('admin/credentials/delete/<int:admin_id>/', admin_delete_credential, name='admin_delete_credential'),
    path('admin/tenants/', admin_list_tenants, name='admin_list_tenants'),
    path('admin/tenants/create/', admin_create_tenant, name='admin_create_tenant'),
    path('admin/tenants/update/', admin_update_tenant, name='admin_update_tenant'),
    path('admin/tenants/<int:tenant_id>/status/', admin_patch_tenant_status, name='admin_patch_tenant_status'),
    path('admin/tenants/delete/<int:tenant_id>/', admin_delete_tenant, name='admin_delete_tenant'),
    path('admin/tenants/<str:company_code>/users/', admin_list_tenant_users, name='admin_list_tenant_users'),
    path('admin/tenants/users/<int:user_id>/', admin_delete_tenant_user, name='admin_delete_tenant_user'),
    path('admin/utility/clients/', admin_utility_clients, name='admin_utility_clients'),
    path('admin/utility/activity/', admin_utility_activity, name='admin_utility_activity'),
    path('admin/reports/user-transactions/', admin_user_transactions, name='admin_user_transactions'),

    # ── Broadcast Notifications ───────────────────────────────────────
    path('notifications/active/', active_notifications, name='active_notifications'),
    path('admin/notifications/', admin_list_notifications, name='admin_list_notifications'),
    path('admin/notifications/create/', admin_create_notification, name='admin_create_notification'),
    path('admin/notifications/<int:notification_id>/', admin_delete_notification, name='admin_delete_notification_rest'),
    path('admin/notifications/delete/<int:notification_id>/', admin_delete_notification, name='admin_delete_notification'),

]