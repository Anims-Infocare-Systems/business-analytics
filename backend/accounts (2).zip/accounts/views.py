from collections import defaultdict
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from typing import Any
from datetime import datetime, date
from calendar import monthrange
from .models import Tenant
from .utils.db import ErpConnectionError, check_tenant_erp_connection, get_connection

# ─────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────
def encrypt_password(plain_password):
    """Shift each ASCII value by +2 (existing ERP encryption)."""
    return ''.join(chr(ord(c) + 2) for c in plain_password)

def decrypt_password(encrypted_password):
    """Shift each ASCII value by -2 (existing ERP decryption)."""
    return ''.join(chr(ord(c) - 2) for c in encrypted_password)

def get_tenant_connection(request):
    """Pull tenant DB details from session and return an open connection (auto-restoring session if needed)."""
    from .session_utils import get_or_restore_session_tenant
    tenant = get_or_restore_session_tenant(request, allow_expired=False)

    conn = get_connection(
        tenant["erp_server"], tenant["erp_database"], tenant["erp_user"],
        tenant["erp_password"], tenant["erp_port"],
    )
    return conn, tenant

def current_financial_year():
    """Returns (start_date, end_date) for the current Indian financial year."""
    today = date.today()
    if today.month >= 4:
        return date(today.year, 4, 1), date(today.year + 1, 3, 31)
    else:
        return date(today.year - 1, 4, 1), date(today.year, 3, 31)

def parse_date_range(request):
    """Parse ?from=YYYY-MM-DD&to=YYYY-MM-DD. Falls back to current FY."""
    from_param = request.GET.get("from", "").strip()
    to_param   = request.GET.get("to",   "").strip()
    if from_param and to_param:
        try:
            start = datetime.strptime(from_param, "%Y-%m-%d").date()
            end   = datetime.strptime(to_param,   "%Y-%m-%d").date()
            if start <= end:
                return start, end
        except ValueError:
            pass
    return current_financial_year()

def generate_month_buckets(start_date, end_date):
    """
    Given start_date and end_date (date objects),
    returns:
      buckets: list of (year, month) tuples
      labels: list of formatted string labels e.g. ["Nov-25", "Dec-25", "Jan-26", ...]
    """
    month_abbrs = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    buckets = []
    labels = []
    
    cur_y = start_date.year
    cur_m = start_date.month
    end_y = end_date.year
    end_m = end_date.month
    
    while (cur_y < end_y) or (cur_y == end_y and cur_m <= end_m):
        buckets.append((cur_y, cur_m))
        labels.append(f"{month_abbrs[cur_m]}-{str(cur_y)[2:]}")
        cur_m += 1
        if cur_m > 12:
            cur_m = 1
            cur_y += 1
            
    return buckets, labels

def get_fy_label(start_date, end_date):
    s_fy = start_date.year if start_date.month >= 4 else start_date.year - 1
    e_fy = end_date.year if end_date.month >= 4 else end_date.year - 1
    if s_fy == e_fy:
        return f"FY {s_fy}-{str(s_fy + 1)[2:]}"
    else:
        return f"FY {s_fy}-{str(e_fy + 1)[2:]}"


def dashboard2_parse_date_range_default_month(request):
    """Same defaults as dashboard2_kpis: month start → today, or ?from=&to="""
    from_param = (request.GET.get("from") or "").strip()
    to_param = (request.GET.get("to") or "").strip()
    if from_param and to_param:
        try:
            start_date = datetime.strptime(from_param, "%Y-%m-%d").date()
            end_date = datetime.strptime(to_param,   "%Y-%m-%d").date()
            if start_date > end_date: start_date, end_date = end_date, start_date
            return start_date, end_date
        except ValueError: pass
    today = date.today()
    return date(today.year, today.month, 1), today

def to_lakhs(value):
    """Convert Rupees → ₹ Lakhs, rounded to 2 decimal places."""
    return round(float(value or 0) / 100_000, 2)

def month_key_from_db(raw):
    try: return int(raw) if raw is not None else None
    except (TypeError, ValueError): return None

def table_exists(cursor, table_name):
    cursor.execute("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = ?", (table_name,))
    return cursor.fetchone() is not None

def find_first_column(cursor, table_name, candidates):
    for col in candidates:
        cursor.execute("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? AND COLUMN_NAME = ?", (table_name, col))
        if cursor.fetchone(): return col
    return None

def find_first_table(cursor, candidates):
    for t in candidates:
        if table_exists(cursor, t): return t
    return None

def resolve_erp_table(cursor, candidate_names):
    for logical in candidate_names:
        cursor.execute("SELECT TOP 1 TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE UPPER(LTRIM(RTRIM(TABLE_NAME))) = UPPER(LTRIM(RTRIM(?))) ORDER BY TABLE_SCHEMA, TABLE_NAME", (logical,))
        row = cursor.fetchone()
        if row:
            schema, name = row[0], row[1]
            return schema, name, f"[{schema}].[{name}]"
    return None, None, None

def find_column_ci(cursor, table_schema, table_name, candidates):
    for col in candidates:
        cursor.execute("SELECT TOP 1 COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND UPPER(LTRIM(RTRIM(COLUMN_NAME))) = UPPER(LTRIM(RTRIM(?)))", (table_schema, table_name, col))
        row = cursor.fetchone()
        if row: return row[0]
    return None

# ─────────────────────────────────────────────────────────────
#  HEALTH
# ─────────────────────────────────────────────────────────────
@api_view(['GET', 'HEAD'])
def health_check(request):
    return Response({"status": "ok"})

@api_view(['GET', 'HEAD', 'POST'])
def prewarm_connection(request):
    """Pre-warm central database connection socket so login is hot."""
    from django.db import connection
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
    except Exception:
        pass
    return Response({"status": "warm"})

def is_plan_expired(company_code):
    """
    Returns True if the tenant's plan has expired or is inactive, False otherwise.
    Companies with company_code starting with T, P, or D are always free forever.
    Companies with company_code starting with A (and other commercial codes) enforce plan & expiry rules.
    Results are cached in Redis for 30 minutes (1800s) to eliminate remote DB query latency on every API call.
    """
    if not company_code:
        return False

    code = str(company_code).strip().upper()

    # Company codes starting with T, P, or D are always free forever
    if code.startswith(('T', 'P', 'D')):
        return False

    from django.core.cache import cache
    cache_key = f"tenant_plan_expired:{code}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    from django.db import connection
    import datetime
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT active_status, end_date FROM tenants_signup WHERE UPPER(company_code) = UPPER(%s)",
                [code]
            )
            row = cursor.fetchone()
            if not row:
                cache.set(cache_key, False, timeout=1800)
                return False
            active_status, end_date = row
            
            # If active status is False/0/None, the plan is inactive/expired
            if not active_status:
                cache.set(cache_key, True, timeout=1800)
                return True
            
            # Check if there is an active plan upgrade
            cursor.execute(
                """
                SELECT plan_end_date 
                FROM tenant_planupgrade 
                WHERE UPPER(company_code) = UPPER(%s) AND plan_status = 'Active'
                """,
                [code]
            )
            upgrade_row = cursor.fetchone()
            if upgrade_row:
                plan_end = upgrade_row[0] or end_date
            else:
                plan_end = end_date
            
            result = False
            if plan_end:
                # Normalize plan_end to date object
                if isinstance(plan_end, datetime.datetime):
                    plan_end = plan_end.date()
                elif isinstance(plan_end, datetime.date):
                    pass
                else:
                    try:
                        plan_end = datetime.datetime.strptime(str(plan_end).split()[0], "%Y-%m-%d").date()
                    except ValueError:
                        cache.set(cache_key, False, timeout=1800)
                        return False
                
                # Expired if plan_end is strictly in the past
                if plan_end < datetime.date.today():
                    result = True
            
            cache.set(cache_key, result, timeout=1800)
            return result
    except Exception:
        return False


def invalidate_plan_expired_cache(company_code):
    """Call when a tenant renews, upgrades, or toggles active status."""
    if not company_code:
        return
    from django.core.cache import cache
    code = str(company_code).strip().upper()
    cache.delete(f"tenant_plan_expired:{code}")
    cache.delete(f"tenant_license:{code}")
    cache.delete(f"company_lookup:{code}")
    cache.delete(f"tenant_model:{code}")
    cache.delete("public_companies_map")

def get_tenant_license(company_code):
    code = str(company_code or "").strip().upper()
    if not code:
        return {
            "dashboard": True, "approvals": True, "reports": True,
            "mis": True, "charts": True, "utility": True, "plan_id": "free"
        }

    from django.core.cache import cache
    cache_key = f"tenant_license:{code}"
    try:
        cached = cache.get(cache_key)
        if cached is not None:
            return cached
    except Exception:
        pass

    license_dict = None
    from django.db import connection
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT dashboard, approvals, reports, mis, charts, utility, plan_id FROM tenants_lisencemodule WHERE UPPER(company_code) = UPPER(%s)",
                [code]
            )
            row = cursor.fetchone()
            if row:
                license_dict = {
                    "dashboard": bool(row[0]),
                    "approvals": bool(row[1]),
                    "reports": bool(row[2]),
                    "mis": bool(row[3]),
                    "charts": bool(row[4]),
                    "utility": bool(row[5]),
                    "plan_id": str(row[6]).strip().lower()
                }
    except Exception:
        pass

    # If not found in tenants_lisencemodule, fallback based on tenants_signup table
    if not license_dict:
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT plan_id FROM tenants_signup WHERE UPPER(company_code) = UPPER(%s)",
                    [code]
                )
                row = cursor.fetchone()
                if row:
                    plan_id = str(row[0]).strip().lower()
                    if plan_id == "pro":
                        license_dict = {
                            "dashboard": True,
                            "approvals": True,
                            "reports": False,
                            "mis": False,
                            "charts": False,
                            "utility": True,
                            "plan_id": "pro"
                        }
        except Exception:
            pass

    # Default fallback (Max/Free have access to all)
    if not license_dict:
        license_dict = {
            "dashboard": True,
            "approvals": True,
            "reports": True,
            "mis": True,
            "charts": True,
            "utility": True,
            "plan_id": "free"
        }

    try:
        cache.set(cache_key, license_dict, timeout=1800)  # 30 minutes
    except Exception:
        pass

    return license_dict

def apply_license_restrictions_to_rights(rights, license_info):
    if not license_info or not isinstance(license_info, dict):
        return rights
        
    MODULE_MAP = {
        "dashboard": ["Dashboard", "Top Management Dashboard", "Plant Performance Dashboard"],
        "approvals": ["Approvals", "E-Approval", "T-Approval", "M-Approval"],
        "reports": ["Reports", "Sales Analysis", "Purchase Analysis", "Quality Analysis", "Production Analysis"],
        "mis": ["MIS", "Idle Time Report", "Efficiency Report"],
        "charts": ["Charts"],
        "utility": ["Utility", "User Rights"],
    }
    
    for mod_key, forms in MODULE_MAP.items():
        if not license_info.get(mod_key, True):
            for f in forms:
                if f in rights:
                    rights[f] = False
    return rights

def update_tenant_license(tenant_id, company_code, plan_id, modules_dict=None):
    from django.db import connection
    plan_id = plan_id.lower().strip()
    
    if modules_dict and isinstance(modules_dict, dict):
        dashboard = 1 if modules_dict.get("dashboard", True) else 0
        approvals = 1 if modules_dict.get("approvals", True) else 0
        reports   = 1 if modules_dict.get("reports", True) else 0
        mis       = 1 if modules_dict.get("mis", True) else 0
        charts    = 1 if modules_dict.get("charts", True) else 0
        utility   = 1 if modules_dict.get("utility", True) else 0
    elif plan_id == "pro":
        dashboard = 1
        approvals = 1
        reports = 0
        mis = 0
        charts = 0
        utility = 1
    else:
        # free, enterprise/max, etc.
        dashboard = 1
        approvals = 1
        reports = 1
        mis = 1
        charts = 1
        utility = 1
        
    try:
        with connection.cursor() as cursor:
            # Check if row already exists
            cursor.execute(
                "SELECT COUNT(1) FROM tenants_lisencemodule WHERE UPPER(company_code) = UPPER(%s)",
                [company_code]
            )
            exists = cursor.fetchone()[0] > 0
            
            if exists:
                cursor.execute(
                    """
                    UPDATE tenants_lisencemodule 
                    SET plan_id = %s, dashboard = %s, approvals = %s, reports = %s, mis = %s, charts = %s, utility = %s, updated_at = GETDATE()
                    WHERE UPPER(company_code) = UPPER(%s)
                    """,
                    [plan_id, dashboard, approvals, reports, mis, charts, utility, company_code]
                )
            else:
                cursor.execute(
                    """
                    INSERT INTO tenants_lisencemodule (tenant_id, company_code, plan_id, dashboard, approvals, reports, mis, charts, utility, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, GETDATE(), GETDATE())
                    """,
                    [tenant_id, company_code, plan_id, dashboard, approvals, reports, mis, charts, utility]
                )
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"Error updating tenant license: {e}")

# ─────────────────────────────────────────────────────────────
#  LOGIN
# ─────────────────────────────────────────────────────────────
@api_view(['POST'])
def login_view(request):
    from django.db import connection
    company_code = (request.data.get("company_code") or "").strip()
    username     = (request.data.get("username")     or "").strip()
    password     =  request.data.get("password", "")
    system_name  = (request.data.get("system_name")  or "").strip()
    if not company_code or not username or not password:
        return Response({"error": "company_code, username and password are required."}, status=400)

    if not system_name:
        user_agent = request.META.get('HTTP_USER_AGENT', '')
        if 'Windows' in user_agent:
            os_name = 'Windows PC'
        elif 'Macintosh' in user_agent:
            os_name = 'Mac'
        elif 'Linux' in user_agent:
            os_name = 'Linux PC'
        elif 'iPhone' in user_agent or 'iPad' in user_agent:
            os_name = 'iOS Device'
        elif 'Android' in user_agent:
            os_name = 'Android Device'
        else:
            os_name = 'Browser Client'
        system_name = os_name
    from django.db import Error as DatabaseError
    from django.core.cache import cache
    tenant = None
    c_code_upper = company_code.strip().upper()
    u_name_upper = username.strip().upper()
    tenant_cache_key = f"tenant_model:{c_code_upper}"
    try:
        tenant = cache.get(tenant_cache_key)
    except Exception:
        pass

    if not tenant:
        try:
            tenant = Tenant.objects.get(company_code__iexact=company_code)
            try:
                cache.set(tenant_cache_key, tenant, timeout=86400)
            except Exception:
                pass
        except Tenant.DoesNotExist:  # type: ignore
            return Response({"error": "Invalid company code."}, status=400)
        except DatabaseError as db_exc:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Master Database connection failed during login: {db_exc}")
            return Response({
                "error": "Cloud DB Server Unavailable. Please try again later or contact support.",
                "code": "db_unavailable"
            }, status=503)

    if not tenant.status:
        return Response({
            "error": "Account Inactive.",
            "code": "account_inactive",
        }, status=403)

    enc_pw = encrypt_password(password)
    user_auth_key = f"user_auth:{c_code_upper}:{u_name_upper}"
    cached_auth = None
    try:
        cached_auth = cache.get(user_auth_key)
    except Exception:
        pass

    user_info = None
    rights = None

    if cached_auth and isinstance(cached_auth, dict) and cached_auth.get("encrypted_password") == enc_pw:
        # ⚡ INSTANT MICRO-CACHE HIT (0.18 ms)
        user_info = cached_auth
        username = user_info["username"]
        designation = user_info["designation"]
        is_super_admin = user_info["is_super_admin"]
        password_expired = user_info.get("password_expired", False)
        password_age_days = user_info.get("password_age_days", 0)
        rights = dict(user_info.get("rights") or {})
        has_access = user_info.get("has_access", True)
    else:
        # ⚡ BATCHED SINGLE ROUND-TRIP SQL QUERY (User + Rights in 1 round-trip)
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT id, tenant_id, company_code, username, designation, issuperadmin, password_updated_at, created_at, password
                    FROM tenants_users 
                    WHERE company_code = %s AND UPPER(username) = UPPER(%s) AND deleted = 0;

                    SELECT form_name, access 
                    FROM tenants_usersrights 
                    WHERE company_code = %s AND UPPER(username) = UPPER(%s);
                    """,
                    [company_code, username, company_code, username]
                )
                user_row = cursor.fetchone()
                if not user_row:
                    return Response({"error": "Invalid username or password."}, status=401)
                
                if user_row[8] != enc_pw:
                    try:
                        cache.delete(user_auth_key)
                    except Exception:
                        pass
                    return Response({"error": "Invalid username or password."}, status=401)

                cursor.nextset()
                rights_rows = cursor.fetchall()
        except DatabaseError as db_exc:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Database error during user query: {db_exc}")
            return Response({
                "error": "Cloud DB Server Unavailable. Please try again later or contact support.",
                "code": "db_unavailable"
            }, status=503)

        # Use canonical username from DB (not typed input which may differ in case)
        username = user_row[3]
        designation = str(user_row[4] or "").strip()
        is_super_admin = (designation.lower() == "admin" or bool(user_row[5]))

        # Calculate password age in days
        ref_date = user_row[6] or user_row[7]
        password_age_days = 0
        import datetime
        if ref_date:
            if isinstance(ref_date, datetime.datetime):
                ref_date = ref_date.date()
            elif isinstance(ref_date, datetime.date):
                pass
            else:
                try:
                    ref_date = datetime.datetime.strptime(str(ref_date).split()[0], "%Y-%m-%d").date()
                except ValueError:
                    ref_date = None
            if ref_date:
                password_age_days = (datetime.date.today() - ref_date).days

        password_expired = (password_age_days >= 60)

        from .views_userrights import FORM_RIGHTS_KEYS
        rights = {key: False for key in FORM_RIGHTS_KEYS}
        if is_super_admin:
            for k in rights:
                rights[k] = True
        else:
            for r_row in rights_rows:
                f_name, acc = r_row[0], bool(r_row[1])
                if f_name in rights:
                    rights[f_name] = acc

        has_access = is_super_admin or any(rights.values())

        user_info = {
            "id": user_row[0],
            "tenant_id": user_row[1],
            "company_code": user_row[2],
            "username": username,
            "designation": designation,
            "is_super_admin": is_super_admin,
            "encrypted_password": user_row[8],
            "password_expired": password_expired,
            "password_age_days": password_age_days,
            "rights": rights,
            "has_access": has_access
        }
        try:
            cache.set(user_auth_key, user_info, timeout=1800)
        except Exception:
            pass

    # ERP Online check with extended 600s cache
    erp_online_key = f"erp_online:{c_code_upper}"
    is_erp_online = False
    try:
        is_erp_online = bool(cache.get(erp_online_key))
    except Exception:
        pass

    if not is_erp_online:
        try:
            check_tenant_erp_connection(
                tenant.erp_server,
                tenant.erp_database,
                tenant.erp_user,
                tenant.erp_password,
                tenant.erp_port,
            )
            try:
                cache.set(erp_online_key, True, timeout=600)  # Micro-cache for 10 minutes
            except Exception:
                pass
        except ErpConnectionError as exc:
            return Response(
                {"error": str(exc), "code": "erp_unavailable"},
                status=503,
            )

    request.session["tenant"] = {
        "tenant_id": tenant.id,
        "erp_server": tenant.erp_server, "erp_database": tenant.erp_database,
        "erp_user":   tenant.erp_user,   "erp_password": tenant.erp_password,
        "erp_port":   tenant.erp_port,   "company_code": tenant.company_code,
        "company_name": tenant.company_name,
        "username": username,
    }
    if request.session.get("is_admin_pannel_authenticated"):
        request.session["is_admin_pannel_authenticated"] = True
    request.session.modified = True
    request.session.save()
    new_session_key = request.session.session_key

    # ── Single Session Enforcement via Redis & Async DB Update ──
    user_active_session_key = f"user_active_session:{c_code_upper}:{u_name_upper}"
    try:
        old_session_key = cache.get(user_active_session_key)
        if old_session_key and old_session_key != new_session_key:
            try:
                cache.delete(f"django.contrib.sessions.cache{old_session_key}")
            except Exception:
                pass
        cache.set(user_active_session_key, new_session_key, timeout=86400)
    except Exception:
        pass

    # Offload database session record and audit logging to background thread pool
    def _async_login_tasks(t_id, c_code, u_name, s_key, s_name):
        from django.db import connection as async_conn
        try:
            with async_conn.cursor() as c:
                c.execute(
                    """
                    UPDATE tenants_userssession 
                    SET session_key = %s, system_name = %s, last_seen = GETUTCDATE(), created_at = GETUTCDATE() 
                    WHERE company_code = %s AND username = %s;

                    IF @@ROWCOUNT = 0
                    BEGIN
                        INSERT INTO tenants_userssession (tenant_id, company_code, username, session_key, system_name, last_seen, created_at)
                        VALUES (%s, %s, %s, %s, %s, GETUTCDATE(), GETUTCDATE());
                    END
                    """,
                    [s_key, s_name, c_code, u_name, t_id, c_code, u_name, s_key, s_name]
                )
                c.execute(
                    """
                    INSERT INTO tenants_clientactivity (tenant_id, company_code, activity_type, username, message, created_at)
                    VALUES (%s, %s, 'login', %s, 'logged in', GETUTCDATE());
                    INSERT INTO tenants_usersTransaction (tenant_id, company_code, username, module_name, created_at)
                    VALUES (%s, %s, %s, 'Login', GETUTCDATE());
                    """,
                    [t_id, c_code, u_name, t_id, c_code, u_name]
                )
        except Exception as ex:
            import logging
            logging.getLogger(__name__).warning(f"Background login tasks error: {ex}")

    _AUDIT_LOG_POOL.submit(_async_login_tasks, tenant.id, company_code, username, new_session_key, system_name)

    is_expired = is_plan_expired(company_code)
    license_info = get_tenant_license(company_code)
    rights = apply_license_restrictions_to_rights(rights, license_info)

    if rights.get("M-Approval"):
        try:
            from accounts.utils.mapproval_settings import check_mapproval_settings
            if not check_mapproval_settings(tenant):
                rights["M-Approval"] = False
        except Exception as e:
            print("[LOGIN] Warning checking M-Approval settings:", e)

    has_access = is_super_admin or any(rights.values())

    return Response({
        "message": "Login successful",
        "company": tenant.company_name,
        "company_code": tenant.company_code,
        "username": username,
        "designation": designation,
        "isSuperAdmin": is_super_admin,
        "rights": rights,
        "hasAccess": has_access,
        "isExpired": is_expired,
        "license": license_info,
        "passwordExpired": password_expired,
        "passwordAgeDays": password_age_days
    })


# ─────────────────────────────────────────────────────────────
#  LOGOUT
# ─────────────────────────────────────────────────────────────
@api_view(['POST'])
def logout_view(request):
    from django.db import connection
    tenant = request.session.get("tenant")
    if tenant:
        company_code = tenant.get("company_code")
        username = tenant.get("username")
        if company_code and username:
            try:
                with connection.cursor() as cursor:
                    cursor.execute(
                        "DELETE FROM tenants_userssession WHERE company_code = %s AND username = %s",
                        [company_code, username]
                    )
                    # Log disconnect activity to tenants_clientactivity
                    cursor.execute(
                        """
                        INSERT INTO tenants_clientactivity (tenant_id, company_code, activity_type, username, message, created_at)
                        VALUES (%s, %s, 'disconnect', %s, 'logged out', GETUTCDATE())
                        """,
                        [tenant.get("tenant_id"), company_code, username]
                    )
                    # Log to tenants_usersTransaction
                    cursor.execute(
                        """
                        INSERT INTO tenants_usersTransaction (tenant_id, company_code, username, module_name, created_at)
                        VALUES (%s, %s, %s, 'Logout', GETUTCDATE())
                        """,
                        [tenant.get("tenant_id"), company_code, username]
                    )
            except Exception:
                pass
    request.session.flush()
    return Response({"message": "Logout successful"}, status=200)


# ─────────────────────────────────────────────────────────────
#  HEARTBEAT  — keeps session alive while tab is open
#  Optimized for high concurrency (5,000 - 8,000 users):
#  1. Sets real-time presence in Redis (fast in-memory)
#  2. Throttles SQL table writes to at most once per 10 minutes per user
# ─────────────────────────────────────────────────────────────
@api_view(['GET'])
def heartbeat_view(request):
    from django.core.cache import cache
    from django.db import connection
    from .session_utils import get_or_restore_session_tenant
    try:
        tenant = get_or_restore_session_tenant(request, allow_expired=True)
    except ValueError as e:
        return Response({"ok": False, "code": "session_terminated", "error": str(e)}, status=401)

    if not tenant:
        return Response({"ok": False, "code": "no_session", "reason": "no_session"}, status=401)

    company_code = tenant.get("company_code")
    username = tenant.get("username")
    if not company_code or not username:
        return Response({"ok": True}, status=200)

    # 1. Update in-memory Redis presence key (real-time, sub-millisecond)
    presence_key = f"presence:{company_code}:{username}"
    cache.set(presence_key, True, timeout=360)

    # 2. Throttle persistent SQL updates to at most once per 10 minutes (600s) per user
    sync_key = f"presence_db_synced:{company_code}:{username}"
    if not cache.get(sync_key):
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "UPDATE tenants_userssession SET last_seen = GETUTCDATE() WHERE company_code = %s AND username = %s",
                    [company_code, username]
                )
            cache.set(sync_key, True, timeout=600)
        except Exception:
            pass

    return Response({"ok": True}, status=200)


# ─────────────────────────────────────────────────────────────
#  LOG USER TRANSACTION
#  Asynchronously records user module navigation in background pool
#  Returns in <2ms without blocking the client on remote DB insert
# ─────────────────────────────────────────────────────────────
from concurrent.futures import ThreadPoolExecutor

_AUDIT_LOG_POOL = ThreadPoolExecutor(max_workers=4, thread_name_prefix="audit_log_worker")

def _async_log_transaction_db(tenant_id, company_code, username, module_name):
    from django.db import connection, close_old_connections
    try:
        close_old_connections()
        with connection.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO tenants_usersTransaction (tenant_id, company_code, username, module_name, created_at)
                VALUES (%s, %s, %s, %s, GETUTCDATE())
                """,
                [tenant_id, company_code, username, module_name]
            )
    except Exception:
        pass
    finally:
        close_old_connections()


@api_view(['GET'])
def log_transaction(request):
    from .session_utils import get_or_restore_session_tenant
    try:
        tenant = get_or_restore_session_tenant(request, allow_expired=True)
    except ValueError:
        tenant = None

    if not tenant:
        return Response({"error": "Unauthorized"}, status=401)

    company_code = tenant.get("company_code")
    username = tenant.get("username")
    tenant_id = tenant.get("tenant_id")
    module_name = request.GET.get("module_name")

    if not module_name:
        return Response({"error": "module_name is required"}, status=400)

    # Dispatched to background pool — client gets immediate HTTP 200 response
    _AUDIT_LOG_POOL.submit(_async_log_transaction_db, tenant_id, company_code, username, module_name)
    return Response({"success": True}, status=200)


# ─────────────────────────────────────────────────────────────
#  COMPANY NAME LOOKUP & PUBLIC DIRECTORY
# ─────────────────────────────────────────────────────────────
@api_view(['GET'])
def public_companies_list(request):
    """
    Returns an ultra-fast in-memory map of active company codes to company names.
    Cached in Redis for 24 hours so frontend login can look up company names in 0ms.
    """
    from django.core.cache import cache
    cache_key = "public_companies_map"
    try:
        cached = cache.get(cache_key)
        if cached is not None:
            return Response(cached, status=200)
    except Exception:
        pass

    try:
        tenants = Tenant.objects.filter(status=True).only("company_code", "company_name")
        companies_map = {
            t.company_code.strip().upper(): t.company_name.strip()
            for t in tenants if t.company_code and t.company_name
        }
    except Exception as e:
        return Response({"error": str(e)}, status=500)

    try:
        cache.set(cache_key, companies_map, timeout=86400)  # 24 hours
    except Exception:
        pass

    return Response(companies_map, status=200)


@api_view(['GET'])
def get_company(request, code):
    code = (code or "").strip()
    if not code:
        return Response({"error": "Company code is required."}, status=400)

    from django.core.cache import cache
    code_upper = code.upper()
    cache_key = f"company_lookup:{code_upper}"
    include_signup = (request.GET.get("signup") or "").strip().lower() in ("1", "true", "yes")

    if not include_signup:
        try:
            cached = cache.get(cache_key)
            if cached is not None:
                if cached.get("code") == "account_inactive":
                    return Response(cached, status=403)
                return Response(cached, status=200)
        except Exception:
            pass

    try:
        tenant = Tenant.objects.only("company_code", "company_name", "status").get(
            company_code__iexact=code
        )
    except Tenant.DoesNotExist:  # type: ignore
        return Response({"error": "Company not found."}, status=404)

    if not tenant.status:
        err_payload = {
            "error": "Account Inactive.",
            "code": "account_inactive",
            "company_name": tenant.company_name,
            "company_code": tenant.company_code,
        }
        try:
            cache.set(cache_key, err_payload, timeout=3600)
        except Exception:
            pass
        return Response(err_payload, status=403)

    payload = {
        "company_name": tenant.company_name,
        "company_code": tenant.company_code,
    }

    if include_signup:
        from django.db import connection
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT COUNT(1) FROM tenants_signup WHERE UPPER(company_code) = UPPER(%s) OR UPPER(company_name) = UPPER(%s)",
                [tenant.company_code, tenant.company_name]
            )
            payload["already_registered"] = cursor.fetchone()[0] > 0
    else:
        try:
            cache.set(cache_key, payload, timeout=86400)
        except Exception:
            pass

    return Response(payload)

# ─────────────────────────────────────────────────────────────
#  CHARTS - SABARISH (Monthwise Charts)
# ─────────────────────────────────────────────────────────────
@api_view(['GET'])
def po_vs_sales(request):
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)
        
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    
    sql = """
    WITH SHD_PO_DET AS
    (
        SELECT DISTINCT
            S.Apono,
            S.pono,
            S.itcode,
            S.poslno
        FROM In_PoDet_ShdQty S
        WHERE ISNULL(S.deleted, 0) = 0
    ),
    PO_DATA AS
    (
        /* 1. PO items WITH Schedule Date (from In_PoDet_ShdQty) */
        SELECT
            YEAR(ISNULL(S.shddate, ISNULL(S.reqdate, PM.PODT))) AS POYear,
            MONTH(ISNULL(S.shddate, ISNULL(S.reqdate, PM.PODT))) AS POMonth,
            CAST(ISNULL(S.shddate, ISNULL(S.reqdate, PM.PODT)) AS DATE) AS PODate,
            PM.Apono,
            PD.ItCode,
            SUM(ISNULL(S.shdQty, 0) * ISNULL(PD.Rate, 0)) AS POValue
        FROM In_PoMas PM
        INNER JOIN In_PoDet PD
            ON PM.PONO = PD.PONO
        INNER JOIN In_PoDet_ShdQty S
            ON (S.Apono = PM.Apono OR S.pono = PM.PONO)
           AND S.itcode = PD.ItCode
           AND S.poslno = PD.poslno
        WHERE PM.Deleted = 0
          AND PD.Deleted = 0
          AND ISNULL(S.deleted, 0) = 0
        GROUP BY
            YEAR(ISNULL(S.shddate, ISNULL(S.reqdate, PM.PODT))),
            MONTH(ISNULL(S.shddate, ISNULL(S.reqdate, PM.PODT))),
            CAST(ISNULL(S.shddate, ISNULL(S.reqdate, PM.PODT)) AS DATE),
            PM.Apono,
            PD.ItCode

        UNION ALL

        /* 2. PO items WITHOUT Schedule (fallback to PO Date and Amt) */
        SELECT
            YEAR(PM.PODT) AS POYear,
            MONTH(PM.PODT) AS POMonth,
            CAST(PM.PODT AS DATE) AS PODate,
            PM.Apono,
            PD.ItCode,
            SUM(ISNULL(PD.Amt, 0)) AS POValue
        FROM In_PoMas PM
        INNER JOIN In_PoDet PD
            ON PM.PONO = PD.PONO
        LEFT JOIN SHD_PO_DET SPD
            ON (SPD.Apono = PM.Apono OR SPD.pono = PM.PONO)
           AND SPD.itcode = PD.ItCode
           AND SPD.poslno = PD.poslno
        WHERE PM.Deleted = 0
          AND PD.Deleted = 0
          AND SPD.itcode IS NULL
        GROUP BY
            YEAR(PM.PODT),
            MONTH(PM.PODT),
            CAST(PM.PODT AS DATE),
            PM.Apono,
            PD.ItCode
    ),
    PO_RATE AS
    (
        SELECT
            LTRIM(RTRIM(CAST(PM.Apono  AS NVARCHAR(512)))) AS Apono,
            LTRIM(RTRIM(CAST(PD.ItCode AS NVARCHAR(512)))) AS ItCode,
            MAX(ISNULL(PD.Rate, 0))                        AS Rate
        FROM In_PoMas PM
        INNER JOIN In_PoDet PD ON PD.PONO = PM.PONO AND PD.Deleted = 0
        WHERE PM.Deleted = 0
        GROUP BY
            LTRIM(RTRIM(CAST(PM.Apono  AS NVARCHAR(512)))),
            LTRIM(RTRIM(CAST(PD.ItCode AS NVARCHAR(512))))
    ),
    DC_SALES AS
    (
        SELECT
            LTRIM(RTRIM(CAST(D.Apono  AS NVARCHAR(512)))) AS Apono,
            LTRIM(RTRIM(CAST(D.PartNo AS NVARCHAR(512)))) AS PartNo,
            SUM(ISNULL(D.okqty, 0) * ISNULL(R.Rate, 0))  AS SalesValue
        FROM DcInSubDet D
        LEFT JOIN PO_RATE R
            ON  R.Apono  = LTRIM(RTRIM(CAST(D.Apono  AS NVARCHAR(512))))
            AND R.ItCode = LTRIM(RTRIM(CAST(D.PartNo AS NVARCHAR(512))))
        WHERE ISNULL(D.Deleted, 0) = 0
        GROUP BY
            LTRIM(RTRIM(CAST(D.Apono  AS NVARCHAR(512)))),
            LTRIM(RTRIM(CAST(D.PartNo AS NVARCHAR(512))))

        UNION ALL

        SELECT
            LTRIM(RTRIM(CAST(D.Apono  AS NVARCHAR(512)))) AS Apono,
            LTRIM(RTRIM(CAST(D.PartNo AS NVARCHAR(512)))) AS PartNo,
            SUM(ISNULL(D.okqty, 0) * ISNULL(R.Rate, 0))  AS SalesValue
        FROM DcInSubDetAssmPoDet D
        LEFT JOIN PO_RATE R
            ON  R.Apono  = LTRIM(RTRIM(CAST(D.Apono  AS NVARCHAR(512))))
            AND R.ItCode = LTRIM(RTRIM(CAST(D.PartNo AS NVARCHAR(512))))
        WHERE ISNULL(D.Deleted, 0) = 0
        GROUP BY
            LTRIM(RTRIM(CAST(D.Apono  AS NVARCHAR(512)))),
            LTRIM(RTRIM(CAST(D.PartNo AS NVARCHAR(512))))
    ),
    SALES_DATA AS
    (
        SELECT Apono, PartNo, SUM(SalesValue) AS SalesValue
        FROM DC_SALES
        GROUP BY Apono, PartNo
    )
    SELECT
        P.POYear,
        P.POMonth,
        SUM(P.POValue) AS POValue,
        SUM(
            CASE
                WHEN ISNULL(S.SalesValue, 0) > P.POValue THEN P.POValue
                ELSE ISNULL(S.SalesValue, 0)
            END
        ) AS SalesValue
    FROM PO_DATA P
    LEFT JOIN SALES_DATA S
        ON  S.Apono  = LTRIM(RTRIM(CAST(P.Apono  AS NVARCHAR(512))))
       AND  S.PartNo = LTRIM(RTRIM(CAST(P.ItCode AS NVARCHAR(512))))
    WHERE P.PODate BETWEEN ? AND ?
    GROUP BY
        P.POYear,
        P.POMonth;
    """
    
    sales_map = {b: 0.0 for b in buckets}
    po_map = {b: 0.0 for b in buckets}
    
    cursor = None
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (start_date, end_date))
        for row in cursor.fetchall() or []:
            yr, mth = int(row[0] or 0), int(row[1] or 0)
            po_val = float(row[2] or 0) / 100_000.0
            sales_val = float(row[3] or 0) / 100_000.0
            k = (yr, mth)
            if k in po_map:
                po_map[k] = round(po_val, 2)
            if k in sales_map:
                sales_map[k] = round(sales_val, 2)
        cursor.close()
        conn.close()
    except Exception as e:
        if cursor:
            try: cursor.close()
            except Exception: pass
        try: conn.close()
        except Exception: pass
        return Response({"error": f"Database error: {str(e)}"}, status=500)
        
    return Response({
        "company": tenant.get("company_name", ""),
        "fy": fy_label,
        "from": str(start_date),
        "to": str(end_date),
        "labels": labels,
        "sales": [sales_map[b] for b in buckets],
        "po": [po_map[b] for b in buckets]
    })

@api_view(['GET'])
def customer_complaints(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT YEAR(CmpDate) AS yr, MONTH(CmpDate) AS month_num, COUNT(*) AS cnt FROM CustCompMas WHERE CmpDate IS NOT NULL AND CAST(CmpDate AS DATE) BETWEEN ? AND ? AND ISNULL(Deleted, 0) = 0 GROUP BY YEAR(CmpDate), MONTH(CmpDate)", (start_date, end_date))
        rows = cursor.fetchall(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    counts = {b: 0 for b in buckets}
    for yr, month_num, cnt in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in counts: counts[k] = int(cnt or 0)
    return Response({"company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "labels": labels, "data": [counts[b] for b in buckets]})

@api_view(['GET'])
def rejection_monthwise(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        sql = """
        SELECT YrNum, MonthNum, SUM(RejQty) as TotalRej FROM (
            SELECT YEAR(finspdate) as YrNum, MONTH(finspdate) as MonthNum, CAST(ISNULL(rejqty, 0) AS FLOAT) as RejQty FROM FinalInspectionEntry WHERE deleted = 0 AND CAST(finspdate AS DATE) BETWEEN ? AND ? AND rejqty > 0
            UNION ALL SELECT YEAR(inter_inspdate) as YrNum, MONTH(inter_inspdate) as MonthNum, CAST(ISNULL(rejqty, 0) AS FLOAT) as RejQty FROM InterInspectionEntry WHERE deleted = 0 AND CAST(inter_inspdate AS DATE) BETWEEN ? AND ? AND rejqty > 0
            UNION ALL SELECT YEAR(m.inspdate) as YrNum, MONTH(m.inspdate) as MonthNum, CAST(ISNULL(d.matrej, 0) + ISNULL(d.macrej, 0) AS FLOAT) as RejQty FROM InJob_Det d INNER JOIN InJob_Mas m ON d.inspno = m.inspno WHERE m.deleted = 0 AND d.deleted = 0 AND CAST(m.inspdate AS DATE) BETWEEN ? AND ? AND (ISNULL(d.matrej, 0) > 0 OR ISNULL(d.macrej, 0) > 0)
        ) as CombinedData GROUP BY YrNum, MonthNum ORDER BY YrNum, MonthNum"""
        params = [start_date, end_date, start_date, end_date, start_date, end_date]
        cursor.execute(sql, params); rows = cursor.fetchall(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    counts = {b: 0 for b in buckets}
    for yr, month_num, cnt in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in counts: counts[k] = int(cnt or 0)
    return Response({"company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "labels": labels, "data": [counts[b] for b in buckets]})

@api_view(['GET'])
def rework_monthwise(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        sql = """
        SELECT YrNum, MonthNum, SUM(ReworkQty) as TotalRework FROM (
            SELECT YEAR(finspdate) as YrNum, MONTH(finspdate) as MonthNum, CAST(ISNULL(matrejqty, 0) AS FLOAT) as ReworkQty FROM FinalInspectionEntry WHERE deleted = 0 AND CAST(finspdate AS DATE) BETWEEN ? AND ? AND matrejqty > 0
            UNION ALL SELECT YEAR(inter_inspdate) as YrNum, MONTH(inter_inspdate) as MonthNum, CAST(ISNULL(rwqty, 0) AS FLOAT) as ReworkQty FROM InterInspectionEntry WHERE deleted = 0 AND CAST(inter_inspdate AS DATE) BETWEEN ? AND ? AND rwqty > 0
            UNION ALL SELECT YEAR(m.inspdate) as YrNum, MONTH(m.inspdate) as MonthNum, CAST(ISNULL(d.rwqty, 0) AS FLOAT) as ReworkQty FROM InJob_Det d INNER JOIN InJob_Mas m ON d.inspno = m.inspno WHERE m.deleted = 0 AND d.deleted = 0 AND CAST(m.inspdate AS DATE) BETWEEN ? AND ? AND d.rwqty > 0
        ) as CombinedData GROUP BY YrNum, MonthNum ORDER BY YrNum, MonthNum"""
        params = [start_date, end_date, start_date, end_date, start_date, end_date]
        cursor.execute(sql, params); rows = cursor.fetchall(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    counts = {b: 0 for b in buckets}
    for yr, month_num, cnt in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in counts: counts[k] = int(cnt or 0)
    return Response({"company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "labels": labels, "data": [counts[b] for b in buckets]})

@api_view(['GET'])
def mac_rejection_ppm(request):
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)
        
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    
    ppm_sql = """
    SELECT
        YEAR(InspDate) AS YrNum,
        MONTH(InspDate) AS MonthNum,
        SUM(InspQty)    AS TotalInspQty,
        SUM(MacRejQty)  AS TotalMacRejQty
    FROM (
        SELECT
            m.inspdate AS InspDate,
            CAST(ISNULL(d.jobqty, 0) AS INT) AS InspQty,
            CAST(ISNULL(d.macrej, 0) AS INT) AS MacRejQty
        FROM InJob_Mas m
        INNER JOIN InJob_Det d ON m.inspno = d.inspno
        WHERE ISNULL(m.deleted, 0) = 0 AND ISNULL(d.deleted, 0) = 0
          AND CAST(m.inspdate AS DATE) BETWEEN ? AND ?

        UNION ALL

        SELECT
            inter_inspdate AS InspDate,
            CAST(ISNULL(inspqty, 0) AS INT) AS InspQty,
            CAST(ISNULL(rejqty, 0) AS INT) AS MacRejQty
        FROM InterInspectionEntry
        WHERE ISNULL(deleted, 0) = 0
          AND CAST(inter_inspdate AS DATE) BETWEEN ? AND ?

        UNION ALL

        SELECT
            finspdate AS InspDate,
            CAST(ISNULL(totqty, 0) AS INT) AS InspQty,
            CAST(ISNULL(rejqty, 0) AS INT) AS MacRejQty
        FROM FinalInspectionEntry
        WHERE ISNULL(deleted, 0) = 0
          AND CAST(finspdate AS DATE) BETWEEN ? AND ?
    ) AS CombinedPPM
    GROUP BY YEAR(InspDate), MONTH(InspDate)
    """
    
    insp_map = {b: 0.0 for b in buckets}
    rej_map = {b: 0.0 for b in buckets}
    
    cursor = None
    try:
        cursor = conn.cursor()
        cursor.execute(ppm_sql, [start_date, end_date, start_date, end_date, start_date, end_date])
        for row in cursor.fetchall() or []:
            yr, month_num = int(row[0] or 0), int(row[1] or 0)
            total_insp = float(row[2] or 0)
            total_rej = float(row[3] or 0)
            k = (yr, month_num)
            if k in insp_map:
                insp_map[k] += total_insp
                rej_map[k] += total_rej
        cursor.close()
        conn.close()
    except Exception as e:
        if cursor:
            try: cursor.close()
            except Exception: pass
        try: conn.close()
        except Exception: pass
        return Response({"error": f"Database error: {str(e)}"}, status=500)
        
    ppm_map = {b: 0.0 for b in buckets}
    for b in buckets:
        ppm_map[b] = round((rej_map[b] / insp_map[b]) * 1_000_000, 2) if insp_map[b] > 0 else 0.0
        
    return Response({
        "company": tenant.get("company_name", ""),
        "fy": fy_label,
        "from": str(start_date),
        "to": str(end_date),
        "labels": labels,
        "data": [ppm_map[b] for b in buckets]
    })

# ─────────────────────────────────────────────────────────────
#  PURCHASE - MONTHWISE TYPE REPORT & SUPPLIER RATING
# ─────────────────────────────────────────────────────────────
@api_view(['GET'])
def purchase_report_monthwise(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        sql = """
        SELECT YEAR(podate) AS yr, MONTH(podate) AS month_num, LTRIM(RTRIM(ISNULL(dtype, ''))) AS dtype, SUM(ISNULL(totamt, 0)) AS total_amount
        FROM POMas
        WHERE deleted = 0 AND CAST(podate AS DATE) BETWEEN ? AND ? AND ISNULL(dtype, '') <> 'Job Order'
        GROUP BY YEAR(podate), MONTH(podate), LTRIM(RTRIM(ISNULL(dtype, '')))
        ORDER BY yr, month_num
        """
        cursor.execute(sql, (start_date, end_date))
        rows = cursor.fetchall(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    raw_map = {b: 0.0 for b in buckets}
    store_map = {b: 0.0 for b in buckets}
    gen_map = {b: 0.0 for b in buckets}
    for yr, month_num, dtype, amount in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k not in raw_map: continue
        amt = float(amount or 0) / 100_000
        dtype_lower = dtype.lower().strip()
        if 'raw' in dtype_lower or dtype_lower == 'raw material':
            raw_map[k] += amt
        elif 'store' in dtype_lower:
            store_map[k] += amt
        else:
            gen_map[k] += amt
    return Response({
        "company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "labels": labels,
        "raw_material": [round(raw_map[b], 2) for b in buckets], "store_material": [round(store_map[b], 2) for b in buckets], "general_service": [round(gen_map[b], 2) for b in buckets]
    })

# ✅ Supplier / Vendor Rating API for Charts screen (Monthwise & Vendor-Filtered)
@api_view(['GET'])
def supplier_rating_monthwise(request):
    """
    Plant Performance / Charts — Vendor/Supplier Rating Report (Monthwise & Filtered).
    Uses Job-based logic for Vendors, and PO/GRN/Inspection-based logic for Suppliers.
    Returns dynamic monthwise trend for overall vendors/suppliers or filtered by name.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    name_filter = (request.GET.get("name") or request.GET.get("vendor") or "").strip()
    entity_type = (request.GET.get("type") or "vendor").strip().lower()

    buckets, labels = generate_month_buckets(start_date, end_date)
    rating_map: dict = {b: None for b in buckets}

    cursor = None
    try:
        cursor = conn.cursor()
        if entity_type == "supplier":
            from .views_plantperformance import get_supplier_rating_base_cte
            cte = get_supplier_rating_base_cte()
            for yr, mo in buckets:
                m_start = date(yr, mo, 1)
                _, last_day = monthrange(yr, mo)
                m_end = date(yr, mo, last_day)

                params: list = [m_start, m_end, m_start, m_end]
                extra_where = ""
                if name_filter:
                    suppliers = [s.strip() for s in name_filter.split(",") if s.strip()]
                    if suppliers:
                        placeholders = ",".join(["?"] * len(suppliers))
                        extra_where = f" AND ss.SupplierName IN ({placeholders})"
                        params.extend(suppliers)

                sql = f"""
                {cte}
                SELECT ROUND(AVG(CAST(ss.TotalSupplierRating AS FLOAT)), 2) AS AvgFinalRating
                FROM SupplierSummary ss
                WHERE 1=1 {extra_where};
                """
                try:
                    cursor.execute(sql, params)
                    row = cursor.fetchone()
                    if row and row[0] is not None:
                        rating_map[(yr, mo)] = round(float(row[0]), 2)
                except Exception:
                    pass
        else:
            for yr, mo in buckets:
                m_start = date(yr, mo, 1)
                _, last_day = monthrange(yr, mo)
                m_end = date(yr, mo, last_day)

                sql = """
                DECLARE @FromDate DATE = ?;
                DECLARE @ToDate   DATE = ?;

                ;WITH JobQuality AS (
                    SELECT
                        jm.jbno,
                        jm.cid,
                        jm.expdate,
                        SUM(ji.Qty)                                                    AS ReceivedQty,
                        SUM(ji.Qty - ISNULL(ji.RejQty,0) - ISNULL(ji.RwQty,0))       AS AcceptedQty,
                        SUM(ISNULL(ji.RejQty,0))                                       AS RejectedQty
                    FROM Job_mas jm
                    INNER JOIN JobIncomeDetInsp ji ON ji.JbNo = jm.jbno
                    INNER JOIN CustMast cm ON cm.Id = jm.cid
                    WHERE jm.deleted = 0
                      AND jm.cid LIKE 'V%'
                      AND CAST(jm.jbdate AS DATE) BETWEEN @FromDate AND @ToDate
                      AND (? = '' OR cm.CName = ?)
                    GROUP BY jm.jbno, jm.cid, jm.expdate
                ),
                JobDelivery AS (
                    SELECT
                        jq.jbno,
                        jq.cid,
                        jq.expdate,
                        jq.ReceivedQty,
                        jq.AcceptedQty,
                        jq.RejectedQty,
                        jd_dc.LastDcDate,
                        CASE
                            WHEN jd_dc.LastDcDate IS NOT NULL AND jd_dc.LastDcDate <= jq.expdate THEN 'ONTIME'
                            WHEN jq.expdate < CAST(GETDATE() AS DATE) THEN 'DELAY'
                            ELSE 'PENDING'
                        END AS DeliveryBucket
                    FROM JobQuality jq
                    OUTER APPLY (
                        SELECT MAX(im.dcdate) AS LastDcDate
                        FROM JobIncomeDetInsp ji
                        INNER JOIN InJob_Mas im ON im.jino = ji.JiNo
                        WHERE ji.JbNo = jq.jbno
                    ) jd_dc
                ),
                VendorAgg AS (
                    SELECT
                        SUM(jd.ReceivedQty)                                                AS TotalReceived,
                        SUM(jd.AcceptedQty)                                                AS TotalAccepted,
                        SUM(jd.RejectedQty)                                                AS TotalRejected,
                        COUNT(*)                                                            AS JobOrdersProduced,
                        SUM(CASE WHEN jd.DeliveryBucket = 'ONTIME'  THEN 1 ELSE 0 END)    AS OnTimeJobs,
                        SUM(CASE WHEN jd.DeliveryBucket = 'DELAY'   THEN 1 ELSE 0 END)    AS DelayJobs,
                        SUM(CASE WHEN jd.DeliveryBucket = 'PENDING' THEN 1 ELSE 0 END)    AS PendingJobs
                    FROM JobDelivery jd
                ),
                VendorScored AS (
                    SELECT
                        va.*,
                        CASE WHEN va.TotalReceived = 0 THEN NULL
                             ELSE (va.TotalAccepted * 100.0) / va.TotalReceived
                        END AS AcceptancePct,
                        CASE WHEN (va.JobOrdersProduced - va.PendingJobs) = 0 THEN NULL
                             ELSE (va.OnTimeJobs * 100.0) / (va.JobOrdersProduced - va.PendingJobs)
                        END AS OnTimeDeliveryPct
                    FROM VendorAgg va
                ),
                VendorGraded AS (
                    SELECT
                        ( ISNULL(qr.RatingFor, 0) + ISNULL(dr.RatingFor, 0) ) / 2.0 AS TotalRating
                    FROM VendorScored vs
                    LEFT JOIN QualityRating qr
                           ON qr.dtype = 'Vendor'
                          AND vs.AcceptancePct IS NOT NULL
                          AND vs.AcceptancePct BETWEEN qr.RatingFrom AND qr.RatingTo
                    LEFT JOIN DeliveryRating dr
                           ON dr.dtype = 'Vendor'
                          AND vs.OnTimeDeliveryPct IS NOT NULL
                          AND vs.OnTimeDeliveryPct BETWEEN dr.RatingFrom AND dr.RatingTo
                )
                SELECT ROUND(AVG(vg.TotalRating), 2) AS [TOTAL RATING]
                FROM VendorGraded vg
                WHERE vg.TotalRating IS NOT NULL;
                """
                try:
                    cursor.execute(sql, [m_start, m_end, name_filter, name_filter])
                    row = cursor.fetchone()
                    if row and row[0] is not None:
                        rating_map[(yr, mo)] = round(float(row[0]), 2)
                except Exception:
                    pass

        chart_data = [rating_map[b] for b in buckets]

        # Fetch distinct names for filter dropdown based on entity type
        if entity_type == "supplier":
            cursor.execute(
                "SELECT DISTINCT LTRIM(RTRIM(ISNULL(ca.CName, cm.CName))) FROM CustMast cm "
                "LEFT JOIN CustAliasMast ca ON ca.Id = cm.Id "
                "WHERE cm.CName IS NOT NULL AND cm.CName <> '' AND cm.Id LIKE 'S%' "
                "ORDER BY LTRIM(RTRIM(ISNULL(ca.CName, cm.CName)))"
            )
        else:
            cursor.execute(
                "SELECT DISTINCT LTRIM(RTRIM(cm.CName)) FROM CustMast cm "
                "WHERE cm.CName IS NOT NULL AND cm.CName <> '' AND cm.Id LIKE 'V%' "
                "ORDER BY LTRIM(RTRIM(cm.CName))"
            )
        all_names = [str(r[0]).strip() for r in cursor.fetchall() if r[0]]
        if not all_names:
            cursor.execute(
                "SELECT DISTINCT LTRIM(RTRIM(ISNULL(ca.CName, cm.CName))) FROM CustMast cm "
                "LEFT JOIN CustAliasMast ca ON ca.Id = cm.Id "
                "WHERE cm.CName IS NOT NULL AND cm.CName <> '' AND (cm.Id LIKE 'V%' OR cm.Id LIKE 'S%') "
                "ORDER BY LTRIM(RTRIM(ISNULL(ca.CName, cm.CName)))"
            )
            all_names = [str(r[0]).strip() for r in cursor.fetchall() if r[0]]

        fy_label = get_fy_label(start_date, end_date)

        return Response({
            "company": tenant.get("company_name", ""),
            "fy":      fy_label,
            "from":    str(start_date),
            "to":      str(end_date),
            "labels":  labels,
            "data":    chart_data,
            "vendors": all_names,
            "selectedVendor": name_filter,
            "filterOptions": {
                "vendors": all_names,
            },
        })
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        conn.close()
        
# ─────────────────────────────────────────────────────────────
#  VENDOR - REJECTION MONTHWISE
# ─────────────────────────────────────────────────────────────
@api_view(['GET'])
def vendor_rejection_monthwise(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    cursor = None
    try:
        cursor = conn.cursor()
        sch_gm, nm_gm, q_gm = resolve_erp_table(cursor, ["grn_mas", "GRN_MAS", "Grn_Mas", "GrnMas", "GRNMast", "grnmast"])
        sch_im, nm_im, q_im = resolve_erp_table(cursor, ["inspmas", "InspMas", "INSPMAS", "Insp_Mas", "InspMas"])
        sch_id, nm_id, q_id = resolve_erp_table(cursor, ["inspdet", "InspDet", "INSPDET", "Insp_Det", "InspDet"])
        sch_cm, nm_cm, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST"])
        if not q_gm or not q_im or not q_id:
            cursor.close(); conn.close()
            return Response({"error": "grn_mas, inspmas, or inspdet table not found."}, status=404)
        gm_grn = find_column_ci(cursor, sch_gm, nm_gm, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        gm_date = find_column_ci(cursor, sch_gm, nm_gm, ["grndate", "GRNDate", "GRNDATE", "Grn_Date"])
        gm_del = find_column_ci(cursor, sch_gm, nm_gm, ["deleted", "Deleted", "IsDeleted"])
        gm_cid = find_column_ci(cursor, sch_gm, nm_gm, ["cid", "CId", "CID", "CustId", "custid"])
        im_grn = find_column_ci(cursor, sch_im, nm_im, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        im_irno = find_column_ci(cursor, sch_im, nm_im, ["irno", "IRNo", "IRNO", "IrNo", "InspNo"])
        im_irdate = find_column_ci(cursor, sch_im, nm_im, ["irdate", "IRDate", "IRDATE", "Ir_Date", "InspDate", "inspdate"])
        im_del = find_column_ci(cursor, sch_im, nm_im, ["deleted", "Deleted", "IsDeleted"])
        d_irno = find_column_ci(cursor, sch_id, nm_id, ["irno", "IRNo", "IRNO", "IrNo"])
        d_del = find_column_ci(cursor, sch_id, nm_id, ["deleted", "Deleted", "IsDeleted"])
        d_matrej = find_column_ci(cursor, sch_id, nm_id, ["matrej", "MatRej", "MATREJ", "Mat_Rej", "mat_rej"])
        d_macrej = find_column_ci(cursor, sch_id, nm_id, ["macrej", "MacRej", "MACREJ", "Mac_Rej", "mac_rej"])
        if not gm_grn or not gm_date or not im_grn or not im_irno or not im_irdate or not d_irno or not d_matrej or not d_macrej:
            cursor.close(); conn.close()
            return Response({"error": "Required columns not found for vendor rejections."}, status=500)
        mat_e = f"ISNULL(CAST(D.[{d_matrej}] AS FLOAT), 0)" if d_matrej else "CAST(0 AS FLOAT)"
        mac_e = f"ISNULL(CAST(D.[{d_macrej}] AS FLOAT), 0)" if d_macrej else "CAST(0 AS FLOAT)"
        rej_sum = f"({mat_e} + {mac_e})"
        rej_filter = f"({mat_e} > 0 OR {mac_e} > 0)"
        gm_del_sql = f"ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else "1=1"
        im_del_sql = f"ISNULL(IM.[{im_del}], 0) = 0" if im_del else "1=1"
        join_d_del = f" AND ISNULL(D.[{d_del}], 0) = 0" if d_del else ""
        cm_join = ""
        vendor_sql = "CAST(NULL AS NVARCHAR(512))"
        if q_cm and gm_cid:
            cm_id = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId", "custid"])
            cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName", "Name"])
            cm_del = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"])
            if cm_id and cm_name:
                cm_del_x = f" AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
                cm_join = f"LEFT JOIN {q_cm} CM ON GM.[{gm_cid}] = CM.[{cm_id}]{cm_del_x}"
                vendor_sql = f"CAST(CM.[{cm_name}] AS NVARCHAR(512))"
        vendor_expr = "N'Unknown'" if vendor_sql.strip().upper().startswith("CAST(NULL") else f"LTRIM(RTRIM(ISNULL({vendor_sql}, N'Unknown')))"
        base_from = f"""FROM {q_gm} GM INNER JOIN {q_im} IM ON GM.[{gm_grn}] = IM.[{im_grn}] AND {im_del_sql} INNER JOIN {q_id} D ON IM.[{im_irno}] = D.[{d_irno}]{join_d_del} {cm_join}"""
        date_where = f"""CAST(IM.[{im_irdate}] AS DATE) BETWEEN ? AND ? AND {gm_del_sql} AND {rej_filter}"""
        agg_sql = f"""
        SELECT
            YEAR(IM.[{im_irdate}]) AS YrNum,
            MONTH(IM.[{im_irdate}]) AS MonthNum,
            {vendor_expr} AS VendorName,
            SUM(CAST({rej_sum} AS FLOAT)) AS TotalRej
            {base_from}
            WHERE {date_where}
            GROUP BY YEAR(IM.[{im_irdate}]), MONTH(IM.[{im_irdate}]), {vendor_expr}
            ORDER BY 3, 1, 2
        """
        params = [start_date, end_date]
        cursor.execute(agg_sql, params)
        rows = cursor.fetchall()
        if not rows:
            injob_sql_both = """
            SELECT YEAR(M.inspdate) AS YrNum, MONTH(M.inspdate) AS MonthNum, LTRIM(RTRIM(ISNULL(C.CName, N'Unknown'))) AS VendorName, SUM(CAST(ISNULL(D.macrej, 0) AS FLOAT) + CAST(ISNULL(D.matrej, 0) AS FLOAT)) AS TotalRej FROM InJob_Det D INNER JOIN InJob_Mas M ON D.inspno = M.inspno LEFT JOIN CustMast C ON M.cid = C.Id WHERE ISNULL(D.deleted, 0) = 0 AND CAST(M.inspdate AS DATE) BETWEEN ? AND ? AND (CAST(ISNULL(D.macrej, 0) AS FLOAT) > 0 OR CAST(ISNULL(D.matrej, 0) AS FLOAT) > 0) GROUP BY YEAR(M.inspdate), MONTH(M.inspdate), LTRIM(RTRIM(ISNULL(C.CName, N'Unknown'))) ORDER BY 3, 1, 2
            """
            try:
                cursor.execute(injob_sql_both, [start_date, end_date])
                rows = cursor.fetchall()
            except Exception:
                rows = []
        cursor.close(); conn.close()
    except Exception as e:
        if cursor:
            try: cursor.close()
            except Exception: pass
        if conn:
            try: conn.close()
            except Exception: pass
        return Response({"error": f"Database error: {str(e)}"}, status=500)
    vendor_data = {}
    for yr, month_num, vendor_name, total_rej in rows:
        vkey = str(vendor_name).strip() if vendor_name is not None else "Unknown"
        if not vkey: vkey = "Unknown"
        if vkey not in vendor_data: vendor_data[vkey] = {b: 0.0 for b in buckets}
        k = (int(yr or 0), int(month_num or 0))
        if k in vendor_data[vkey]: vendor_data[vkey][k] += float(total_rej or 0)
    palette = [{"border": "#3b82f6", "bg": "rgba(59,130,246,0.06)"}, {"border": "#f97316", "bg": "rgba(249,115,22,0.06)"}, {"border": "#10b981", "bg": "rgba(16,185,129,0.06)"}, {"border": "#8b5cf6", "bg": "rgba(139,92,246,0.06)"}, {"border": "#ec4899", "bg": "rgba(236,72,153,0.06)"}, {"border": "#06b6d4", "bg": "rgba(6,182,212,0.06)"}, {"border": "#f43f5e", "bg": "rgba(244,63,94,0.06)"}]
    formatted_datasets = []
    for i, (vname, vdata) in enumerate(vendor_data.items()):
        c = palette[i % len(palette)]
        formatted_datasets.append({"label": vname, "data": [round(vdata.get(b, 0), 2) for b in buckets], "borderColor": c["border"], "backgroundColor": c["bg"], "tension": 0.4, "fill": False, "pointRadius": 2, "pointHoverRadius": 4, "borderWidth": 1.5})
    return Response({"company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "labels": labels, "datasets": formatted_datasets})

# ─────────────────────────────────────────────────────────────
#  OPERATIONS - OVERALL EFFICIENCY
# ─────────────────────────────────────────────────────────────
@api_view(['GET'])
def overall_efficiency_monthwise(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        sql = """SELECT YEAR(dt) AS YrNum, MONTH(dt) AS MonthNum, AVG(CAST(OAEFF AS FLOAT)) AS Avg_OAEFF FROM (SELECT proddate AS dt, OAEFF FROM ProductionEntry WHERE CAST(proddate AS DATE) BETWEEN ? AND ? AND deleted = 0 AND OAEFF IS NOT NULL UNION ALL SELECT entrydate AS dt, OAEFF FROM ConvProductionEntry WHERE CAST(entrydate AS DATE) BETWEEN ? AND ? AND deleted = 0 AND OAEFF IS NOT NULL UNION ALL SELECT entrydate AS dt, OAEFF FROM ConvProductionEntryRod WHERE CAST(entrydate AS DATE) BETWEEN ? AND ? AND deleted = 0 AND OAEFF IS NOT NULL) AS X GROUP BY YEAR(dt), MONTH(dt) ORDER BY YEAR(dt), MONTH(dt)"""
        params = [start_date, end_date, start_date, end_date, start_date, end_date]
        cursor.execute(sql, params); rows = cursor.fetchall(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    eff_map = {b: 0.0 for b in buckets}
    for yr, month_num, avg_eff in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in eff_map: eff_map[k] = round(float(avg_eff or 0), 2)
    return Response({"company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "labels": labels, "data": [eff_map[b] for b in buckets]})

# ─────────────────────────────────────────────────────────────
#  PRODUCTION - OPERATOR EFFICIENCY & MACHINE IDLE TIME & MACHINE EFFICIENCY
# ─────────────────────────────────────────────────────────────
def _sql_deleted_safe(del_col):
    if not del_col:
        return "1=1"
    return f"ISNULL(CAST([{del_col}] AS INT), 0) = 0"


def _operator_name_slices(cursor):
    """Operator column for dropdowns — no date/eff/qty required."""
    opr_cands = ["oprname", "OprName", "OPRNAME", "opr_name", "OpName", "OperatorName", "Operator", "operator", "EmpName", "Emp_Code", "empcode"]
    del_cands = ["deleted", "Deleted", "IsDeleted"]
    layouts = [
        ["ConvProductionEntryRod", "convproductionentryrod", "CONVPRODUCTIONENTRYROD"],
        ["ConvProductionEntry", "convproductionentry"],
        ["ProductionEntry", "productionentry", "PRODUCTIONENTRY"],
    ]
    slices = []
    for logicals in layouts:
        sch, tn, qt = resolve_erp_table(cursor, logicals)
        if not qt:
            continue
        opr_col = find_column_ci(cursor, sch, tn, opr_cands)
        if not opr_col:
            continue
        del_col = find_column_ci(cursor, sch, tn, del_cands)
        slices.append({"q": qt, "opr": opr_col, "del": _sql_deleted_safe(del_col)})
    return slices


def _operator_table_slices(cursor):
    """Discover ProductionEntry family tables & columns (names differ across ERP installs)."""
    opr_cands = ["oprname", "OprName", "OPRNAME", "opr_name", "OpName", "OperatorName", "Operator", "operator", "EmpName", "Emp_Code", "empcode"]
    del_cands = ["deleted", "Deleted", "IsDeleted"]
    eff_conv = ["eff", "Eff", "EFF", "OpEff", "opeff", "OPREFF", "opreff"]
    qty_conv = ["qty", "Qty", "QTY", "OkQty"]
    eff_prod = ["OPREFF", "opreff", "Eff", "eff", "OpEff"]
    qty_prod = ["okqty", "OkQty", "OKQTY", "qty", "Qty"]
    entry_dates = ["entrydate", "entry_date", "EntryDate"]
    prod_dates = ["proddate", "prod_date", "Proddate", "ProductionDate"]
    layouts = [
        (["ConvProductionEntryRod", "convproductionentryrod", "CONVPRODUCTIONENTRYROD"], "entry", eff_conv, qty_conv),
        (["ConvProductionEntry", "convproductionentry"], "entry", eff_conv, qty_conv),
        (["ProductionEntry", "productionentry", "PRODUCTIONENTRY"], "prod", eff_prod, qty_prod),
    ]
    slices = []
    for logicals, kind, ef_cands, qty_cands in layouts:
        sch, tn, qt = resolve_erp_table(cursor, logicals)
        if not qt:
            continue
        date_cands = prod_dates if kind == "prod" else entry_dates
        d_col = find_column_ci(cursor, sch, tn, date_cands)
        opr_col = find_column_ci(cursor, sch, tn, opr_cands)
        if not (d_col and opr_col):
            continue
        del_col = find_column_ci(cursor, sch, tn, del_cands)
        eff_col = find_column_ci(cursor, sch, tn, ef_cands)
        qty_col = find_column_ci(cursor, sch, tn, qty_cands)
        slices.append({
            "q": qt, "d": d_col, "opr": opr_col, "eff": eff_col, "qty": qty_col,
            "del": _sql_deleted_safe(del_col),
        })
    return slices


def _machine_identifier_slices(cursor):
    """mac column only — used for machine dropdown even when OAEFF is absent."""
    mac_cands = ["macno", "MacNo", "MACNO", "machine_no", "MachineNo", "machineno"]
    del_cands = ["deleted", "Deleted", "IsDeleted"]
    layouts = [
        ["ConvProductionEntryRod", "convproductionentryrod", "CONVPRODUCTIONENTRYROD"],
        ["ConvProductionEntry", "convproductionentry"],
        ["ProductionEntry", "productionentry", "PRODUCTIONENTRY"],
    ]
    slices = []
    for logicals in layouts:
        sch, tn, qt = resolve_erp_table(cursor, logicals)
        if not qt:
            continue
        mac_col = find_column_ci(cursor, sch, tn, mac_cands)
        if not mac_col:
            continue
        del_col = find_column_ci(cursor, sch, tn, del_cands)
        slices.append({"q": qt, "mac": mac_col, "del": _sql_deleted_safe(del_col)})
    return slices


def _machine_oaeff_slices(cursor):
    mac_cands = ["macno", "MacNo", "MACNO", "machine_no", "MachineNo", "machineno"]
    del_cands = ["deleted", "Deleted", "IsDeleted"]
    oaeff_cands = ["OAEFF", "oaeff", "OAEff", "OA_EFF"]
    entry_dates = ["entrydate", "entry_date", "EntryDate"]
    prod_dates = ["proddate", "prod_date", "Proddate"]
    layouts = [
        ["ConvProductionEntryRod", "convproductionentryrod", "CONVPRODUCTIONENTRYROD"],
        ["ConvProductionEntry", "convproductionentry"],
        ["ProductionEntry", "productionentry", "PRODUCTIONENTRY"],
    ]
    kinds = ["entry", "entry", "prod"]
    slices = []
    for logicals, kind in zip(layouts, kinds):
        sch, tn, qt = resolve_erp_table(cursor, logicals)
        if not qt:
            continue
        date_cands = prod_dates if kind == "prod" else entry_dates
        d_col = find_column_ci(cursor, sch, tn, date_cands)
        mac_col = find_column_ci(cursor, sch, tn, mac_cands)
        eff_col = find_column_ci(cursor, sch, tn, oaeff_cands)
        if not (d_col and mac_col and eff_col):
            continue
        del_col = find_column_ci(cursor, sch, tn, del_cands)
        slices.append({
            "q": qt, "d": d_col, "mac": mac_col, "oaeff": eff_col,
            "del": _sql_deleted_safe(del_col),
        })
    return slices


_LEGACY_OPERATORS_SQL = (
    "SELECT DISTINCT oprname FROM ("
    "SELECT oprname FROM ConvProductionEntryRod WHERE deleted = 0 AND oprname IS NOT NULL AND LTRIM(RTRIM(oprname)) != '' "
    "UNION SELECT oprname FROM ProductionEntry WHERE deleted = 0 AND oprname IS NOT NULL AND LTRIM(RTRIM(oprname)) != '' "
    "UNION SELECT oprname FROM ConvProductionEntry WHERE deleted = 0 AND oprname IS NOT NULL AND LTRIM(RTRIM(oprname)) != '') "
    "AS AllOperators ORDER BY oprname ASC"
)

_LEGACY_MACHINES_SQL = """
SELECT DISTINCT macno FROM (
    SELECT macno FROM ConvProductionEntryRod WHERE deleted = 0 AND macno IS NOT NULL AND LTRIM(RTRIM(macno)) != ''
    UNION SELECT macno FROM ConvProductionEntry WHERE deleted = 0 AND macno IS NOT NULL AND LTRIM(RTRIM(macno)) != ''
    UNION SELECT macno FROM ProductionEntry WHERE deleted = 0 AND macno IS NOT NULL AND LTRIM(RTRIM(macno)) != ''
) AS AllMachines ORDER BY macno ASC
"""


@api_view(['GET'])
def get_operators(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    try:
        cursor = conn.cursor()
        operators = []
        slices = _operator_name_slices(cursor)
        opr_parts = []
        for s in slices:
            o = s["opr"]
            opr_parts.append(
                f"SELECT DISTINCT LTRIM(RTRIM(CAST([{o}] AS NVARCHAR(512)))) AS v FROM {s['q']} "
                f"WHERE {s['del']} AND [{o}] IS NOT NULL "
                f"AND LTRIM(RTRIM(CAST([{o}] AS NVARCHAR(512)))) <> N''"
            )
        if opr_parts:
            cursor.execute(f"SELECT DISTINCT v FROM ({' UNION ALL '.join(opr_parts)}) AS U ORDER BY v")
            operators = [row[0].strip() for row in (cursor.fetchall() or []) if row[0] and str(row[0]).strip()]
        if not operators:
            try:
                cursor.execute(_LEGACY_OPERATORS_SQL)
                operators = [row[0].strip() for row in (cursor.fetchall() or []) if row[0] and row[0].strip()]
            except Exception:
                operators = []
        cursor.close(); conn.close()
        return Response({"operators": operators, "default": operators[0] if operators else None})
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)

@api_view(['GET'])
def operator_efficiency(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    oprname = (request.GET.get("oprname") or request.GET.get("operator") or request.GET.get("name") or request.GET.get("opr") or "").strip()
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        if not oprname:
            try:
                name_slices = _operator_name_slices(cursor)
                parts = []
                for s in name_slices:
                    o = s["opr"]
                    parts.append(
                        f"SELECT DISTINCT LTRIM(RTRIM(CAST([{o}] AS NVARCHAR(512)))) AS v FROM {s['q']} "
                        f"WHERE {s['del']} AND [{o}] IS NOT NULL AND LTRIM(RTRIM(CAST([{o}] AS NVARCHAR(512)))) <> N''"
                    )
                if parts:
                    cursor.execute(f"SELECT TOP 1 v FROM ({' UNION ALL '.join(parts)}) AS U ORDER BY v")
                    r = cursor.fetchone()
                    if r and r[0]:
                        oprname = str(r[0]).strip()
                if not oprname:
                    cursor.execute(_LEGACY_OPERATORS_SQL)
                    r = cursor.fetchone()
                    if r and r[0]:
                        oprname = str(r[0]).strip()
            except Exception:
                pass
        if not oprname:
            cursor.close()
            conn.close()
            return Response({"error": "Operator name (oprname) is required."}, status=400)

        slices = _operator_table_slices(cursor)
        branches, params = [], []
        for s in slices:
            if not (s["eff"] and s["qty"]):
                continue
            branches.append(
                f"SELECT YEAR([{s['d']}]) AS YrNum, MONTH([{s['d']}]) AS MonthNo, ISNULL(CAST([{s['eff']}] AS FLOAT), 0) AS Eff, "
                f"ISNULL(CAST([{s['qty']}] AS FLOAT), 0) AS Qty FROM {s['q']} WHERE {s['del']} "
                f"AND CAST([{s['d']}] AS DATE) BETWEEN ? AND ? "
                f"AND UPPER(LTRIM(RTRIM(CAST([{s['opr']}] AS NVARCHAR(512))))) = UPPER(LTRIM(RTRIM(?)))"
            )
            params.extend([start_date, end_date, oprname])
        if branches:
            sql = (
                "WITH AllEfficiency AS (" + " UNION ALL ".join(branches) + ") "
                "SELECT YrNum, MonthNo, CASE WHEN SUM(Qty) = 0 THEN 0 ELSE AVG(Eff) END AS OperatorEfficiency "
                "FROM AllEfficiency GROUP BY YrNum, MonthNo ORDER BY YrNum, MonthNo"
            )
            cursor.execute(sql, params)
        else:
            sql = """WITH AllEfficiency AS (SELECT oprname, YEAR(entrydate) AS YrNum, MONTH(entrydate) AS MonthNo, ISNULL(eff,0) AS Eff, ISNULL(qty,0) AS Qty FROM ConvProductionEntryRod WHERE deleted = 0 AND CAST(entrydate AS DATE) BETWEEN ? AND ? AND UPPER(LTRIM(RTRIM(oprname))) = UPPER(LTRIM(RTRIM(?))) UNION ALL SELECT oprname, YEAR(proddate) AS YrNum, MONTH(proddate) AS MonthNo, ISNULL(OPREFF,0) AS Eff, ISNULL(okqty,0) AS Qty FROM ProductionEntry WHERE deleted = 0 AND CAST(proddate AS DATE) BETWEEN ? AND ? AND UPPER(LTRIM(RTRIM(oprname))) = UPPER(LTRIM(RTRIM(?))) UNION ALL SELECT oprname, YEAR(entrydate) AS YrNum, MONTH(entrydate) AS MonthNo, ISNULL(eff,0) AS Eff, ISNULL(qty,0) AS Qty FROM ConvProductionEntry WHERE deleted = 0 AND CAST(entrydate AS DATE) BETWEEN ? AND ? AND UPPER(LTRIM(RTRIM(oprname))) = UPPER(LTRIM(RTRIM(?)))) SELECT YrNum, MonthNo, CASE WHEN SUM(Qty) = 0 THEN 0 ELSE AVG(Eff) END AS OperatorEfficiency FROM AllEfficiency GROUP BY YrNum, MonthNo ORDER BY YrNum, MonthNo"""
            cursor.execute(sql, [start_date, end_date, oprname, start_date, end_date, oprname, start_date, end_date, oprname])
        rows = cursor.fetchall(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    eff_map = {b: 0.0 for b in buckets}
    for yr, month_num, efficiency in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in eff_map: eff_map[k] = round(float(efficiency or 0), 2)
    return Response({"company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "operator": oprname, "labels": labels, "data": [eff_map[b] for b in buckets]})

@api_view(['GET'])
def overall_operator_efficiency(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        slices = _operator_table_slices(cursor)
        branches, params = [], []
        for s in slices:
            if not (s["eff"] and s["qty"]):
                continue
            branches.append(
                f"SELECT YEAR([{s['d']}]) AS YrNum, MONTH([{s['d']}]) AS MonthNo, ISNULL(CAST([{s['eff']}] AS FLOAT), 0) AS Eff, "
                f"ISNULL(CAST([{s['qty']}] AS FLOAT), 0) AS Qty FROM {s['q']} WHERE {s['del']} "
                f"AND CAST([{s['d']}] AS DATE) BETWEEN ? AND ?"
            )
            params.extend([start_date, end_date])
        if branches:
            sql = (
                "WITH AllEfficiency AS (" + " UNION ALL ".join(branches) + ") "
                "SELECT YrNum, MonthNo, CASE WHEN SUM(Qty) = 0 THEN 0 ELSE AVG(Eff) END AS OverallEfficiency "
                "FROM AllEfficiency GROUP BY YrNum, MonthNo ORDER BY YrNum, MonthNo"
            )
            cursor.execute(sql, params)
        else:
            sql = """WITH AllEfficiency AS (SELECT YEAR(entrydate) AS YrNum, MONTH(entrydate) AS MonthNo, ISNULL(eff,0) AS Eff, ISNULL(qty,0) AS Qty FROM ConvProductionEntryRod WHERE deleted = 0 AND CAST(entrydate AS DATE) BETWEEN ? AND ? UNION ALL SELECT YEAR(proddate) AS YrNum, MONTH(proddate) AS MonthNo, ISNULL(OPREFF,0) AS Eff, ISNULL(okqty,0) AS Qty FROM ProductionEntry WHERE deleted = 0 AND CAST(proddate AS DATE) BETWEEN ? AND ? UNION ALL SELECT YEAR(entrydate) AS YrNum, MONTH(entrydate) AS MonthNo, ISNULL(eff,0) AS Eff, ISNULL(qty,0) AS Qty FROM ConvProductionEntry WHERE deleted = 0 AND CAST(entrydate AS DATE) BETWEEN ? AND ?) SELECT YrNum, MonthNo, CASE WHEN SUM(Qty) = 0 THEN 0 ELSE AVG(Eff) END AS OverallEfficiency FROM AllEfficiency GROUP BY YrNum, MonthNo ORDER BY YrNum, MonthNo"""
            cursor.execute(sql, [start_date, end_date, start_date, end_date, start_date, end_date])
        rows = cursor.fetchall(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    eff_map = {b: 0.0 for b in buckets}
    for yr, month_num, efficiency in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in eff_map: eff_map[k] = round(float(efficiency or 0), 2)
    return Response({"company": tenant.get("company_name", ""), "fy": fy_label, "from": str(start_date), "to": str(end_date), "labels": labels, "data": [eff_map[b] for b in buckets]})

@api_view(['GET'])
def machine_wise_idle_time(request):
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)
        
    start_date, end_date = parse_date_range(request)
    macno_raw = (request.GET.get("macno") or request.GET.get("mac") or request.GET.get("machine") or "").strip()
    mac_list = [m.strip() for m in macno_raw.split(",") if m.strip()]
    
    if mac_list:
        placeholders = ", ".join(["?"] * len(mac_list))
        top_clause = ""
        where_clause = f"WHERE macno IS NOT NULL AND LTRIM(RTRIM(macno)) <> '' AND LTRIM(RTRIM(macno)) IN ({placeholders})"
        order_clause = "ORDER BY macno"
        params = [start_date, end_date, start_date, end_date, start_date, end_date, start_date, end_date] + mac_list
    else:
        top_clause = "TOP 10"
        where_clause = "WHERE macno IS NOT NULL AND LTRIM(RTRIM(macno)) <> ''"
        order_clause = "ORDER BY TotalIdleMinutes DESC"
        params = [start_date, end_date, start_date, end_date, start_date, end_date, start_date, end_date]
        
    sql = f"""
    SELECT {top_clause} macno, SUM(IdleSeconds) / 60.0 AS TotalIdleMinutes FROM (
        SELECT d.MacNo AS macno, CAST(CASE WHEN SQL_VARIANT_PROPERTY(d.tottime, 'BaseType') IN ('datetime','time') THEN DATEDIFF(SECOND, 0, d.tottime) ELSE d.tottime END AS BIGINT) AS IdleSeconds FROM Machine_IdleEntryDet d INNER JOIN Machine_IdleEntryMas m ON d.prodid = m.prodid WHERE m.proddate BETWEEN ? AND ? AND m.deleted = 0 AND d.deleted = 0 
        UNION ALL 
        SELECT macno, CAST(DATEDIFF(SECOND, 0, IdleTime) AS BIGINT) FROM ConvProductionEntryRod WHERE entrydate BETWEEN ? AND ? AND deleted = 0 
        UNION ALL 
        SELECT macno, CAST(DATEDIFF(SECOND, 0, IdleTime) AS BIGINT) FROM ConvProductionEntry WHERE entrydate BETWEEN ? AND ? AND deleted = 0 
        UNION ALL 
        SELECT macno, CAST(CASE WHEN SQL_VARIANT_PROPERTY(idlTime, 'BaseType') IN ('datetime','time') THEN DATEDIFF(SECOND, 0, idlTime) ELSE idlTime END AS BIGINT) FROM ProductionEntry WHERE proddate BETWEEN ? AND ? AND deleted = 0
    ) AS X 
    {where_clause}
    GROUP BY macno 
    {order_clause}
    """
    
    try:
        cursor = conn.cursor()
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)
        
    if mac_list:
        idle_map = {m: 0.0 for m in mac_list}
        for row in rows:
            if row[0] is None:
                continue
            r_mac = str(row[0]).strip()
            val = round(float(row[1] or 0) / 60.0, 2)
            matched = False
            for k in idle_map.keys():
                if k.lower() == r_mac.lower():
                    idle_map[k] = val
                    matched = True
                    break
            if not matched:
                idle_map[r_mac] = val
        labels = list(idle_map.keys())
        data = list(idle_map.values())
    else:
        labels = [str(row[0]).strip() for row in rows if row[0] is not None]
        data = [round(float(row[1] or 0) / 60.0, 2) for row in rows]

    return Response({
        "company": tenant.get("company_name", ""),
        "from": str(start_date),
        "to": str(end_date),
        "labels": labels,
        "data": data
    })

# ✅ NEW: Get Machines List
@api_view(['GET'])
def get_machines(request):
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)
    try:
        cursor = conn.cursor()
        machines = []
        slices = _machine_identifier_slices(cursor)
        mac_parts = []
        for s in slices:
            m = s["mac"]
            mac_parts.append(
                f"SELECT DISTINCT LTRIM(RTRIM(CAST([{m}] AS NVARCHAR(512)))) AS v FROM {s['q']} "
                f"WHERE {s['del']} AND [{m}] IS NOT NULL "
                f"AND LTRIM(RTRIM(CAST([{m}] AS NVARCHAR(512)))) <> N''"
            )
        if mac_parts:
            cursor.execute(f"SELECT DISTINCT v FROM ({' UNION ALL '.join(mac_parts)}) AS U ORDER BY v")
            machines = [str(row[0]).strip() for row in (cursor.fetchall() or []) if row[0] and str(row[0]).strip()]
        if not machines:
            try:
                cursor.execute(_LEGACY_MACHINES_SQL)
                machines = [str(row[0]).strip() for row in (cursor.fetchall() or []) if row[0] and str(row[0]).strip()]
            except Exception:
                machines = []
        cursor.close()
        conn.close()
        return Response({"machines": machines, "default": machines[0] if machines else None})
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

# ✅ NEW: Machine Efficiency Monthwise API
@api_view(['GET'])
def machine_efficiency_monthwise(request):
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)
    macno_raw = (request.GET.get("macno") or request.GET.get("mac") or request.GET.get("machine") or "").strip()
    is_all_mac = not macno_raw or macno_raw.lower() in ("all", "all machines")
    mac_list = [m.strip() for m in macno_raw.split(",") if m.strip()]

    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        slices = _machine_oaeff_slices(cursor)
        branches, params = [], []
        for s in slices:
            cur_mac_cond = "" if is_all_mac else f"AND LTRIM(RTRIM(CAST([{s['mac']}] AS NVARCHAR(512)))) IN ({', '.join(['?'] * len(mac_list))}) "
            branches.append(
                f"SELECT YEAR([{s['d']}]) AS [Year], MONTH([{s['d']}]) AS [Month], CAST([{s['oaeff']}] AS FLOAT) AS Ov "
                f"FROM {s['q']} WHERE {s['del']} AND CAST([{s['d']}] AS DATE) BETWEEN ? AND ? "
                f"AND [{s['oaeff']}] IS NOT NULL {cur_mac_cond}"
            )
            params.extend([start_date, end_date])
            if not is_all_mac:
                params.extend(mac_list)
        if branches:
            sql = (
                "SELECT [Year], [Month], ROUND(AVG(Ov), 2) AS Avg_OA_EFF_Percentage FROM ("
                + " UNION ALL ".join(branches)
                + ") A GROUP BY [Year], [Month] ORDER BY [Year], [Month]"
            )
            cursor.execute(sql, params)
        else:
            if is_all_mac:
                sql = """
                    SELECT YEAR(A.EntryDate) AS [Year], MONTH(A.EntryDate) AS [Month],
                    ROUND(AVG(A.OAEFF), 2) AS Avg_OA_EFF_Percentage
                    FROM (
                        SELECT entrydate AS EntryDate, macno, OAEFF FROM ConvProductionEntryRod WHERE deleted = 0 AND OAEFF IS NOT NULL
                        UNION ALL
                        SELECT entrydate AS EntryDate, macno, OAEFF FROM ConvProductionEntry WHERE deleted = 0 AND OAEFF IS NOT NULL
                        UNION ALL
                        SELECT proddate AS EntryDate, macno, OAEFF FROM ProductionEntry WHERE deleted = 0 AND OAEFF IS NOT NULL
                    ) A
                    WHERE CAST(A.EntryDate AS DATE) BETWEEN ? AND ?
                    GROUP BY YEAR(A.EntryDate), MONTH(A.EntryDate)
                    ORDER BY YEAR(A.EntryDate), MONTH(A.EntryDate)
                """
                cursor.execute(sql, [start_date, end_date])
            else:
                placeholders = ", ".join(["?"] * len(mac_list))
                sql = f"""
                    SELECT YEAR(A.EntryDate) AS [Year], MONTH(A.EntryDate) AS [Month],
                    ROUND(AVG(A.OAEFF), 2) AS Avg_OA_EFF_Percentage
                    FROM (
                        SELECT entrydate AS EntryDate, macno, OAEFF FROM ConvProductionEntryRod WHERE deleted = 0 AND OAEFF IS NOT NULL AND LTRIM(RTRIM(macno)) IN ({placeholders})
                        UNION ALL
                        SELECT entrydate AS EntryDate, macno, OAEFF FROM ConvProductionEntry WHERE deleted = 0 AND OAEFF IS NOT NULL AND LTRIM(RTRIM(macno)) IN ({placeholders})
                        UNION ALL
                        SELECT proddate AS EntryDate, macno, OAEFF FROM ProductionEntry WHERE deleted = 0 AND OAEFF IS NOT NULL AND LTRIM(RTRIM(macno)) IN ({placeholders})
                    ) A
                    WHERE CAST(A.EntryDate AS DATE) BETWEEN ? AND ?
                    GROUP BY YEAR(A.EntryDate), MONTH(A.EntryDate)
                    ORDER BY YEAR(A.EntryDate), MONTH(A.EntryDate)
                """
                cursor.execute(sql, mac_list + mac_list + mac_list + [start_date, end_date])
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    eff_map = {b: 0.0 for b in buckets}
    for yr, month_num, efficiency in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in eff_map:
            eff_map[k] = round(float(efficiency or 0), 2)

    return Response({
        "company": tenant.get("company_name", ""),
        "fy": fy_label,
        "from": str(start_date),
        "to": str(end_date),
        "machine": "All Machines" if is_all_mac else macno_raw,
        "labels": labels,
        "data": [eff_map[b] for b in buckets]
    })

# ─────────────────────────────────────────────────────────────
#  OPERATIONS - PRODUCTION VALUE MONTHWISE
# ─────────────────────────────────────────────────────────────
@api_view(['GET'])
def production_value_monthwise(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    try:
        cursor = conn.cursor()
        sql = """WITH CombinedData AS (SELECT P.proddate AS EntryDate, ((CASE WHEN P.runto >= P.runfrom THEN DATEDIFF(SECOND, P.runfrom, P.runto) ELSE DATEDIFF(SECOND, P.runfrom, DATEADD(DAY, 1, P.runto)) END - ISNULL(P.accidletimesecs, 0)) / 60.0) * (ISNULL(M.RatePerHr, 0) / 60.0) AS ProductionValue FROM ProductionEntry P LEFT JOIN MacMaster M ON P.macno = M.macno WHERE P.deleted = 0 AND CAST(P.proddate AS DATE) BETWEEN ? AND ? UNION ALL SELECT C.entrydate AS EntryDate, ((CASE WHEN C.endtime >= C.starttime THEN DATEDIFF(SECOND, C.starttime, C.endtime) ELSE DATEDIFF(SECOND, C.starttime, DATEADD(DAY, 1, C.endtime)) END - ISNULL(DATEDIFF(SECOND, 0, C.IdleTime), 0)) / 60.0) * (ISNULL(M.RatePerHr, 0) / 60.0) AS ProductionValue FROM ConvProductionEntry C LEFT JOIN MacMaster M ON C.macno = M.macno WHERE C.deleted = 0 AND CAST(C.entrydate AS DATE) BETWEEN ? AND ? UNION ALL SELECT R.entrydate AS EntryDate, ((CASE WHEN R.endtime >= R.starttime THEN DATEDIFF(SECOND, R.starttime, R.endtime) ELSE DATEDIFF(SECOND, R.starttime, DATEADD(DAY, 1, R.endtime)) END - ISNULL(DATEDIFF(SECOND, 0, R.IdleTime), 0)) / 60.0) * (ISNULL(M.RatePerHr, 0) / 60.0) AS ProductionValue FROM ConvProductionEntryRod R LEFT JOIN MacMaster M ON R.macno = M.macno WHERE R.deleted = 0 AND CAST(R.entrydate AS DATE) BETWEEN ? AND ?), MachineStats AS (SELECT SUM(ISNULL(RatePerHr, 0)) AS TotalRatePerHr FROM MacMaster WHERE deleted = 0) SELECT YEAR(C.EntryDate) AS YrNum, MONTH(C.EntryDate) AS MonthNum, SUM(C.ProductionValue) AS TotalProductionValue, (24.0 * DAY(EOMONTH(C.EntryDate)) * MS.TotalRatePerHr) AS TargetProductionValue FROM CombinedData C CROSS JOIN MachineStats MS GROUP BY YEAR(C.EntryDate), MONTH(C.EntryDate), DAY(EOMONTH(C.EntryDate)), MS.TotalRatePerHr ORDER BY YEAR(C.EntryDate), MONTH(C.EntryDate)"""
        params = [start_date, end_date, start_date, end_date, start_date, end_date]
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        cursor.close(); conn.close()
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)
    actual_map = {b: 0.0 for b in buckets}
    target_map = {b: 0.0 for b in buckets}
    for yr, month_num, actual_val, target_val in rows:
        k = (int(yr or 0), int(month_num or 0))
        if k in actual_map:
            actual_map[k] = round(float(actual_val or 0) / 100_000, 2)
            target_map[k] = round(float(target_val or 0) / 100_000, 2)
    return Response({
        "company": tenant.get("company_name", ""),
        "fy": fy_label,
        "from": str(start_date),
        "to": str(end_date),
        "labels": labels,
        "actual": [actual_map[b] for b in buckets],
        "target": [target_map[b] for b in buckets],
    })

# ─────────────────────────────────────────────────────────────
#  DASHBOARD2 - PRANESH (Full Implementation)
# ─────────────────────────────────────────────────────────────
# ... [Rest of your existing dashboard2 views remain exactly the same] ...
def inspection_grand_rejection_rework_totals(cursor, tenant, start_date, end_date):
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    deleted_candidates = ["deleted", "is_deleted", "Deleted", "IsDeleted"]
    company_code = tenant.get("company_code")
    grand_rej = 0.0; grand_rwk = 0.0
    try:
        mas_tbl = find_first_table(cursor, ["InJob_Mas", "INJOB_MAS", "injob_mas"])
        det_tbl = find_first_table(cursor, ["InJob_Det", "INJOB_DET", "injob_det"])
        if mas_tbl and det_tbl:
            join_candidates = ["inspno", "InspNo", "INSPNO"]
            date_candidates = ["inspdate", "InspDate", "INSPDATE", "insp_date"]
            join_m = find_first_column(cursor, mas_tbl, join_candidates)
            join_d = find_first_column(cursor, det_tbl, join_candidates)
            mas_date = find_first_column(cursor, mas_tbl, date_candidates)
            matrej_c = find_first_column(cursor, det_tbl, ["matrej", "MatRej", "MATREJ"])
            macrej_c = find_first_column(cursor, det_tbl, ["macrej", "MacRej", "MACREJ"])
            rwqty_c = find_first_column(cursor, det_tbl, ["rwqty", "RwQty", "RWQTY", "rw_qty", "RW_Qty"])
            rej_parts = []
            if matrej_c: rej_parts.append(f"COALESCE(CAST(D.[{matrej_c}] AS FLOAT), 0)")
            if macrej_c: rej_parts.append(f"COALESCE(CAST(D.[{macrej_c}] AS FLOAT), 0)")
            if join_m and join_d and mas_date and rej_parts:
                inner_rejection = " + ".join(rej_parts)
                sql_total_rejection = f"COALESCE(SUM({inner_rejection}), 0)"
                sql_total_rework = f"COALESCE(SUM(COALESCE(CAST(D.[{rwqty_c}] AS FLOAT), 0)), 0)" if rwqty_c else "CAST(0 AS FLOAT)"
                mas_del = find_first_column(cursor, mas_tbl, deleted_candidates)
                det_del = find_first_column(cursor, det_tbl, deleted_candidates)
                mas_cc = find_first_column(cursor, mas_tbl, company_candidates)
                where_parts = [f"CAST(M.[{mas_date}] AS DATE) BETWEEN ? AND ?"]; params = [start_date, end_date]
                if mas_del: where_parts.append(f"M.[{mas_del}] = 0")
                if det_del: where_parts.append(f"(D.[{det_del}] IS NULL OR D.[{det_del}] = 0)")
                if mas_cc and company_code: where_parts.append(f"M.[{mas_cc}] = ?"); params.append(company_code)
                where_sql = " AND ".join(where_parts)
                sql = f"SELECT {sql_total_rejection} AS total_rejection, {sql_total_rework} AS total_rework FROM [{mas_tbl}] M INNER JOIN [{det_tbl}] D ON M.[{join_m}] = D.[{join_d}] WHERE {where_sql}"
                cursor.execute(sql, params); row = cursor.fetchone()
                if row: grand_rej += float((row[0] if row else 0) or 0); grand_rwk += float((row[1] if row else 0) or 0)
    except Exception: pass
    return grand_rej, grand_rwk

@api_view(['GET'])
def dashboard2_kpis(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    from_param = (request.GET.get("from") or "").strip(); to_param = (request.GET.get("to") or "").strip()
    if from_param and to_param:
        try: start_date = datetime.strptime(from_param, "%Y-%m-%d").date(); end_date = datetime.strptime(to_param, "%Y-%m-%d").date()
        except ValueError: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    else: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    production_specs = [("ConvProductionEntryRod", "qty"), ("ConvProductionEntry", "qty"), ("ProductionEntry", "okqty")]
    date_candidates = ["proddate", "prod_date", "entrydate", "entry_date", "vdate", "date", "finspdate", "inspdate", "rejdate", "jobdate"]
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    deleted_candidates = ["deleted", "is_deleted", "Deleted", "IsDeleted"]
    production_output = 0.0; oa_efficiency = 0.0; company_code = tenant.get("company_code")
    oaeff_table_specs = [("ProductionEntry", ["proddate", "prod_date", "entrydate", "entry_date", "vdate", "date"]), ("ConvProductionEntryRod", ["entrydate", "entry_date", "proddate", "prod_date", "vdate", "date"]), ("ConvProductionEntry", ["entrydate", "entry_date", "proddate", "prod_date", "vdate", "date"])]
    oaeff_col_candidates = ["OAEFF", "OaEff", "oaeff", "OEENEW"]
    try:
        cursor = conn.cursor()
        for table_name, qty_col in production_specs:
            if not table_exists(cursor, table_name): continue
            date_col = find_first_column(cursor, table_name, date_candidates)
            if not date_col: continue
            company_col = find_first_column(cursor, table_name, company_candidates)
            deleted_col = find_first_column(cursor, table_name, deleted_candidates)
            sql = f"SELECT COALESCE(SUM(CAST([{qty_col}] AS FLOAT)), 0) FROM [{table_name}] WHERE CAST([{date_col}] AS date) BETWEEN ? AND ?"
            params = [start_date, end_date]
            if company_col and company_code: sql += f" AND [{company_col}] = ?"; params.append(company_code)
            if deleted_col: sql += f" AND [{deleted_col}] = 0"
            cursor.execute(sql, params); row = cursor.fetchone()
            production_output += float((row[0] if row else 0) or 0)
        rejection_qty, rework_grand_total = inspection_grand_rejection_rework_totals(cursor, tenant, start_date, end_date)
        total_oaeff_sum = 0.0; total_oaeff_rows = 0
        for table_name, date_prefs in oaeff_table_specs:
            if not table_exists(cursor, table_name): continue
            oaeff_col = find_first_column(cursor, table_name, oaeff_col_candidates)
            if not oaeff_col: continue
            date_col = find_first_column(cursor, table_name, date_prefs)
            if not date_col: continue
            company_col = find_first_column(cursor, table_name, company_candidates)
            deleted_col = find_first_column(cursor, table_name, deleted_candidates)
            sql = f"SELECT COALESCE(SUM(COALESCE(CAST([{oaeff_col}] AS FLOAT), 0)), 0), COUNT(*) FROM [{table_name}] WHERE CAST([{date_col}] AS date) BETWEEN ? AND ?"
            params = [start_date, end_date]
            if company_col and company_code: sql += f" AND [{company_col}] = ?"; params.append(company_code)
            if deleted_col: sql += f" AND [{deleted_col}] = 0"
            cursor.execute(sql, params); row = cursor.fetchone()
            if row: total_oaeff_sum += float((row[0] if row[0] is not None else 0) or 0); total_oaeff_rows += int((row[1] if row[1] is not None else 0) or 0)
        oa_efficiency = (total_oaeff_sum / total_oaeff_rows) if total_oaeff_rows > 0 else 0.0
        cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "kpis": {"production_output": round(production_output, 2), "rejection_qty": round(rejection_qty, 2), "rework_grand_total": round(rework_grand_total, 2), "oa_efficiency": round(oa_efficiency, 2)}})

@api_view(["GET"])
def dashboard2_production_by_shift(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    company_code = tenant.get("company_code")
    branch_specs = [("ProductionEntry", "okqty", ["proddate", "prod_date", "entrydate", "entry_date", "vdate", "date"]), ("ConvProductionEntry", "qty", ["entrydate", "entry_date", "proddate", "prod_date", "vdate", "date"]), ("ConvProductionEntryRod", "qty", ["entrydate", "entry_date", "proddate", "prod_date", "vdate", "date"])]
    date_fallback = ["proddate", "prod_date", "entrydate", "entry_date", "vdate", "date", "finspdate", "inspdate"]
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    deleted_candidates = ["deleted", "is_deleted", "Deleted", "IsDeleted"]
    shift_candidates = ["shift", "shift_id", "Shift", "ShiftId", "SHIFT", "Shift_ID", "shiftid", "ShiftID"]
    totals_by_shift = {}
    try:
        cursor = conn.cursor()
        for table_name, qty_col, date_prefs in branch_specs:
            if not table_exists(cursor, table_name): continue
            if not find_first_column(cursor, table_name, [qty_col]): continue
            date_col = find_first_column(cursor, table_name, date_prefs) or find_first_column(cursor, table_name, date_fallback)
            if not date_col: continue
            shift_col = find_first_column(cursor, table_name, shift_candidates)
            if not shift_col: continue
            company_col = find_first_column(cursor, table_name, company_candidates)
            deleted_col = find_first_column(cursor, table_name, deleted_candidates)
            sql = f"SELECT [{shift_col}], COALESCE(SUM(CAST([{qty_col}] AS FLOAT)), 0) FROM [{table_name}] WHERE CAST([{date_col}] AS date) BETWEEN ? AND ?"
            params = [start_date, end_date]
            if company_col and company_code: sql += f" AND [{company_col}] = ?"; params.append(company_code)
            if deleted_col: sql += f" AND [{deleted_col}] = 0"
            sql += f" GROUP BY [{shift_col}]"
            cursor.execute(sql, params)
            for row in cursor.fetchall() or []:
                raw_shift = row[0]; key = str(raw_shift).strip() if raw_shift is not None else ""
                if key == "": key = "(unassigned)"
                qty = float((row[1] if len(row) > 1 else 0) or 0)
                totals_by_shift[key] = totals_by_shift.get(key, 0.0) + qty
        cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    shifts_out = [{"shift": k, "total_qty": round(v, 2)} for k, v in sorted(totals_by_shift.items(), key=lambda kv: kv[0])]
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "shifts": shifts_out})

@api_view(["GET"])
def dashboard2_idle_hours(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    company_code = tenant.get("company_code")
    date_params = [start_date, end_date]
    final_sql = """SELECT CAST(ISNULL(SUM(AcceptedMinutes), 0) AS FLOAT) / 60.0 AS accepted_hours, CAST(ISNULL(SUM(NonAcceptedMinutes), 0) AS FLOAT) / 60.0 AS non_accepted_hours, CAST(ISNULL(SUM(TotalMinutes), 0) AS FLOAT) / 60.0 AS total_idle_hours, CAST(ISNULL(SUM(OtherMinutes), 0) AS FLOAT) / 60.0 AS other_hours FROM (SELECT ISNULL(SUM(CASE WHEN IR.IsAccept = 1 THEN DATEDIFF(MINUTE, '1900-01-01', D.tottime) END), 0) AS AcceptedMinutes, ISNULL(SUM(CASE WHEN IR.IsAccept = 0 THEN DATEDIFF(MINUTE, '1900-01-01', D.tottime) END), 0) AS NonAcceptedMinutes, ISNULL(SUM(DATEDIFF(MINUTE, '1900-01-01', D.tottime)), 0) AS TotalMinutes, ISNULL(SUM(CASE WHEN IR.IdleReasons IS NULL THEN DATEDIFF(MINUTE, '1900-01-01', D.tottime) END), 0) AS OtherMinutes FROM Machine_IdleEntryDet D INNER JOIN Machine_IdleEntryMas M ON D.prodid = M.prodid LEFT JOIN IdleReasons IR ON LTRIM(RTRIM(D.reasons)) = LTRIM(RTRIM(IR.IdleReasons)) AND IR.deleted = 0 WHERE M.proddate BETWEEN ? AND ? AND M.deleted = 0 AND D.deleted = 0 UNION ALL SELECT ISNULL(SUM(CASE WHEN IR.IsAccept = 1 THEN DATEDIFF(MINUTE, '1900-01-01', P.tottime) END), 0), ISNULL(SUM(CASE WHEN IR.IsAccept = 0 THEN DATEDIFF(MINUTE, '1900-01-01', P.tottime) END), 0), ISNULL(SUM(DATEDIFF(MINUTE, '1900-01-01', P.tottime)), 0), ISNULL(SUM(CASE WHEN IR.IdleReasons IS NULL THEN DATEDIFF(MINUTE, '1900-01-01', P.tottime) END), 0) FROM Prod_IdleEntry P INNER JOIN ProductionEntry PE ON P.prodid = PE.prodid LEFT JOIN IdleReasons IR ON LTRIM(RTRIM(P.reasons)) = LTRIM(RTRIM(IR.IdleReasons)) AND IR.deleted = 0 WHERE PE.proddate BETWEEN ? AND ? AND PE.deleted = 0 AND P.deleted = 0 UNION ALL SELECT ISNULL(SUM(CASE WHEN IR.IsAccept = 1 THEN DATEDIFF(MINUTE, '1900-01-01', CI.tottime) END), 0), ISNULL(SUM(CASE WHEN IR.IsAccept = 0 THEN DATEDIFF(MINUTE, '1900-01-01', CI.tottime) END), 0), ISNULL(SUM(DATEDIFF(MINUTE, '1900-01-01', CI.tottime)), 0), ISNULL(SUM(CASE WHEN IR.IdleReasons IS NULL THEN DATEDIFF(MINUTE, '1900-01-01', CI.tottime) END), 0) FROM conv_IdleEntry CI INNER JOIN (SELECT entryno FROM ConvProductionEntry WHERE entrydate BETWEEN ? AND ? AND deleted = 0 UNION SELECT entryno FROM ConvProductionEntryRod WHERE entrydate BETWEEN ? AND ? AND deleted = 0) C ON CI.entryno = C.entryno LEFT JOIN IdleReasons IR ON LTRIM(RTRIM(CI.reasons)) = LTRIM(RTRIM(IR.IdleReasons)) AND IR.deleted = 0 WHERE CI.deleted = 0) AS X"""
    params = [start_date, end_date, start_date, end_date, start_date, end_date, start_date, end_date]
    acc_h = na_h = tot_h = other_h = 0.0
    try:
        cursor = conn.cursor(); cursor.execute(final_sql, params); row = cursor.fetchone()
        if row: acc_h = float(row[0] or 0); na_h = float(row[1] or 0); tot_h = float(row[2] or 0); other_h = float(row[3] or 0)
        cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    return Response({"company": tenant.get("company_name", ""), "company_code": company_code or "", "from": str(start_date), "to": str(end_date), "summary": {"accepted_hours": round(acc_h, 2), "non_accepted_hours": round(na_h, 2), "total_idle_hours": round(tot_h, 2), "other_hours": round(other_h, 2)}, "accepted": [], "non_accepted": []})

@api_view(["GET"])
def dashboard2_downtime_by_reason(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    d1 = start_date.isoformat(); d2 = end_date.isoformat()
    sql = f"""SELECT IR.IdleReasons AS Reason, CAST(SUM(DATEDIFF(MINUTE, '1900-01-01', X.tottime)) / 60.0 AS DECIMAL(12, 2)) AS Hours FROM (SELECT D.reasons AS reasons, D.tottime AS tottime FROM Machine_IdleEntryDet D INNER JOIN Machine_IdleEntryMas M ON D.prodid = M.prodid WHERE M.proddate BETWEEN '{d1}' AND '{d2}' AND M.deleted = 0 AND D.deleted = 0 UNION ALL SELECT P.reasons, P.tottime FROM Prod_IdleEntry P INNER JOIN ProductionEntry PE ON P.prodid = PE.prodid WHERE PE.proddate BETWEEN '{d1}' AND '{d2}' AND PE.deleted = 0 AND P.deleted = 0 UNION ALL SELECT CI.reasons, CI.tottime FROM conv_IdleEntry CI INNER JOIN (SELECT entryno FROM ConvProductionEntry WHERE entrydate BETWEEN '{d1}' AND '{d2}' AND deleted = 0 UNION SELECT entryno FROM ConvProductionEntryRod WHERE entrydate BETWEEN '{d1}' AND '{d2}' AND deleted = 0) C ON CI.entryno = C.entryno WHERE CI.deleted = 0) X INNER JOIN IdleReasons IR ON LTRIM(RTRIM(X.reasons)) = LTRIM(RTRIM(IR.IdleReasons)) AND IR.deleted = 0 WHERE IR.IsAccept = 0 GROUP BY IR.IdleReasons ORDER BY SUM(DATEDIFF(MINUTE, '1900-01-01', X.tottime)) DESC"""
    reasons_out = []
    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        for row in cursor.fetchall() or []:
            r, h = row[0], row[1]
            reasons_out.append({"reason": (str(r).strip() if r is not None else "") or "(blank)", "hours": float(h or 0)})
        cursor.close()
        conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "reasons": reasons_out})

@api_view(["GET"])
def dashboard2_customer_complaints(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    company_code = tenant.get("company_code")
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    complaints = []
    try:
        cursor = conn.cursor()
        tbl_m = find_first_table(cursor, ["CustCompMas", "custcompmas", "CUSTCOMPMAS"])
        if not tbl_m: cursor.close(); conn.close(); return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "complaints": [], "error": "CustCompMas table not found in this database."})
        cmpno_m = find_first_column(cursor, tbl_m, ["CmpNo", "cmpno", "CMPNO"])
        cid_m = find_first_column(cursor, tbl_m, ["CId", "cid", "CID", "CustId", "custid"])
        date_m = find_first_column(cursor, tbl_m, ["CmpDate", "cmpdate", "CMPDATE"])
        del_m = find_first_column(cursor, tbl_m, ["Deleted", "deleted", "IsDeleted"])
        part_m = find_first_column(cursor, tbl_m, ["partno", "PartNo", "PARTNO", "ItCode", "itcode"])
        desc_m = find_first_column(cursor, tbl_m, ["description", "Description", "DESCRIPTION", "Descr", "descr"])
        rem_m = find_first_column(cursor, tbl_m, ["Remarks", "remarks", "REMARKS"])
        cor_m = find_first_column(cursor, tbl_m, ["coraction", "CorAction", "CORACTION"])
        per_m = find_first_column(cursor, tbl_m, ["peraction", "PerAction", "PERACTION"])
        company_m = find_first_column(cursor, tbl_m, company_candidates)
        if not cmpno_m or not date_m: cursor.close(); conn.close(); return Response({"error": "CustCompMas is missing CmpNo or CmpDate (or equivalent).", "complaints": []}, status=500)
        part_expr = f"ISNULL(CAST(M.[{part_m}] AS NVARCHAR(256)), N'')" if part_m else "N''"
        desc_expr = f"ISNULL(CAST(M.[{desc_m}] AS NVARCHAR(512)), N'')" if desc_m else "N''"
        product_sql = f"({part_expr} + CASE WHEN LEN({desc_expr}) > 0 AND LEN({part_expr}) > 0 THEN N' - ' ELSE N'' END + {desc_expr})"
        rem_sql = f"CAST(M.[{rem_m}] AS NVARCHAR(MAX))" if rem_m else "CAST(NULL AS NVARCHAR(MAX))"
        cor_sql = f"CAST(M.[{cor_m}] AS NVARCHAR(MAX))" if cor_m else "CAST(NULL AS NVARCHAR(MAX))"
        per_sql = f"CAST(M.[{per_m}] AS NVARCHAR(MAX))" if per_m else "CAST(NULL AS NVARCHAR(MAX))"
        cm_join = ""; customer_sql = "CAST(NULL AS NVARCHAR(512))"; cname_cm = None
        tbl_cm = find_first_table(cursor, ["CustMast", "custmast", "CUSTMAST"])
        if tbl_cm and cid_m:
            id_cm = find_first_column(cursor, tbl_cm, ["Id", "id", "ID", "CustId", "custid"])
            cname_cm = find_first_column(cursor, tbl_cm, ["CName", "cname", "CNAME", "CustName", "custname", "Name"])
            del_cm = find_first_column(cursor, tbl_cm, ["Deleted", "deleted", "IsDeleted"])
            if id_cm and cname_cm:
                cm_del = f" AND ISNULL(CM.[{del_cm}], 0) = 0" if del_cm else ""
                cm_join = f"LEFT JOIN [{tbl_cm}] CM ON M.[{cid_m}] = CM.[{id_cm}]{cm_del}"; customer_sql = f"CAST(CM.[{cname_cm}] AS NVARCHAR(512))"
        tbl_d = find_first_table(cursor, ["CustCompDet", "custcompdet", "CUSTCOMPDET"])
        if tbl_d:
            cmpno_d = find_first_column(cursor, tbl_d, ["CmpNo", "cmpno", "CMPNO"])
            action_d = find_first_column(cursor, tbl_d, ["ActionTaken", "actiontaken", "ACTIONTAKEN"])
            status_d = find_first_column(cursor, tbl_d, ["CompStatus", "compstatus", "COMPSTATUS", "Status", "status"])
            del_d = find_first_column(cursor, tbl_d, ["Deleted", "deleted", "IsDeleted"])
            if cmpno_d:
                del_dx = f" AND ISNULL(dx.[{del_d}], 0) = 0" if del_d else ""
                sel_a = f"CAST(dx.[{action_d}] AS NVARCHAR(MAX))" if action_d else "CAST(NULL AS NVARCHAR(MAX))"
                sel_s = f"CAST(dx.[{status_d}] AS NVARCHAR(200))" if status_d else "CAST(NULL AS NVARCHAR(200))"
                apply_block = f"""OUTER APPLY (SELECT TOP 1 {sel_a} AS ActionTaken, {sel_s} AS CompStatus FROM [{tbl_d}] dx WHERE dx.[{cmpno_d}] = M.[{cmpno_m}]{del_dx} ORDER BY (SELECT NULL)) AS Det"""
            else: apply_block = """OUTER APPLY (SELECT CAST(NULL AS NVARCHAR(MAX)) AS ActionTaken, CAST(NULL AS NVARCHAR(200)) AS CompStatus) AS Det"""
        else: apply_block = """OUTER APPLY (SELECT CAST(NULL AS NVARCHAR(MAX)) AS ActionTaken, CAST(NULL AS NVARCHAR(200)) AS CompStatus) AS Det"""
        mas_where = f"CAST(M.[{date_m}] AS DATE) BETWEEN ? AND ?"; params: list[Any] = [start_date, end_date]
        if del_m: mas_where += f" AND ISNULL(M.[{del_m}], 0) = 0"
        if company_m and company_code: mas_where += f" AND M.[{company_m}] = ?"; params.append(company_code)
        cust_param = request.GET.get("customer") or request.GET.get("customer_name") or request.GET.get("customers") or ""
        cust_list = [c.strip() for c in cust_param.split(",") if c.strip() and c.strip().lower() not in ("all", "all customers", "all customer")]
        if cust_list and tbl_cm and cid_m and cname_cm:
            placeholders = ",".join(["?"] * len(cust_list))
            mas_where += f" AND CM.[{cname_cm}] IN ({placeholders})"
            params.extend(cust_list)
        sql = f"""SELECT TOP 500 M.[{cmpno_m}] AS Complaint_ID, {customer_sql} AS Customer_Name, CAST({product_sql} AS NVARCHAR(800)) AS Product, {rem_sql} AS Complaint_Description, Det.ActionTaken AS Action_Taken, M.[{date_m}] AS Complaint_Date, {cor_sql} AS Corrective_Action, {per_sql} AS Permanent_Action, Det.CompStatus AS Status FROM [{tbl_m}] M {apply_block} {cm_join} WHERE {mas_where} ORDER BY M.[{date_m}], M.[{cmpno_m}]"""
        cursor.execute(sql, params)
        for row in cursor.fetchall() or []:
            cid, cname, prod, crem, tact, cdt, cor, per, st = row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]
            cdt_s = cdt.isoformat()[:10] if cdt is not None and hasattr(cdt, "isoformat") else (str(cdt) if cdt is not None else "")
            complaints.append({"complaint_id": str(cid).strip() if cid is not None else "", "customer_name": (str(cname).strip() if cname is not None else "") or "—", "product": (str(prod).strip() if prod is not None else "") or "—", "complaint_description": (str(crem).strip() if crem is not None else "") or "—", "action_taken": (str(tact).strip() if tact is not None else "") or "—", "complaint_date": cdt_s, "corrective_action": (str(cor).strip() if cor is not None else "") or "—", "permanent_action": (str(per).strip() if per is not None else "") or "—", "status": (str(st).strip() if st is not None else "") or "—"})
        cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}", "complaints": []}, status=500)
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "complaints": complaints})

@api_view(["GET"])
def dashboard2_po_pipeline(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    company_code = tenant.get("company_code")
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    cursor = None
    try:
        cursor = conn.cursor()
        sch_po, nm_po, q_po = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        sch_det, nm_det, q_det = resolve_erp_table(cursor, ["PODet", "podet", "PODET", "PoDet"])
        sch_grn, nm_grn, q_grn = resolve_erp_table(cursor, ["grninsubdet", "GRNInSubDet", "GrnInSubDet", "GRNINSUBDET"])
        sch_gm, nm_gm, q_gm = resolve_erp_table(cursor, ["grn_mas", "GRN_MAS", "Grn_Mas", "GrnMas"])
        sch_cm, nm_cm, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST"])
        if not q_po or not q_det or not q_grn: cursor.close(); conn.close(); return Response({"error": "Required tables not found.", "from": str(start_date), "to": str(end_date), "summary": None, "rows": []}, status=404)
        po_pono = find_column_ci(cursor, sch_po, nm_po, ["pono", "PONo", "PONO", "PoNo", "PONumber"])
        po_date = find_column_ci(cursor, sch_po, nm_po, ["podate", "PODate", "PO_Date", "po_date", "PODt"])
        po_del = find_column_ci(cursor, sch_po, nm_po, ["deleted", "Deleted", "IsDeleted"])
        po_dtype = find_column_ci(cursor, sch_po, nm_po, ["dtype", "DType", "POType", "potype", "Type"])
        po_appr = find_column_ci(cursor, sch_po, nm_po, ["IsApprovePo", "isapprovepo", "IsApproved", "Approved", "ApprovePo"])
        po_cid = find_column_ci(cursor, sch_po, nm_po, ["cid", "CId", "CID", "CustId", "custid"])
        po_cc = find_column_ci(cursor, sch_po, nm_po, company_candidates)
        det_pono = find_column_ci(cursor, sch_det, nm_det, ["pono", "PONo", "PONO", "PoNo"])
        det_del = find_column_ci(cursor, sch_det, nm_det, ["deleted", "Deleted", "IsDeleted"])
        det_rm = find_column_ci(cursor, sch_det, nm_det, ["rmname", "RMName", "RMNAME", "RmName", "ItemName"])
        det_mt = find_column_ci(cursor, sch_det, nm_det, ["mattype", "MatType", "MATTYPE", "Mat_Type"])
        det_uom = find_column_ci(cursor, sch_det, nm_det, ["uom", "UOM", "Uom", "Unit"])
        det_qty = find_column_ci(cursor, sch_det, nm_det, ["qty", "Qty", "QTY", "Quantity"])
        det_amt = find_column_ci(cursor, sch_det, nm_det, ["amount", "Amount", "AMOUNT", "Amt", "Value"])
        g_pono = find_column_ci(cursor, sch_grn, nm_grn, ["pono", "PONo", "PONO", "PoNo"])
        g_grnno = find_column_ci(cursor, sch_grn, nm_grn, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        g_del = find_column_ci(cursor, sch_grn, nm_grn, ["deleted", "Deleted", "IsDeleted"])
        gm_grn = gm_date = gm_del = gm_namt = None
        if q_gm:
            gm_grn = find_column_ci(cursor, sch_gm, nm_gm, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
            gm_date = find_column_ci(cursor, sch_gm, nm_gm, ["grndate", "GRNDate", "GRNDATE", "Grn_Date"])
            gm_del = find_column_ci(cursor, sch_gm, nm_gm, ["deleted", "Deleted", "IsDeleted"])
            gm_namt = find_column_ci(cursor, sch_gm, nm_gm, ["namt", "NAMT", "NetAmt", "GrandTotal", "Amount", "TotAmt"])
        cm_id = cm_name = cm_del = None
        if q_cm:
            cm_id = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId", "custid"])
            cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName", "Name"])
            cm_del = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"])
        if not po_pono or not po_date or not det_pono or not det_amt or not g_pono or not g_grnno: cursor.close(); conn.close(); return Response({"error": "Required columns not found.", "from": str(start_date), "to": str(end_date), "summary": None, "rows": []}, status=500)
        del_po_sql = f"ISNULL(M.[{po_del}], 0) = 0" if po_del else "1=1"
        del_det_sql = f"ISNULL(D.[{det_del}], 0) = 0" if det_del else "1=1"
        dtype_filter = f" AND LOWER(ISNULL(M.[{po_dtype}], N'')) <> N'job order'" if po_dtype else ""
        company_sql = ""; cte_params = [start_date, end_date]
        if po_cc and company_code: company_sql = f" AND M.[{po_cc}] = ?"; cte_params.append(company_code)
        appr_sel = f"M.[{po_appr}] AS appr_col" if po_appr else "CAST(0 AS INT) AS appr_col"
        grn_dist_where = f"ISNULL(gx.[{g_del}], 0) = 0" if g_del else "1=1"
        grnval_sql = "CAST(0 AS FLOAT)"
        if q_gm and gm_grn and gm_namt:
            gm_del_sql = f"ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else "1=1"
            gjoin_del = f"ISNULL(G.[{g_del}], 0) = 0" if g_del else "1=1"
            grnval_sql = f"""(SELECT SUM(ISNULL(CAST(GM.[{gm_namt}] AS FLOAT), 0)) FROM {q_gm} GM INNER JOIN {q_grn} G ON GM.[{gm_grn}] = G.[{g_grnno}] INNER JOIN M_FILTER MF ON G.[{g_pono}] = MF.pono_col WHERE {gjoin_del} AND {gm_del_sql})"""
        cte_sql = f"""WITH M_FILTER AS (SELECT M.[{po_pono}] AS pono_col, {appr_sel} FROM {q_po} M WHERE CAST(M.[{po_date}] AS DATE) BETWEEN ? AND ? AND {del_po_sql}{dtype_filter}{company_sql})"""
        summary_sql = cte_sql + f"""SELECT (SELECT COUNT(DISTINCT pono_col) FROM M_FILTER) AS Total_POs, (SELECT COUNT(DISTINCT CASE WHEN appr_col = 1 THEN pono_col END) FROM M_FILTER) AS Approved, (SELECT COUNT(DISTINCT CASE WHEN ISNULL(appr_col, 0) = 0 THEN pono_col END) FROM M_FILTER) AS Pending_Approval, (SELECT COUNT(DISTINCT CASE WHEN G.pono_join IS NOT NULL THEN H.pono_col END) FROM M_FILTER H LEFT JOIN (SELECT DISTINCT gx.[{g_pono}] AS pono_join FROM {q_grn} gx WHERE {grn_dist_where}) G ON H.pono_col = G.pono_join) AS GRN_Done, (SELECT COUNT(DISTINCT CASE WHEN G.pono_join IS NULL THEN H.pono_col END) FROM M_FILTER H LEFT JOIN (SELECT DISTINCT gx.[{g_pono}] AS pono_join FROM {q_grn} gx WHERE {grn_dist_where}) G ON H.pono_col = G.pono_join) AS GRN_Pending, (SELECT SUM(ISNULL(CAST(D.[{det_amt}] AS FLOAT), 0)) FROM {q_det} D INNER JOIN M_FILTER MF ON D.[{det_pono}] = MF.pono_col WHERE {del_det_sql}) AS Total_PO_Value, {grnval_sql} AS Total_GRN_Value"""
        cursor.execute(summary_sql, cte_params); sum_row = cursor.fetchone()
        summary_out = {"total_pos": int(sum_row[0] or 0) if sum_row else 0, "approved": int(sum_row[1] or 0) if sum_row else 0, "pending_approval": int(sum_row[2] or 0) if sum_row else 0, "grn_done": int(sum_row[3] or 0) if sum_row else 0, "grn_pending": int(sum_row[4] or 0) if sum_row else 0, "total_po_value": float(sum_row[5] or 0) if sum_row else 0.0, "total_grn_value": float(sum_row[6] or 0) if sum_row else 0.0}
        rm_a = f"D.[{det_rm}]" if det_rm else "CAST(NULL AS NVARCHAR(256))"
        mt_a = f"D.[{det_mt}]" if det_mt else "CAST(NULL AS NVARCHAR(256))"
        mat_concat = f"ISNULL(CAST({rm_a} AS NVARCHAR(256)), N'') + N' - ' + ISNULL(CAST({mt_a} AS NVARCHAR(256)), N'')"
        po_qty_sql = f"CAST(ROUND(ISNULL(D.[{det_qty}], 0), 2) AS NVARCHAR(50)) + N' ' + ISNULL(CAST(D.[{det_uom}] AS NVARCHAR(32)), N'')" if det_qty and det_uom else (f"CAST(ROUND(ISNULL(D.[{det_qty}], 0), 2) AS NVARCHAR(50))" if det_qty else "N''")
        vendor_sql = "CAST(NULL AS NVARCHAR(512))"; cm_join = ""
        if q_cm and cm_id and cm_name and po_cid:
            cm_del_sql = f" AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
            cm_join = f"LEFT JOIN {q_cm} CM ON M.[{po_cid}] = CM.[{cm_id}]{cm_del_sql}"; vendor_sql = f"CAST(CM.[{cm_name}] AS NVARCHAR(512))"
        g_agg = f"""LEFT JOIN (SELECT gx.[{g_pono}] AS pono_g, MAX(gx.[{g_grnno}]) AS grnno_g FROM {q_grn} gx WHERE {grn_dist_where} GROUP BY gx.[{g_pono}]) G ON M.[{po_pono}] = G.pono_g"""
        gm_join = ""; grn_no_sel = "CAST(G.grnno_g AS NVARCHAR(64))"; grn_dt_sel = "CAST(NULL AS DATE)"
        if q_gm and gm_grn and gm_date:
            gm_del_j = f" AND ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else ""
            gm_join = f"LEFT JOIN {q_gm} GM ON G.grnno_g = GM.[{gm_grn}]{gm_del_j}"; grn_dt_sel = f"GM.[{gm_date}]"
        mas_where_detail = f"""CAST(M.[{po_date}] AS DATE) BETWEEN ? AND ? AND {del_po_sql}{dtype_filter}{company_sql}"""
        detail_params = [start_date, end_date]
        if po_cc and company_code: detail_params.append(company_code)
        detail_sql = f"""SELECT TOP 3000 M.[{po_pono}] AS PO_Number, {f"M.[{po_dtype}]" if po_dtype else "CAST(NULL AS NVARCHAR(64))"} AS PO_Type, {vendor_sql} AS Vendor_Name, CAST({mat_concat} AS NVARCHAR(520)) AS Material, CAST({po_qty_sql} AS NVARCHAR(120)) AS PO_Qty, ISNULL(CAST(D.[{det_amt}] AS FLOAT), 0) AS Value, M.[{po_date}] AS PO_Date, {grn_no_sel} AS GRN_No, {grn_dt_sel} AS GRN_Date FROM {q_po} M INNER JOIN {q_det} D ON M.[{po_pono}] = D.[{det_pono}] AND {del_det_sql} {cm_join} {g_agg} {gm_join} WHERE {mas_where_detail} ORDER BY M.[{po_date}], M.[{po_pono}]"""
        cursor.execute(detail_sql, detail_params); rows_out = []
        for row in cursor.fetchall() or []:
            po_dt = row[6]; grn_dt = row[8]
            rows_out.append({"po_number": str(row[0]).strip() if row[0] is not None else "", "po_type": str(row[1]).strip() if row[1] is not None else "", "vendor_name": str(row[2]).strip() if row[2] is not None else "", "material": str(row[3]).strip() if row[3] is not None else "", "po_qty": str(row[4]).strip() if row[4] is not None else "", "value": float(row[5] or 0), "po_date": po_dt.isoformat()[:10] if po_dt is not None and hasattr(po_dt, "isoformat") else (str(po_dt)[:10] if po_dt else ""), "grn_no": str(row[7]).strip() if row[7] is not None else "", "grn_date": grn_dt.isoformat()[:10] if grn_dt is not None and hasattr(grn_dt, "isoformat") else (str(grn_dt)[:10] if grn_dt else "")})
        cursor.close(); conn.close()
        return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "summary": summary_out, "rows": rows_out})
    except Exception as e:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass
        return Response({"error": f"Database error: {str(e)}", "from": str(start_date), "to": str(end_date), "summary": None, "rows": []}, status=500)

@api_view(["GET"])
def dashboard2_inspection_pending_snapshot(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    cursor = None; warnings = []
    try:
        cursor = conn.cursor()
        sch_rcs, nm_rcs, q_rcs = resolve_erp_table(cursor, ["RouteCardStock", "ROUTECARDSTOCK", "routecardstock", "Route_Card_Stock"])
        sch_job, nm_job, q_job = resolve_erp_table(cursor, ["InJob_DetTemp", "INJOB_DETTEMP", "injob_dettemp", "InJobDetTemp"])
        inter_col = final_col = None
        if q_rcs:
            inter_col = find_column_ci(cursor, sch_rcs, nm_rcs, ["interinspqty", "InterInspQty", "INTERINSPQTY", "InterInsp_Qty"])
            final_col = find_column_ci(cursor, sch_rcs, nm_rcs, ["finalinspqty", "FinalInspQty", "FINALINSPQTY", "FinalInsp_Qty"])
            if not inter_col: warnings.append("RouteCardStock found but interinspqty missing; intermediate_pending_qty = 0.")
            if not final_col: warnings.append("RouteCardStock found but finalinspqty missing; final_pending_qty = 0.")
        else: warnings.append("RouteCardStock not found; intermediate and final pending qty returned as 0.")
        job_bal = insp_col = job_del = None
        if q_job:
            job_bal = find_column_ci(cursor, sch_job, nm_job, ["JobBalQty", "jobbalqty", "JOBBALQTY", "Job_Bal_Qty", "BalQty"])
            insp_col = find_column_ci(cursor, sch_job, nm_job, ["insp", "Insp", "INSP", "Inspected", "IsInsp"])
            job_del = find_column_ci(cursor, sch_job, nm_job, ["deleted", "Deleted", "IsDeleted"])
            if not job_bal: warnings.append("InJob_DetTemp found but JobBalQty missing; joborder_pending_qty = 0.")
            if not insp_col: warnings.append("InJob_DetTemp found but insp column missing; joborder_pending_qty = 0.")
        else: warnings.append("InJob_DetTemp not found; joborder_pending_qty returned as 0.")
        sel_inter = f"""(SELECT SUM(ISNULL(CAST(R.[{inter_col}] AS FLOAT), 0)) FROM {q_rcs} R WHERE ISNULL(CAST(R.[{inter_col}] AS FLOAT), 0) > 0)""" if inter_col and q_rcs else "CAST(0 AS FLOAT)"
        sel_final = f"""(SELECT SUM(ISNULL(CAST(R.[{final_col}] AS FLOAT), 0)) FROM {q_rcs} R WHERE ISNULL(CAST(R.[{final_col}] AS FLOAT), 0) > 0)""" if final_col and q_rcs else "CAST(0 AS FLOAT)"
        sel_job = f"""(SELECT SUM(ISNULL(CAST(T.[{job_bal}] AS FLOAT), 0)) FROM {q_job} T WHERE ISNULL(CAST(T.[{insp_col}] AS INT), 0) = 0 AND ISNULL(T.[{job_del}], 0) = 0)""" if job_bal and insp_col and q_job else "CAST(0 AS FLOAT)"
        sql = f"""SELECT ISNULL({sel_inter}, 0) AS intermediate_pending_qty, ISNULL({sel_final}, 0) AS final_pending_qty, ISNULL({sel_job}, 0) AS joborder_pending_qty"""
        cursor.execute(sql); row = cursor.fetchone(); cursor.close(); conn.close()
        def _f(idx):
            if not row or row[idx] is None: return 0.0
            try: return float(row[idx])
            except: return 0.0
        return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "intermediate_pending_qty": _f(0), "final_pending_qty": _f(1), "joborder_pending_qty": _f(2), "warnings": warnings})
    except Exception as e:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass
        return Response({"error": f"Database error: {str(e)}", "intermediate_pending_qty": None, "final_pending_qty": None, "joborder_pending_qty": None}, status=500)

@api_view(["GET"])
def dashboard2_grn_pending_pipeline(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    cursor = None; warnings = []
    try:
        cursor = conn.cursor()
        sch_m, nm_m, q_m = resolve_erp_table(cursor, ["grn_mas", "GRN_MAS", "Grn_Mas", "GrnMas", "GRNMast", "grnmast"])
        sch_d, nm_d, q_d = resolve_erp_table(cursor, ["grn_det", "GRN_DET", "Grn_Det", "GrnDet", "GRNDet"])
        if not q_m or not q_d: cursor.close(); conn.close(); return Response({"from": str(start_date), "to": str(end_date), "rows": [], "error": "grn_mas or grn_det table not found."}, status=404)
        m_grn = find_column_ci(cursor, sch_m, nm_m, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        m_date = find_column_ci(cursor, sch_m, nm_m, ["grndate", "GRNDate", "GRNDATE", "Grn_Date"])
        m_del = find_column_ci(cursor, sch_m, nm_m, ["deleted", "Deleted", "IsDeleted"])
        m_dtype = find_column_ci(cursor, sch_m, nm_m, ["dtype", "DType", "GRNType", "Type"])
        d_grn = find_column_ci(cursor, sch_d, nm_d, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        d_del = find_column_ci(cursor, sch_d, nm_d, ["deleted", "Deleted", "IsDeleted"])
        d_insp = find_column_ci(cursor, sch_d, nm_d, ["insp", "Insp", "INSP", "Inspected", "IsInsp"])
        d_part = find_column_ci(cursor, sch_d, nm_d, ["partno", "PartNo", "PARTNO", "Part_No", "ItCode", "itcode"])
        d_desc = find_column_ci(cursor, sch_d, nm_d, ["description", "Description", "DESCRIPTION", "Descr", "descr", "PartName"])
        d_uom = find_column_ci(cursor, sch_d, nm_d, ["uom", "UOM", "Uom", "Unit"])
        d_qty = find_column_ci(cursor, sch_d, nm_d, ["qty", "Qty", "QTY", "Quantity"])
        d_qtykgs = find_column_ci(cursor, sch_d, nm_d, ["qtykgs", "QtyKgs", "QTYKGS", "Qty_Kgs", "qty_kgs", "WeightQty"])
        d_pono = find_column_ci(cursor, sch_d, nm_d, ["pono", "PONo", "PONO", "PoNo", "PONumber"])
        if not m_grn or not m_date or not d_grn: cursor.close(); conn.close(); return Response({"error": "Required columns not found.", "from": str(start_date), "to": str(end_date), "rows": []}, status=500)
        if not d_insp: warnings.append("insp column not found on grn_det; cannot apply pending-inspection filter.")
        part_e = f"CAST(D.[{d_part}] AS NVARCHAR(256))" if d_part else "CAST(N'' AS NVARCHAR(256))"
        desc_e = f"CAST(D.[{d_desc}] AS NVARCHAR(512))" if d_desc else "CAST(N'' AS NVARCHAR(512))"
        mat_sql = f"ISNULL({part_e}, N'') + N' - ' + ISNULL({desc_e}, N'')"
        dtype_sel = f"CAST(M.[{m_dtype}] AS NVARCHAR(128))" if m_dtype else "CAST(NULL AS NVARCHAR(128))"
        mas_del_sql = f"ISNULL(M.[{m_del}], 0) = 0" if m_del else "1=1"
        join_del = f" AND ISNULL(D.[{d_del}], 0) = 0" if d_del else ""
        insp_where = f"ISNULL(CAST(D.[{d_insp}] AS INT), 0) = 0" if d_insp else "1=0"
        else_qty_sum = f"ISNULL(CAST(D.[{d_qty}] AS FLOAT), 0)" if d_qty else "CAST(0 AS FLOAT)"
        w_uom_lower = f"LOWER(ISNULL(D.[{d_uom}], N''))" if d_uom else "N''"
        weight_qty_sum = f"""CASE WHEN TRY_CAST(D.[{d_pono}] AS FLOAT) IS NOT NULL THEN TRY_CAST(D.[{d_pono}] AS FLOAT) ELSE 0.0 END""" if d_pono else "CAST(0 AS FLOAT)"
        sum_qty_inner = f"""CASE WHEN {w_uom_lower} IN (N'kgs', N'kg', N'mtrs', N'mtr', N'meter', N'meters') THEN {weight_qty_sum} ELSE {else_qty_sum} END""" if d_uom and d_qty else else_qty_sum
        summary_sql = f"""SELECT COUNT(*) AS Total_Record_Count, ISNULL(SUM({sum_qty_inner}), 0) AS Total_Qty FROM {q_m} M INNER JOIN {q_d} D ON M.[{m_grn}] = D.[{d_grn}]{join_del} WHERE CAST(M.[{m_date}] AS DATE) BETWEEN ? AND ? AND {mas_del_sql} AND {insp_where}"""
        params = [start_date, end_date]
        cursor.execute(summary_sql, params); sum_row = cursor.fetchone()
        total_record_count = int(sum_row[0] or 0) if sum_row else 0
        total_qty_val = float(sum_row[1] or 0) if sum_row else 0.0
        w_uom = f"LOWER(ISNULL(D.[{d_uom}], N''))" if d_uom else "N''"
        weight_numeric_display = f"""CASE WHEN TRY_CAST(D.[{d_pono}] AS FLOAT) IS NOT NULL THEN TRY_CAST(D.[{d_pono}] AS FLOAT) ELSE 0.0 END""" if d_pono else (f"CASE WHEN ISNULL(D.[{d_qtykgs}], 0) > 0 THEN CAST(D.[{d_qtykgs}] AS FLOAT) ELSE ISNULL(CAST(D.[{d_qty}] AS FLOAT), 0) END" if d_qtykgs else f"ISNULL(CAST(D.[{d_qty}] AS FLOAT), 0)")
        qty_sql = f"""CASE WHEN {w_uom} IN (N'kgs', N'kg', N'mtrs', N'mtr', N'meter', N'meters') THEN CAST(ROUND(CAST({weight_numeric_display} AS FLOAT), 2) AS NVARCHAR(50)) + N' ' + ISNULL(CAST(D.[{d_uom}] AS NVARCHAR(32)), N'') ELSE CAST(ROUND(ISNULL(CAST(D.[{d_qty}] AS FLOAT), 0), 2) AS NVARCHAR(50)) + N' ' + ISNULL(CAST(D.[{d_uom}] AS NVARCHAR(32)), N'') END""" if d_uom and d_qty else (f"CAST(ROUND(ISNULL(CAST(D.[{d_qty}] AS FLOAT), 0), 2) AS NVARCHAR(50))" + (f" + N' ' + ISNULL(CAST(D.[{d_uom}] AS NVARCHAR(32)), N'')" if d_uom else "") if d_qty else "N''")
        sql = f"""SELECT TOP 500 M.[{m_grn}] AS GRN_No, M.[{m_date}] AS GRN_Date, {dtype_sel} AS Type_, CAST({mat_sql} AS NVARCHAR(800)) AS Material_, CAST({qty_sql} AS NVARCHAR(120)) AS Qty_ FROM {q_m} M INNER JOIN {q_d} D ON M.[{m_grn}] = D.[{d_grn}]{join_del} WHERE CAST(M.[{m_date}] AS DATE) BETWEEN ? AND ? AND {mas_del_sql} AND {insp_where} ORDER BY M.[{m_date}] DESC, M.[{m_grn}]"""
        cursor.execute(sql, params); rows_out = []
        for row in cursor.fetchall() or []:
            gdt = row[1]
            rows_out.append({"grn_no": str(row[0]).strip() if row[0] is not None else "", "grn_date": gdt.isoformat()[:10] if gdt is not None and hasattr(gdt, "isoformat") else (str(gdt)[:10] if gdt else ""), "type": str(row[2]).strip() if row[2] is not None else "", "material": str(row[3]).strip() if row[3] is not None else "", "qty": str(row[4]).strip() if row[4] is not None else ""})
        cursor.close(); conn.close()
        return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "summary": {"total_record_count": total_record_count, "total_qty": total_qty_val}, "rows": rows_out, "warnings": warnings})
    except Exception as e:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass
        return Response({"error": f"Database error: {str(e)}", "from": str(start_date), "to": str(end_date), "summary": None, "rows": []}, status=500)

@api_view(["GET"])
def dashboard2_iqc_rejections(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    cursor = None; warnings = []
    try:
        cursor = conn.cursor()
        sch_gm, nm_gm, q_gm = resolve_erp_table(cursor, ["grn_mas", "GRN_MAS", "Grn_Mas", "GrnMas", "GRNMast", "grnmast"])
        sch_im, nm_im, q_im = resolve_erp_table(cursor, ["inspmas", "InspMas", "INSPMAS", "Insp_Mas", "InspMas"])
        sch_id, nm_id, q_id = resolve_erp_table(cursor, ["inspdet", "InspDet", "INSPDET", "Insp_Det", "InspDet"])
        sch_cm, nm_cm, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST"])
        if not q_gm or not q_im or not q_id: cursor.close(); conn.close(); return Response({"from": str(start_date), "to": str(end_date), "summary": None, "rows": [], "error": "grn_mas, inspmas, or inspdet table not found."}, status=404)
        gm_grn = find_column_ci(cursor, sch_gm, nm_gm, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        gm_date = find_column_ci(cursor, sch_gm, nm_gm, ["grndate", "GRNDate", "GRNDATE", "Grn_Date"])
        gm_del = find_column_ci(cursor, sch_gm, nm_gm, ["deleted", "Deleted", "IsDeleted"])
        gm_dtype = find_column_ci(cursor, sch_gm, nm_gm, ["dtype", "DType", "GRNType", "Type"])
        gm_cid = find_column_ci(cursor, sch_gm, nm_gm, ["cid", "CId", "CID", "CustId", "custid"])
        im_grn = find_column_ci(cursor, sch_im, nm_im, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        im_irno = find_column_ci(cursor, sch_im, nm_im, ["irno", "IRNo", "IRNO", "IrNo", "InspNo"])
        im_irdate = find_column_ci(cursor, sch_im, nm_im, ["irdate", "IRDate", "IRDATE", "Ir_Date", "InspDate", "inspdate"])
        im_del = find_column_ci(cursor, sch_im, nm_im, ["deleted", "Deleted", "IsDeleted"])
        d_irno = find_column_ci(cursor, sch_id, nm_id, ["irno", "IRNo", "IRNO", "IrNo"])
        d_del = find_column_ci(cursor, sch_id, nm_id, ["deleted", "Deleted", "IsDeleted"])
        d_part = find_column_ci(cursor, sch_id, nm_id, ["partno", "PartNo", "PARTNO", "Part_No", "ItCode", "itcode"])
        d_desc = find_column_ci(cursor, sch_id, nm_id, ["description", "Description", "DESCRIPTION", "Descr", "descr", "PartName"])
        d_matrej = find_column_ci(cursor, sch_id, nm_id, ["matrej", "MatRej", "MATREJ", "Mat_Rej", "mat_rej"])
        d_macrej = find_column_ci(cursor, sch_id, nm_id, ["macrej", "MacRej", "MACREJ", "Mac_Rej", "mac_rej"])
        if not gm_grn or not gm_date or not im_grn or not im_irno or not im_irdate or not d_irno or not d_matrej or not d_macrej: cursor.close(); conn.close(); return Response({"error": "Required columns not found.", "from": str(start_date), "to": str(end_date), "summary": None, "rows": []}, status=500)
        mat_e = f"ISNULL(CAST(D.[{d_matrej}] AS FLOAT), 0)" if d_matrej else "CAST(0 AS FLOAT)"
        mac_e = f"ISNULL(CAST(D.[{d_macrej}] AS FLOAT), 0)" if d_macrej else "CAST(0 AS FLOAT)"
        rej_sum = f"({mat_e} + {mac_e})"; rej_filter = f"({mat_e} > 0 OR {mac_e} > 0)"
        part_e = f"CAST(D.[{d_part}] AS NVARCHAR(256))" if d_part else "CAST(N'' AS NVARCHAR(256))"
        desc_e = f"CAST(D.[{d_desc}] AS NVARCHAR(512))" if d_desc else "CAST(N'' AS NVARCHAR(512))"
        mat_sql = f"ISNULL({part_e}, N'') + N' - ' + ISNULL({desc_e}, N'')"
        dtype_sel = f"CAST(GM.[{gm_dtype}] AS NVARCHAR(128))" if gm_dtype else "CAST(NULL AS NVARCHAR(128))"
        gm_del_sql = f"ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else "1=1"
        im_del_sql = f"ISNULL(IM.[{im_del}], 0) = 0" if im_del else "1=1"
        join_d_del = f" AND ISNULL(D.[{d_del}], 0) = 0" if d_del else ""
        cm_join = ""; vendor_sql = "CAST(NULL AS NVARCHAR(512))"
        if q_cm and gm_cid:
            cm_id = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId", "custid"])
            cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName", "Name"])
            cm_del = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"])
            if cm_id and cm_name:
                cm_del_x = f" AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
                cm_join = f"LEFT JOIN {q_cm} CM ON GM.[{gm_cid}] = CM.[{cm_id}]{cm_del_x}"; vendor_sql = f"CAST(CM.[{cm_name}] AS NVARCHAR(512))"
        base_from = f"""FROM {q_gm} GM INNER JOIN {q_im} IM ON GM.[{gm_grn}] = IM.[{im_grn}] AND {im_del_sql} INNER JOIN {q_id} D ON IM.[{im_irno}] = D.[{d_irno}]{join_d_del} {cm_join}"""
        date_where = f"""CAST(GM.[{gm_date}] AS DATE) BETWEEN ? AND ? AND CAST(IM.[{im_irdate}] AS DATE) BETWEEN ? AND ? AND {gm_del_sql} AND {rej_filter}"""
        params = [start_date, end_date, start_date, end_date]
        summary_sql = f"""SELECT COUNT(*) AS Total_Record_Count, ISNULL(SUM({rej_sum}), 0) AS Total_Rejection_Qty {base_from} WHERE {date_where}"""
        cursor.execute(summary_sql, params); sum_row = cursor.fetchone()
        total_rec = int(sum_row[0] or 0) if sum_row else 0; total_rej = float(sum_row[1] or 0) if sum_row else 0.0
        detail_sql = f"""SELECT TOP 500 D.[{d_irno}] AS GRN_Insp_No, IM.[{im_irdate}] AS GRN_Insp_Date, {dtype_sel} AS Type_, {vendor_sql} AS Vendor_Name, CAST({mat_sql} AS NVARCHAR(800)) AS Material_, CAST({rej_sum} AS FLOAT) AS Total_Rejection_Qty {base_from} WHERE {date_where} ORDER BY IM.[{im_irdate}] DESC, D.[{d_irno}]"""
        cursor.execute(detail_sql, params); rows_out = []
        for row in cursor.fetchall() or []:
            idt = row[1]
            rows_out.append({"grn_insp_no": str(row[0]).strip() if row[0] is not None else "", "grn_insp_date": idt.isoformat()[:10] if idt is not None and hasattr(idt, "isoformat") else (str(idt)[:10] if idt else ""), "type": str(row[2]).strip() if row[2] is not None else "", "vendor_name": str(row[3]).strip() if row[3] is not None else "", "material": str(row[4]).strip() if row[4] is not None else "", "total_rejection_qty": float(row[5] or 0) if row[5] is not None else 0.0})
        cursor.close(); conn.close()
        return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "summary": {"total_record_count": total_rec, "total_rejection_qty": total_rej}, "rows": rows_out, "warnings": warnings})
    except Exception as e:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass
        return Response({"error": f"Database error: {str(e)}", "from": str(start_date), "to": str(end_date), "summary": None, "rows": []}, status=500)

@api_view(["GET"])
def dashboard2_otd(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    company_code = tenant.get("company_code")
    try: cursor = conn.cursor()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    tbl_po_mas = find_first_table(cursor, candidates=["In_PoMas", "in_pomas", "IN_POMAS"])
    tbl_shd = find_first_table(cursor, candidates=["In_PoDet_ShdQty", "in_podet_shdqty", "IN_PODET_SHDQTY"])
    tbl_dc_mas = find_first_table(cursor, candidates=["dc_mas", "Dc_Mas", "DC_Mas", "DcMas"])
    tbl_dc_det = find_first_table(cursor, candidates=["DcInSubDet", "dcinsubdet", "DCINSUBDET"])
    tbl_dc_assm = find_first_table(cursor, candidates=["DcInSubDetAssmPoDet", "dcinsubdetassmpodet", "DCINSUBDETASSMPODET"])
    tbl_rating = find_first_table(cursor, candidates=["CustPoOTDRating", "custpootdrating", "CUSTPOOTDRATING"])
    if not all([tbl_po_mas, tbl_shd, tbl_dc_mas, tbl_dc_det, tbl_dc_assm]):
        cursor.close(); conn.close()
        missing = [n for n, t in [("In_PoMas", tbl_po_mas), ("In_PoDet_ShdQty", tbl_shd), ("dc_mas", tbl_dc_mas), ("DcInSubDet", tbl_dc_det), ("DcInSubDetAssmPoDet", tbl_dc_assm)] if not t]
        return Response({"error": f"Missing table(s) for OTD: {', '.join(missing)}"}, status=404)
    po_apono = find_first_column(cursor, tbl_po_mas, ["APono", "apono", "APNO", "PONo", "pono", "PoNo"])
    po_deleted = find_first_column(cursor, tbl_po_mas, ["deleted", "Deleted", "is_deleted"])
    po_company = find_first_column(cursor, tbl_po_mas, ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"])
    sh_apono = find_first_column(cursor, tbl_shd, ["APono", "apono", "APNO", "PONo", "pono"])
    sh_itcode = find_first_column(cursor, tbl_shd, ["itcode", "ItCode", "ITCODE", "PartNo", "partno", "Part_No"])
    sh_req = find_first_column(cursor, tbl_shd, ["reqdate", "ReqDate", "REQDATE", "Req_Dt", "req_dt"])
    sh_deleted = find_first_column(cursor, tbl_shd, ["deleted", "Deleted", "is_deleted"])
    dcno_m = find_first_column(cursor, tbl_dc_mas, ["dcno", "DcNo", "DCNO", "DC_No"])
    dc_dt = find_first_column(cursor, tbl_dc_mas, ["dcdate", "DcDate", "DCDT", "DC_DT", "dcdt", "date", "Date"])
    dc_m_deleted = find_first_column(cursor, tbl_dc_mas, ["deleted", "Deleted", "is_deleted"])
    dc_m_company = find_first_column(cursor, tbl_dc_mas, ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"])
    def dc_cols(tbl): return {"apono": find_first_column(cursor, tbl, ["apono", "APono", "APNO", "PONo", "pono"]), "partno": find_first_column(cursor, tbl, ["partno", "PartNo", "PARTNO", "itcode", "ItCode"]), "dcno": find_first_column(cursor, tbl, ["dcno", "DcNo", "DCNO"]), "ok": find_first_column(cursor, tbl, ["okqty", "OkQty", "OKQty"]), "matrej": find_first_column(cursor, tbl, ["matrej", "MatRej", "MATREJ"]), "macrej": find_first_column(cursor, tbl, ["macrej", "MacRej", "MACREJ"]), "uncomp": find_first_column(cursor, tbl, ["uncompqty", "UncompQty", "UNCOMPQTY", "uncomp_qty"]), "deleted": find_first_column(cursor, tbl, ["deleted", "Deleted", "is_deleted"])}
    c1 = dc_cols(tbl_dc_det); c2 = dc_cols(tbl_dc_assm)
    required = [(f"{tbl_po_mas}.apono", po_apono), (f"{tbl_shd}.apono", sh_apono), (f"{tbl_shd}.itcode", sh_itcode), (f"{tbl_shd}.reqdate", sh_req), (f"{tbl_dc_mas}.dcno", dcno_m), (f"{tbl_dc_mas}.dcdate", dc_dt), (f"{tbl_dc_det}.apono", c1["apono"]), (f"{tbl_dc_det}.partno", c1["partno"]), (f"{tbl_dc_det}.dcno", c1["dcno"]), (f"{tbl_dc_assm}.apono", c2["apono"]), (f"{tbl_dc_assm}.partno", c2["partno"]), (f"{tbl_dc_assm}.dcno", c2["dcno"])]
    for label, col in required:
        if not col: cursor.close(); conn.close(); return Response({"error": f"OTD: could not resolve column for {label}"}, status=422)
    qty_expr_det = " + ".join([f"COALESCE(CAST(d.[{c}] AS FLOAT), 0)" for c in [c1["ok"], c1["matrej"], c1["macrej"], c1["uncomp"]] if c]) or "0"
    qty_expr_assm = " + ".join([f"COALESCE(CAST(a.[{c}] AS FLOAT), 0)" for c in [c2["ok"], c2["matrej"], c2["macrej"], c2["uncomp"]] if c]) or "0"
    def filt_po(alias):
        parts = [f"[{alias}].[{po_deleted}] = 0"] if po_deleted else []
        if po_company and company_code: parts.append(f"[{alias}].[{po_company}] = ?")
        return " AND " + " AND ".join(parts) if parts else ""
    def filt_dc_mas(alias):
        parts = [f"CAST([{alias}].[{dc_dt}] AS DATE) BETWEEN ? AND ?"]
        if dc_m_deleted: parts.append(f"[{alias}].[{dc_m_deleted}] = 0")
        if dc_m_company and company_code: parts.append(f"[{alias}].[{dc_m_company}] = ?")
        return " AND ".join(parts)
    sh_where = f"[{sh_deleted}] = 0" if sh_deleted else "1=1"
    d_del = f"d.[{c1['deleted']}] = 0" if c1["deleted"] else "1=1"
    a_del = f"a.[{c2['deleted']}] = 0" if c2["deleted"] else "1=1"
    join_po = f"INNER JOIN [{tbl_po_mas}] p ON p.[{po_apono}] = d.[{c1['apono']}]{filt_po('p')}"
    union_sql = f"""SELECT d.[{c1['dcno']}] AS dcno, LTRIM(RTRIM(CAST(d.[{c1['apono']}] AS NVARCHAR(64)))) AS apono, LTRIM(RTRIM(CAST(d.[{c1['partno']}] AS NVARCHAR(128)))) AS partno, CAST(m.[{dc_dt}] AS DATE) AS dc_date, ({qty_expr_det}) AS del_qty FROM [{tbl_dc_det}] d INNER JOIN [{tbl_dc_mas}] m ON m.[{dcno_m}] = d.[{c1['dcno']}] {join_po} WHERE {d_del} AND {filt_dc_mas('m')} UNION ALL SELECT a.[{c2['dcno']}] AS dcno, LTRIM(RTRIM(CAST(a.[{c2['apono']}] AS NVARCHAR(64)))) AS apono, LTRIM(RTRIM(CAST(a.[{c2['partno']}] AS NVARCHAR(128)))) AS partno, CAST(m2.[{dc_dt}] AS DATE) AS dc_date, ({qty_expr_assm}) AS del_qty FROM [{tbl_dc_assm}] a INNER JOIN [{tbl_dc_mas}] m2 ON m2.[{dcno_m}] = a.[{c2['dcno']}] INNER JOIN [{tbl_po_mas}] p2 ON p2.[{po_apono}] = a.[{c2['apono']}]{filt_po('p2')} WHERE {a_del} AND {filt_dc_mas('m2')}"""
    rf = rt = rfor = None
    if tbl_rating:
        rf = find_first_column(cursor, tbl_rating, ["RatingFrom", "ratingfrom", "RATINGFROM"])
        rt = find_first_column(cursor, tbl_rating, ["RatingTo", "ratingto", "RATINGTO"])
        rfor = find_first_column(cursor, tbl_rating, ["RatingFor", "ratingfor", "RATINGFOR"])
    rating_join = ""; rating_expr = "CAST(0 AS FLOAT)"
    if tbl_rating and rf and rt and rfor:
        rating_join = f"LEFT JOIN [{tbl_rating}] r ON j.days_late >= r.[{rf}] AND j.days_late <= r.[{rt}]"; rating_expr = f"COALESCE(CAST(r.[{rfor}] AS FLOAT), 0)"
    def append_po_params():
        pl = []
        if po_company and company_code: pl.append(company_code)
        return pl
    def append_dc_params():
        pl = [start_date, end_date]
        if dc_m_company and company_code: pl.append(company_code)
        return pl
    union_params = append_po_params() + append_dc_params() + append_po_params() + append_dc_params()
    main_sql = f"""WITH sch AS (SELECT LTRIM(RTRIM(CAST([{sh_apono}] AS NVARCHAR(64)))) AS apono, LTRIM(RTRIM(CAST([{sh_itcode}] AS NVARCHAR(128)))) AS itcode, MIN(CAST([{sh_req}] AS DATE)) AS reqdate FROM [{tbl_shd}] WHERE {sh_where} GROUP BY LTRIM(RTRIM(CAST([{sh_apono}] AS NVARCHAR(64)))), LTRIM(RTRIM(CAST([{sh_itcode}] AS NVARCHAR(128))))), del AS ({union_sql}), joined AS (SELECT del.dc_date, del.del_qty, sch.reqdate, CASE WHEN del.dc_date <= sch.reqdate THEN 0 ELSE DATEDIFF(DAY, sch.reqdate, del.dc_date) END AS days_late FROM del INNER JOIN sch ON sch.apono = del.apono AND sch.itcode = del.partno) SELECT COALESCE(SUM(CASE WHEN j.dc_date <= j.reqdate THEN j.del_qty ELSE 0 END), 0) AS on_time_qty, COALESCE(SUM(j.del_qty), 0) AS total_qty, COALESCE(SUM(CASE WHEN j.dc_date > j.reqdate THEN 1 ELSE 0 END), 0) AS delayed_lines, COALESCE(SUM(CAST(j.del_qty AS FLOAT) * ({rating_expr})), 0) AS rating_num FROM joined j {rating_join}"""
    trend_sql = f"""WITH sch AS (SELECT LTRIM(RTRIM(CAST([{sh_apono}] AS NVARCHAR(64)))) AS apono, LTRIM(RTRIM(CAST([{sh_itcode}] AS NVARCHAR(128)))) AS itcode, MIN(CAST([{sh_req}] AS DATE)) AS reqdate FROM [{tbl_shd}] WHERE {sh_where} GROUP BY LTRIM(RTRIM(CAST([{sh_apono}] AS NVARCHAR(64)))), LTRIM(RTRIM(CAST([{sh_itcode}] AS NVARCHAR(128))))), del AS ({union_sql}), joined AS (SELECT del.dc_date, del.del_qty, sch.reqdate FROM del INNER JOIN sch ON sch.apono = del.apono AND sch.itcode = del.partno) SELECT YEAR(j.dc_date) AS y, MONTH(j.dc_date) AS m, COALESCE(SUM(CASE WHEN j.dc_date <= j.reqdate THEN j.del_qty ELSE 0 END), 0) AS on_time_qty, COALESCE(SUM(j.del_qty), 0) AS total_qty FROM joined j GROUP BY YEAR(j.dc_date), MONTH(j.dc_date) ORDER BY YEAR(j.dc_date), MONTH(j.dc_date)"""
    try:
        cursor.execute(main_sql, union_params); row = cursor.fetchone()
        if not row:
            row = (0, 0, 0, 0)
        on_time_qty = float(row[0] or 0); total_qty = float(row[1] or 0); delayed_lines = int(row[2] or 0); rating_num = float(row[3] or 0)
        cursor.execute(trend_sql, union_params); trend_rows = cursor.fetchall()
    except Exception as e: cursor.close(); conn.close(); return Response({"error": f"Database error: {str(e)}"}, status=500)
    cursor.close(); conn.close()
    otd_pct = round((on_time_qty / total_qty) * 100, 2) if total_qty > 0 else None
    rating_weighted_pct = round((rating_num / total_qty), 2) if total_qty > 0 else None
    month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    trend = []
    for tr in trend_rows or []:
        y, m, otq, tq = int(tr[0]), int(tr[1]), float(tr[2] or 0), float(tr[3] or 0)
        pct = round((otq / tq) * 100, 2) if tq > 0 else None
        trend.append({"year": y, "month": m, "label": f"{month_names[m - 1]} {y}", "on_time_delivery_pct": pct, "total_qty": round(tq, 2)})
    schedule_adherence_pct = rating_weighted_pct if rating_weighted_pct is not None else otd_pct
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "kpis": {"on_time_delivery_pct": otd_pct, "rating_weighted_pct": rating_weighted_pct, "schedule_adherence_pct": schedule_adherence_pct, "delayed_lines": delayed_lines, "on_time_qty": round(on_time_qty, 2), "total_del_qty": round(total_qty, 2)}, "trend": trend})

@api_view(['GET'])
def otd_report(request):
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)
        
    start_date, end_date = parse_date_range(request)
    fy_label = get_fy_label(start_date, end_date)
    buckets, labels = generate_month_buckets(start_date, end_date)
    
    cte = """
    WITH AllSchedules AS (
        SELECT s.Apono, s.itcode AS partno, s.poslno, s.reqdate, s.shddate, s.shdQty,
               COALESCE(
                   NULLIF(TRY_CAST(s.shddate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 120),
                   NULLIF(TRY_CAST(s.reqdate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 120),
                   CAST(p.podt AS DATE)
               ) AS targetdate,
               YEAR(COALESCE(
                   NULLIF(TRY_CAST(s.shddate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 120),
                   NULLIF(TRY_CAST(s.reqdate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 120),
                   CAST(p.podt AS DATE)
               )) AS PoYear,
               MONTH(COALESCE(
                   NULLIF(TRY_CAST(s.shddate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 120),
                   NULLIF(TRY_CAST(s.reqdate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 120),
                   CAST(p.podt AS DATE)
               )) AS PoMonth
        FROM In_PoDet_ShdQty s
        INNER JOIN In_PoMas p ON s.Apono = p.Apono
        LEFT JOIN CustMast cm ON p.cid = cm.Id
        LEFT JOIN CustAliasMast ca ON p.cid = ca.Id
        WHERE COALESCE(
                   NULLIF(TRY_CAST(s.shddate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.shddate AS NVARCHAR(50)), 120),
                   NULLIF(TRY_CAST(s.reqdate AS DATE), '1900-01-01'),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 105),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 103),
                   TRY_CONVERT(DATE, CAST(s.reqdate AS NVARCHAR(50)), 120),
                   CAST(p.podt AS DATE)
               ) BETWEEN ? AND ?
          AND ISNULL(s.deleted, 0) = 0
          AND ISNULL(p.deleted, 0) = 0
    ),
    AllDeliveries AS (
        SELECT d.Apono, d.partno, d.poslno, CAST(m.dcdate AS DATE) AS dcdate, d.okqty
        FROM DcInSubDetAssmPoDet d
        INNER JOIN DC_Mas m ON d.dcno = m.dcno
        WHERE d.deleted = 0
        UNION ALL
        SELECT d.Apono, d.partno, d.poslno, CAST(m.dcdate AS DATE) AS dcdate, d.okqty
        FROM DcInSubDet d
        INNER JOIN DC_Mas m ON d.dcno = m.dcno
        WHERE d.deleted = 0
    ),
    DeliverySummary AS (
        SELECT sch.Apono, sch.partno, sch.poslno, sch.shdQty, sch.targetdate, sch.PoYear, sch.PoMonth,
               ISNULL(SUM(CASE WHEN del.dcdate <= sch.targetdate THEN del.okqty ELSE 0 END), 0) AS OnTimeDelQty,
               ISNULL(SUM(CASE WHEN del.dcdate > sch.targetdate THEN del.okqty ELSE 0 END), 0) AS DelayedDelQty,
               ISNULL(SUM(del.okqty), 0) AS TotalDelQty,
               MAX(CASE WHEN del.dcdate > sch.targetdate THEN del.dcdate ELSE NULL END) AS LastDelayedDcDate
        FROM AllSchedules sch
        LEFT JOIN AllDeliveries del
            ON sch.Apono = del.Apono AND sch.partno = del.partno AND sch.poslno = del.poslno
        GROUP BY sch.Apono, sch.partno, sch.poslno, sch.shdQty, sch.targetdate, sch.PoYear, sch.PoMonth
    ),
    OTDCalc AS (
        SELECT ds.PoYear, ds.PoMonth,
               ds.shdQty,
               ds.TotalDelQty,
               ds.OnTimeDelQty AS on_time_qty,
               CASE WHEN ds.DelayedDelQty > 0 THEN 1 ELSE 0 END AS delayed_flag,
               CASE
                   WHEN ds.TotalDelQty = 0 THEN 0.0
                   WHEN ds.DelayedDelQty = 0 THEN 100.0
                   ELSE ISNULL(
                       (SELECT TOP 1 r2.RatingFor FROM CustPoOTDRating r2
                        WHERE DATEDIFF(DAY, ds.targetdate, ds.LastDelayedDcDate)
                              BETWEEN r2.RatingFrom AND r2.RatingTo),
                       0.0
                   )
               END AS OTDScore
        FROM DeliverySummary ds
        WHERE ds.TotalDelQty > 0
    )
    """

    monthly_tail = """
    SELECT PoYear, PoMonth, AVG(OTDScore) as AvgOTD, COUNT(*) as CompletedSchedules
    FROM OTDCalc GROUP BY PoYear, PoMonth ORDER BY PoYear, PoMonth
    """

    kpi_tail = """
    SELECT AVG(OTDScore) AS overall_otd,
           ISNULL(SUM(CAST(shdQty AS FLOAT)), 0) AS total_qty,
           ISNULL(SUM(on_time_qty), 0) AS on_time_qty,
           ISNULL(SUM(delayed_flag), 0) AS delayed_lines,
           COUNT(*) AS completed_lines
    FROM OTDCalc
    """

    data_map = {b: 0.0 for b in buckets}
    overall_otd = 0.0
    delayed_lines = 0
    on_time_qty = 0.0
    total_qty = 0.0

    cursor = None
    try:
        cursor = conn.cursor()
        cursor.execute(cte + kpi_tail, (start_date, end_date))
        kpi_row = cursor.fetchone()
        if kpi_row:
            overall_otd = round(float(kpi_row[0] or 0), 2)
            total_qty = round(float(kpi_row[1] or 0), 2)
            on_time_qty = round(float(kpi_row[2] or 0), 2)
            delayed_lines = int(kpi_row[3] or 0)

        cursor.execute(cte + monthly_tail, (start_date, end_date))
        for row in cursor.fetchall() or []:
            yr, mth = int(row[0] or 0), int(row[1] or 0)
            avg_otd = round(float(row[2] or 0), 2)
            k = (yr, mth)
            if k in data_map:
                data_map[k] = avg_otd

        cursor.close()
        conn.close()
    except Exception as e:
        if cursor:
            try: cursor.close()
            except Exception: pass
        try: conn.close()
        except Exception: pass
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    data_list = [data_map[b] for b in buckets]
    month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    trend = []
    for b in buckets:
        yr, mth = b
        trend.append({
            "year": yr,
            "month": mth,
            "label": f"{month_names[mth - 1]} {yr}",
            "on_time_delivery_pct": data_map[b],
            "total_qty": total_qty
        })

    return Response({
        "company": tenant.get("company_name", ""),
        "company_code": tenant.get("company_code", ""),
        "fy": fy_label,
        "from": str(start_date),
        "to": str(end_date),
        "labels": labels,
        "data": data_list,
        "kpis": {
            "on_time_delivery_pct": overall_otd,
            "rating_weighted_pct": overall_otd,
            "schedule_adherence_pct": overall_otd,
            "delayed_lines": delayed_lines,
            "on_time_qty": on_time_qty,
            "total_del_qty": total_qty
        },
        "trend": trend
    })

@api_view(['GET'])
def dashboard2_final_inspection_kpi(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    from_param = (request.GET.get("from") or "").strip(); to_param = (request.GET.get("to") or "").strip()
    if from_param and to_param:
        try: start_date = datetime.strptime(from_param, "%Y-%m-%d").date(); end_date = datetime.strptime(to_param, "%Y-%m-%d").date()
        except ValueError: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    else: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    try:
        cursor = conn.cursor()
        if not table_exists(cursor, "FinalInspectionEntry"): cursor.close(); conn.close(); return Response({"error": "Table FinalInspectionEntry not found in this database."}, status=404)
        company_col = find_first_column(cursor, "FinalInspectionEntry", company_candidates)
        company_code = tenant.get("company_code")
        sql = """SELECT COALESCE(SUM(CAST(okqty AS FLOAT)), 0) AS total_ok_qty, COALESCE(SUM(CAST(rejqty AS FLOAT)), 0) AS total_rej_qty, COALESCE(SUM(CAST(matrejqty AS FLOAT)), 0) AS total_mat_rej_qty, COALESCE(SUM(CAST(totqty AS FLOAT)), 0) AS total_qty, COUNT(finspno) AS inspection_count FROM FinalInspectionEntry WHERE deleted = 0 AND CAST(finspdate AS DATE) BETWEEN ? AND ?"""
        params = [start_date, end_date]
        if company_col and company_code: sql += f" AND [{company_col}] = ?"; params.append(company_code)
        cursor.execute(sql, params); row = cursor.fetchone(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    if row:
        total_ok_qty = float(row[0] or 0); total_rej_qty = float(row[1] or 0); total_mat_rej_qty = float(row[2] or 0)
        total_qty = float(row[3] or 0); inspection_count = int(row[4] or 0)
    else:
        total_ok_qty = total_rej_qty = total_mat_rej_qty = total_qty = 0.0
        inspection_count = 0
    first_pass_yield = round((total_ok_qty / total_qty) * 100, 2) if total_qty > 0 else 0.0
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "total_ok_qty": round(total_ok_qty, 2), "total_rej_qty": round(total_rej_qty, 2), "total_mat_rej_qty": round(total_mat_rej_qty, 2), "total_qty": round(total_qty, 2), "first_pass_yield": first_pass_yield, "inspection_count": inspection_count})

@api_view(["GET"])
def dashboard2_injob_inspection(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    from_param = (request.GET.get("from") or "").strip(); to_param = (request.GET.get("to") or "").strip()
    if from_param and to_param:
        try: start_date = datetime.strptime(from_param, "%Y-%m-%d").date(); end_date = datetime.strptime(to_param, "%Y-%m-%d").date()
        except ValueError: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    else: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    deleted_candidates = ["deleted", "is_deleted", "Deleted", "IsDeleted"]
    date_candidates = ["inspdate", "InspDate", "INSPDATE", "insp_date"]
    join_candidates = ["inspno", "InspNo", "INSPNO"]
    qty_basis_candidates = ["totqty", "TotQty", "TOTQTY", "qty", "Qty", "QTY", "okqty", "OkQty", "OKQty", "inspqty", "InspQty", "INSPQTY"]
    try:
        cursor = conn.cursor()
        mas_tbl = find_first_table(cursor, ["InJob_Mas", "INJOB_MAS", "injob_mas"])
        det_tbl = find_first_table(cursor, ["InJob_Det", "INJOB_DET", "injob_det"])
        if not mas_tbl or not det_tbl: cursor.close(); conn.close(); return Response({"error": "InJob_Mas / InJob_Det not found in this database.", "from": str(start_date), "to": str(end_date)}, status=404)
        join_m = find_first_column(cursor, mas_tbl, join_candidates); join_d = find_first_column(cursor, det_tbl, join_candidates)
        if not join_m or not join_d: cursor.close(); conn.close(); return Response({"error": "Join column inspno not found on InJob_Mas / InJob_Det."}, status=404)
        mas_date = find_first_column(cursor, mas_tbl, date_candidates)
        if not mas_date: cursor.close(); conn.close(); return Response({"error": "Date column (e.g. inspdate) not found on InJob_Mas."}, status=404)
        matrej_c = find_first_column(cursor, det_tbl, ["matrej", "MatRej", "MATREJ"])
        macrej_c = find_first_column(cursor, det_tbl, ["macrej", "MacRej", "MACREJ"])
        rwqty_c = find_first_column(cursor, det_tbl, ["rwqty", "RwQty", "RWQTY", "rw_qty", "RW_Qty"])
        mas_del = find_first_column(cursor, mas_tbl, deleted_candidates); det_del = find_first_column(cursor, det_tbl, deleted_candidates)
        mas_cc = find_first_column(cursor, mas_tbl, company_candidates); company_code = tenant.get("company_code")
        rej_parts = []
        if matrej_c: rej_parts.append(f"COALESCE(CAST(D.[{matrej_c}] AS FLOAT), 0)")
        if macrej_c: rej_parts.append(f"COALESCE(CAST(D.[{macrej_c}] AS FLOAT), 0)")
        if not rej_parts: cursor.close(); conn.close(); return Response({"error": "Neither matrej nor macrej column found on InJob_Det."}, status=404)
        inner_rejection = " + ".join(rej_parts)
        sql_total_rejection = f"COALESCE(SUM({inner_rejection}), 0)"
        sql_total_rework = f"COALESCE(SUM(COALESCE(CAST(D.[{rwqty_c}] AS FLOAT), 0)), 0)" if rwqty_c else "CAST(0 AS FLOAT)"
        qty_basis_col = find_first_column(cursor, det_tbl, qty_basis_candidates)
        sql_total_qty_basis = f"COALESCE(SUM(COALESCE(CAST(D.[{qty_basis_col}] AS FLOAT), 0)), 0)" if qty_basis_col else "CAST(0 AS FLOAT)"
        where_parts = [f"CAST(M.[{mas_date}] AS DATE) BETWEEN ? AND ?"]; params = [start_date, end_date]
        if mas_del: where_parts.append(f"M.[{mas_del}] = 0")
        if det_del: where_parts.append(f"(D.[{det_del}] IS NULL OR D.[{det_del}] = 0)")
        if mas_cc and company_code: where_parts.append(f"M.[{mas_cc}] = ?"); params.append(company_code)
        where_sql = " AND ".join(where_parts)
        sql = f"""SELECT {sql_total_rejection} AS total_rejection, {sql_total_rework} AS total_rework, {sql_total_qty_basis} AS total_qty_basis, COUNT(DISTINCT M.[{join_m}]) AS inspection_master_count FROM [{mas_tbl}] M INNER JOIN [{det_tbl}] D ON M.[{join_m}] = D.[{join_d}] WHERE {where_sql}"""
        cursor.execute(sql, params); row = cursor.fetchone(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    total_rejection = float((row[0] if row else 0) or 0); total_rework = float((row[1] if row else 0) or 0)
    total_qty_basis = float((row[2] if row else 0) or 0); inspection_master_count = int((row[3] if row else 0) or 0)
    rej_pct = round((total_rejection / total_qty_basis) * 100, 2) if total_qty_basis > 0 else None
    rwk_pct = round((total_rework / total_qty_basis) * 100, 2) if total_qty_basis > 0 else None
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "total_rejection": round(total_rejection, 2), "total_rework": round(total_rework, 2), "total_qty_basis": round(total_qty_basis, 2), "inspection_master_count": inspection_master_count, "rejection_pct": rej_pct, "rework_pct": rwk_pct})

@api_view(["GET"])
def dashboard2_inter_inspection(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    from_param = (request.GET.get("from") or "").strip(); to_param = (request.GET.get("to") or "").strip()
    if from_param and to_param:
        try: start_date = datetime.strptime(from_param, "%Y-%m-%d").date(); end_date = datetime.strptime(to_param, "%Y-%m-%d").date()
        except ValueError: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    else: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    deleted_candidates = ["deleted", "is_deleted", "Deleted", "IsDeleted"]
    date_candidates = ["inter_inspdate", "Inter_InspDate", "INTER_INSPDATE", "interinspdate", "InterInspDate", "inspdate", "InspDate", "INSPDATE", "insp_date"]
    qty_basis_candidates = ["totqty", "TotQty", "TOTQTY", "totinspqty", "TotInspQty", "inspqty", "InspQty", "qty", "Qty", "okqty", "OkQty"]
    try:
        cursor = conn.cursor()
        tbl = find_first_table(cursor, ["InterInspectionEntry", "INTERINSPECTIONENTRY", "interinspectionentry"])
        if not tbl: cursor.close(); conn.close(); return Response({"error": "InterInspectionEntry table not found in this database.", "from": str(start_date), "to": str(end_date)}, status=404)
        date_col = find_first_column(cursor, tbl, date_candidates)
        if not date_col: cursor.close(); conn.close(); return Response({"error": "Date column (e.g. inter_inspdate) not found on InterInspectionEntry."}, status=404)
        rejqty_c = find_first_column(cursor, tbl, ["rejqty", "RejQty", "REJQTY"])
        matrejqty_c = find_first_column(cursor, tbl, ["matrejqty", "MatRejQty", "MATREJQTY", "matrej_qty"])
        rwqty_c = find_first_column(cursor, tbl, ["rwqty", "RwQty", "RWQTY", "rw_qty"])
        rej_parts = []
        if rejqty_c: rej_parts.append(f"COALESCE(CAST([{rejqty_c}] AS FLOAT), 0)")
        if matrejqty_c: rej_parts.append(f"COALESCE(CAST([{matrejqty_c}] AS FLOAT), 0)")
        if not rej_parts: cursor.close(); conn.close(); return Response({"error": "Neither rejqty nor matrejqty column found on InterInspectionEntry."}, status=404)
        inner_rejection = " + ".join(rej_parts)
        sql_total_rejection = f"COALESCE(SUM({inner_rejection}), 0)"
        sql_total_rework = f"COALESCE(SUM(COALESCE(CAST([{rwqty_c}] AS FLOAT), 0)), 0)" if rwqty_c else "CAST(0 AS FLOAT)"
        qty_basis_col = find_first_column(cursor, tbl, qty_basis_candidates)
        sql_total_qty_basis = f"COALESCE(SUM(COALESCE(CAST([{qty_basis_col}] AS FLOAT), 0)), 0)" if qty_basis_col else "CAST(0 AS FLOAT)"
        del_col = find_first_column(cursor, tbl, deleted_candidates); cc_col = find_first_column(cursor, tbl, company_candidates)
        company_code = tenant.get("company_code")
        where_parts = [f"CAST([{date_col}] AS DATE) BETWEEN ? AND ?"]; params = [start_date, end_date]
        if del_col: where_parts.append(f"[{del_col}] = 0")
        if cc_col and company_code: where_parts.append(f"[{cc_col}] = ?"); params.append(company_code)
        where_sql = " AND ".join(where_parts)
        sql = f"""SELECT {sql_total_rejection} AS total_rejection, {sql_total_rework} AS total_rework, {sql_total_qty_basis} AS total_qty_basis, COUNT(*) AS row_count FROM [{tbl}] WHERE {where_sql}"""
        cursor.execute(sql, params); row = cursor.fetchone(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    total_rejection = float((row[0] if row else 0) or 0); total_rework = float((row[1] if row else 0) or 0)
    total_qty_basis = float((row[2] if row else 0) or 0); row_count = int((row[3] if row else 0) or 0)
    rej_pct = round((total_rejection / total_qty_basis) * 100, 2) if total_qty_basis > 0 else None
    rwk_pct = round((total_rework / total_qty_basis) * 100, 2) if total_qty_basis > 0 else None
    return Response({"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "total_rejection": round(total_rejection, 2), "total_rework": round(total_rework, 2), "total_qty_basis": round(total_qty_basis, 2), "row_count": row_count, "rejection_pct": rej_pct, "rework_pct": rwk_pct})

@api_view(["GET"])
def dashboard2_final_inspection_org_rej_rwk(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    from_param = (request.GET.get("from") or "").strip(); to_param = (request.GET.get("to") or "").strip()
    if from_param and to_param:
        try: start_date = datetime.strptime(from_param, "%Y-%m-%d").date(); end_date = datetime.strptime(to_param, "%Y-%m-%d").date()
        except ValueError: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    else: today = date.today(); start_date = date(today.year, today.month, 1); end_date = today
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    deleted_candidates = ["deleted", "is_deleted", "Deleted", "IsDeleted"]
    date_candidates = ["finspdate", "FinSpDate", "FINSPDATE", "fin_sp_date", "Fin_Sp_Date"]
    join_candidates = ["finspno", "FinSpNo", "FINSPNO", "FinspNo"]
    qty_qty_only = ["qty", "Qty", "QTY"]
    try:
        cursor = conn.cursor()
        sch_m, nm_m, q_m = resolve_erp_table(cursor, ["FinalInspectionEntry", "FINALINSPECTIONENTRY", "finalinspectionentry"])
        if not q_m: cursor.close(); conn.close(); return Response({"error": "FinalInspectionEntry not found (check table name / schema).", "from": str(start_date), "to": str(end_date)}, status=404)
        sch_r, nm_r, q_r = resolve_erp_table(cursor, ["FinalInspRejectionEntryOrg", "FINALINSPREJECTIONENTRYORG", "finalinsprejectionentryorg", "FinalInspRejectionOrg", "FINALINSPREJECTIONORG"])
        sch_w, nm_w, q_w = resolve_erp_table(cursor, ["FinalInspReworkEntryOrg", "FINALINSPREWORKENTRYORG", "finalinspreworkentryorg", "FinalInspectionReworkEntryOrg", "FinalInspReworkOrg"])
        join_m = find_column_ci(cursor, sch_m, nm_m, join_candidates)
        if not join_m: cursor.close(); conn.close(); return Response({"error": "finspno (or equivalent) not found on FinalInspectionEntry."}, status=404)
        date_m = find_column_ci(cursor, sch_m, nm_m, date_candidates)
        if not date_m: cursor.close(); conn.close(); return Response({"error": "finspdate (or equivalent) not found on FinalInspectionEntry."}, status=404)
        del_m = find_column_ci(cursor, sch_m, nm_m, deleted_candidates); cc_m = find_column_ci(cursor, sch_m, nm_m, company_candidates)
        company_code = tenant.get("company_code"); partial = False; warnings = []
        if not q_r: partial = True; warnings.append("FinalInspRejectionEntryOrg not found; total_rejection returned as 0.")
        if not q_w: partial = True; warnings.append("FinalInspReworkEntryOrg not found; total_rework returned as 0.")
        use_r = bool(q_r); join_r = qty_r = del_r = None
        if use_r:
            join_r = find_column_ci(cursor, sch_r, nm_r, join_candidates)
            qty_r = find_column_ci(cursor, sch_r, nm_r, qty_qty_only + ["rejqty", "RejQty", "REJQTY", "matrejqty", "MatRejQty"])
            del_r = find_column_ci(cursor, sch_r, nm_r, deleted_candidates)
            if not join_r or not qty_r: use_r = False; partial = True; warnings.append("Rejection org table found but finspno or qty column missing; total_rejection = 0.")
        use_w = bool(q_w); join_w = qty_w = del_w = None
        if use_w:
            join_w = find_column_ci(cursor, sch_w, nm_w, join_candidates)
            qty_w = find_column_ci(cursor, sch_w, nm_w, qty_qty_only + ["rwqty", "RwQty", "RWQTY"])
            del_w = find_column_ci(cursor, sch_w, nm_w, deleted_candidates)
            if not join_w or not qty_w: use_w = False; partial = True; warnings.append("Rework org table found but finspno or qty column missing; total_rework = 0.")
        if not use_r and not use_w: cursor.close(); conn.close(); return Response({"error": "Neither FinalInspRejectionEntryOrg nor FinalInspReworkEntryOrg is usable.", "from": str(start_date), "to": str(end_date)}, status=404)
        rej_where = "1=1"
        if use_r and del_r: rej_where = f"ISNULL([{del_r}], 0) = 0"
        rwk_where = "1=1"
        if use_w and del_w: rwk_where = f"ISNULL([{del_w}], 0) = 0"
        mas_parts = [f"CAST(M.[{date_m}] AS DATE) BETWEEN ? AND ?"]; params = [start_date, end_date]
        if del_m: mas_parts.append(f"ISNULL(M.[{del_m}], 0) = 0")
        if cc_m and company_code: mas_parts.append(f"M.[{cc_m}] = ?"); params.append(company_code)
        mas_where_sql = " AND ".join(mas_parts)
        join_fragments = []
        if use_r: join_fragments.append(f"""LEFT JOIN (SELECT [{join_r}] AS rej_k, SUM(ISNULL(CAST([{qty_r}] AS FLOAT), 0)) AS TotalRejection FROM {q_r} WHERE {rej_where} GROUP BY [{join_r}]) R ON M.[{join_m}] = R.rej_k""")
        if use_w: join_fragments.append(f"""LEFT JOIN (SELECT [{join_w}] AS wrk_k, SUM(ISNULL(CAST([{qty_w}] AS FLOAT), 0)) AS TotalRework FROM {q_w} WHERE {rwk_where} GROUP BY [{join_w}]) W ON M.[{join_m}] = W.wrk_k""")
        sel_rej = "COALESCE(SUM(ISNULL(R.TotalRejection, 0)), 0)" if use_r else "CAST(0 AS FLOAT)"
        sel_rwk = "COALESCE(SUM(ISNULL(W.TotalRework, 0)), 0)" if use_w else "CAST(0 AS FLOAT)"
        sql = f"""SELECT {sel_rej} AS total_rejection, {sel_rwk} AS total_rework FROM {q_m} M {' '.join(join_fragments)} WHERE {mas_where_sql}"""
        cursor.execute(sql, params); row = cursor.fetchone(); cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    total_rejection = float((row[0] if row else 0) or 0); total_rework = float((row[1] if row else 0) or 0)
    resp = {"company": tenant.get("company_name", ""), "company_code": tenant.get("company_code", ""), "from": str(start_date), "to": str(end_date), "total_rejection": round(total_rejection, 2), "total_rework": round(total_rework, 2), "partial": partial}
    if warnings: resp["warnings"] = warnings
    return Response(resp)

@api_view(["GET"])
def dashboard2_top_defect_categories(request):
    try: conn, tenant = get_tenant_connection(request)
    except ValueError as e: return Response({"error": str(e)}, status=401)
    start_date, end_date = dashboard2_parse_date_range_default_month(request)
    company_code = tenant.get("company_code")
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]
    deleted_candidates = ["deleted", "is_deleted", "Deleted", "IsDeleted"]
    branches = []
    try:
        cursor = conn.cursor()
        sch_m, nm_m, q_m = resolve_erp_table(cursor, ["FinalInspectionEntry", "FINALINSPECTIONENTRY", "finalinspectionentry"])
        sch_r, nm_r, q_r = resolve_erp_table(cursor, ["FinalInspRejectionEntryOrg", "FINALINSPREJECTIONENTRYORG", "finalinsprejectionentryorg", "FinalInspRejectionOrg"])
        if q_m and q_r:
            join_cands = ["finspno", "FinSpNo", "FINSPNO", "FinspNo"]
            date_cands = ["finspdate", "FinSpDate", "FINSPDATE", "fin_sp_date"]
            pno_cands = ["partno", "PartNo", "PARTNO", "part_no", "Part_No"]
            qty_cands = ["qty", "Qty", "QTY", "rejqty", "RejQty", "REJQTY"]
            join_m = find_column_ci(cursor, sch_m, nm_m, join_cands)
            date_m = find_column_ci(cursor, sch_m, nm_m, date_cands)
            del_m = find_column_ci(cursor, sch_m, nm_m, deleted_candidates)
            cc_m = find_column_ci(cursor, sch_m, nm_m, company_candidates)
            join_r = find_column_ci(cursor, sch_r, nm_r, join_cands)
            partno_r = find_column_ci(cursor, sch_r, nm_r, pno_cands)
            qty_r = find_column_ci(cursor, sch_r, nm_r, qty_cands)
            del_r = find_column_ci(cursor, sch_r, nm_r, deleted_candidates)
            if join_m and date_m and join_r and partno_r and qty_r:
                where_parts = [f"CAST(F.[{date_m}] AS DATE) BETWEEN ? AND ?"]; params = [start_date, end_date]
                if del_m: where_parts.append(f"ISNULL(F.[{del_m}], 0) = 0")
                if del_r: where_parts.append(f"ISNULL(R.[{del_r}], 0) = 0")
                if cc_m and company_code: where_parts.append(f"F.[{cc_m}] = ?"); params.append(company_code)
                where_parts.append(f"ISNULL(R.[{qty_r}], 0) > 0")
                branch_sql = f"SELECT R.[{partno_r}] AS partno, ISNULL(R.[{qty_r}], 0) AS RejQty FROM {q_m} F INNER JOIN {q_r} R ON F.[{join_m}] = R.[{join_r}] WHERE {' AND '.join(where_parts)}"
                branches.append((branch_sql, params))
        sch_i, nm_i, q_i = resolve_erp_table(cursor, ["InterInspectionEntry", "INTERINSPECTIONENTRY", "interinspectionentry"])
        if q_i:
            date_cands_i = ["inter_inspdate", "Inter_InspDate", "INTER_INSPDATE", "interinspdate", "InterInspDate", "inspdate", "InspDate", "INSPDATE"]
            pno_cands_i = ["partno", "PartNo", "PARTNO", "part_no", "Part_No"]
            rej_cands_i = ["rejqty", "RejQty", "REJQTY", "rej_qty", "matrejqty", "MatRejQty"]
            date_i = find_column_ci(cursor, sch_i, nm_i, date_cands_i)
            partno_i = find_column_ci(cursor, sch_i, nm_i, pno_cands_i)
            rejqty_i = find_column_ci(cursor, sch_i, nm_i, rej_cands_i)
            del_i = find_column_ci(cursor, sch_i, nm_i, deleted_candidates)
            cc_i = find_column_ci(cursor, sch_i, nm_i, company_candidates)
            if date_i and partno_i and rejqty_i:
                where_parts = [f"CAST([{date_i}] AS DATE) BETWEEN ? AND ?"]; params = [start_date, end_date]
                if del_i: where_parts.append(f"ISNULL([{del_i}], 0) = 0")
                if cc_i and company_code: where_parts.append(f"[{cc_i}] = ?"); params.append(company_code)
                where_parts.append(f"ISNULL([{rejqty_i}], 0) > 0")
                branch_sql = f"SELECT [{partno_i}] AS partno, ISNULL([{rejqty_i}], 0) AS RejQty FROM {q_i} WHERE {' AND '.join(where_parts)}"
                branches.append((branch_sql, params))
        if not branches: cursor.close(); conn.close(); return Response({"from": str(start_date), "to": str(end_date), "rows": [], "total_rejection_qty": 0.0, "note": "No matching inspection tables or required columns found."})
        union_sql = " UNION ALL ".join(sql for sql, _ in branches)
        union_params = []
        for _, p in branches: union_params.extend(p)
        final_sql = f"""WITH AllRejection AS ({union_sql}), TotalData AS (SELECT SUM(RejQty) AS TotalQty FROM AllRejection) SELECT TOP 5 A.partno, SUM(A.RejQty) AS Total_Rejection_Qty, CAST((SUM(A.RejQty) * 100.0) / NULLIF(TD.TotalQty, 0) AS DECIMAL(10,2)) AS Rejection_Percentage FROM AllRejection A CROSS JOIN TotalData TD GROUP BY A.partno, TD.TotalQty ORDER BY Total_Rejection_Qty DESC"""
        cursor.execute(final_sql, union_params); rows = cursor.fetchall()
        total_sql = f"WITH AllRejection AS ({union_sql}) SELECT ISNULL(SUM(RejQty), 0) FROM AllRejection"
        cursor.execute(total_sql, union_params); total_row = cursor.fetchone()
        total_qty = float((total_row[0] if total_row else 0) or 0)
        cursor.close(); conn.close()
    except Exception as e: return Response({"error": f"Database error: {str(e)}"}, status=500)
    result_rows = [{"partno": str(row[0] or "").strip() or "—", "total_rejection_qty": float(row[1] or 0), "rejection_pct": float(row[2] or 0)} for row in rows]
    return Response({"from": str(start_date), "to": str(end_date), "rows": result_rows, "total_rejection_qty": round(total_qty, 2)})


# ─────────────────────────────────────────────────────────────
#  FORGOT PASSWORD VERIFICATION & RESET
# ─────────────────────────────────────────────────────────────
@api_view(['POST'])
@authentication_classes([])
@permission_classes([AllowAny])
def forgot_password_verify(request):
    from django.db import connection
    company_code = (request.data.get("company_code") or "").strip()
    company_name = (request.data.get("company_name") or "").strip()
    username     = (request.data.get("username")     or "").strip()

    if not company_code or not company_name or not username:
        return Response({"error": "Company code, company name, and username are required."}, status=400)

    try:
        # Check tenant by company code and name (case-insensitive)
        tenant = Tenant.objects.get(
            company_code__iexact=company_code,
            company_name__iexact=company_name,
            status=True
        )
    except Tenant.DoesNotExist:  # type: ignore
        return Response({"error": "Invalid company code or company name."}, status=404)

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT COUNT(1) FROM tenants_users WHERE UPPER(company_code) = UPPER(%s) AND UPPER(username) = UPPER(%s) AND deleted = 0",
                [tenant.company_code, username]
            )
            exists = cursor.fetchone()[0] > 0
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    if not exists:
        return Response({"error": "User not found under this company."}, status=404)

    return Response({
        "success": True,
        "message": "Identity verified successfully.",
        "company_code": tenant.company_code,
        "username": username
    })


@api_view(['POST'])
@authentication_classes([])
@permission_classes([AllowAny])
def forgot_password_reset(request):
    from django.db import connection
    company_code = (request.data.get("company_code") or "").strip()
    username     = (request.data.get("username")     or "").strip()
    new_password = request.data.get("new_password", "")

    if not company_code or not username or not new_password:
        return Response({"error": "Company code, username, and new password are required."}, status=400)

    if len(new_password) < 6:
        return Response({"error": "Password must be at least 6 characters."}, status=400)

    try:
        with connection.cursor() as cursor:
            # Check if user exists
            cursor.execute(
                "SELECT COUNT(1) FROM tenants_users WHERE UPPER(company_code) = UPPER(%s) AND UPPER(username) = UPPER(%s) AND deleted = 0",
                [company_code, username]
            )
            exists = cursor.fetchone()[0] > 0
            if not exists:
                return Response({"error": "User not found."}, status=404)

            # Update password
            cursor.execute(
                "UPDATE tenants_users SET password = %s WHERE UPPER(company_code) = UPPER(%s) AND UPPER(username) = UPPER(%s) AND deleted = 0",
                [encrypt_password(new_password), company_code, username]
            )
    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    return Response({
        "success": True,
        "message": "Password reset successfully."
    })