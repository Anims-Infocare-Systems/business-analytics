# ════════════════════════════════════════════════════════════════════
#  views_purchaseanalysis.py
#  Purchase Analysis — KPI strip, weekly trend, supplier charts,
#  PO detail table, GRN aging, and management alerts
# ════════════════════════════════════════════════════════════════════

import logging
from calendar import monthrange
from datetime import date

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .utils.cache import cache_analytics_response

logger = logging.getLogger(__name__)

from .views import (
    get_tenant_connection,
    parse_date_range,
    table_exists,
    find_column_ci,
    resolve_erp_table,
    find_first_column,
    dashboard2_parse_date_range_default_month,
)


# ─────────────────────────────────────────────────────────────
#  PRIVATE HELPERS
# ─────────────────────────────────────────────────────────────

_MONTH_ABB = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]


def _pct(part, whole):
    if not whole:
        return 0.0
    return round((float(part or 0) / float(whole)) * 100, 1)


def _to_lakhs(value):
    return round(float(value or 0) / 100_000, 2)


def _fmt_period(start_date, end_date):
    if start_date.year == end_date.year and start_date.month == end_date.month:
        return f"{_MONTH_ABB[start_date.month - 1]} {start_date.year}"
    if start_date.year == end_date.year:
        return (
            f"{_MONTH_ABB[start_date.month - 1]} – "
            f"{_MONTH_ABB[end_date.month - 1]} {end_date.year}"
        )
    return (
        f"{_MONTH_ABB[start_date.month - 1]} {start_date.year} – "
        f"{_MONTH_ABB[end_date.month - 1]} {end_date.year}"
    )


def _week_bounds(year, month, week_num):
    _, last_day = monthrange(year, month)
    if week_num == 5:
        if last_day < 29:
            return None
        return date(year, month, 29), date(year, month, last_day)
    starts = {1: 1, 2: 8, 3: 15, 4: 22}
    ends   = {1: 7, 2: 14, 3: 21, 4: 28}
    return date(year, month, starts[week_num]), date(year, month, min(ends[week_num], last_day))


def _weekly_slots(start_date, end_date):
    labels, keys = [], []
    year, month = start_date.year, start_date.month
    while date(year, month, 1) <= end_date:
        for wn in range(1, 6):
            bounds = _week_bounds(year, month, wn)
            if not bounds:
                continue
            w_start, w_end = bounds
            if w_end < start_date or w_start > end_date:
                continue
            labels.append(f"W{wn} {_MONTH_ABB[month - 1]}")
            keys.append((year, month, wn))
        if month == 12:
            year, month = year + 1, 1
        else:
            month += 1
    return labels, keys


_WEEK_OF_MONTH_CASE = """
    CASE
        WHEN DAY(CAST(podate AS DATE)) BETWEEN 1 AND 7 THEN 1
        WHEN DAY(CAST(podate AS DATE)) BETWEEN 8 AND 14 THEN 2
        WHEN DAY(CAST(podate AS DATE)) BETWEEN 15 AND 21 THEN 3
        WHEN DAY(CAST(podate AS DATE)) BETWEEN 22 AND 28 THEN 4
        ELSE 5
    END
"""

_GRN_WEEK_CASE = """
    CASE
        WHEN DAY(CAST(grndate AS DATE)) BETWEEN 1 AND 7 THEN 1
        WHEN DAY(CAST(grndate AS DATE)) BETWEEN 8 AND 14 THEN 2
        WHEN DAY(CAST(grndate AS DATE)) BETWEEN 15 AND 21 THEN 3
        WHEN DAY(CAST(grndate AS DATE)) BETWEEN 22 AND 28 THEN 4
        ELSE 5
    END
"""


def _supplier_name_expr(cursor):
    """Return the SQL expression for supplier name from CustMast (cid join)."""
    has_alias = table_exists(cursor, "CustAliasMast")
    if has_alias:
        return (
            "LTRIM(RTRIM(ISNULL("
            "NULLIF(LTRIM(RTRIM(ISNULL(C.CName, N''))), N''), "
            "NULLIF(LTRIM(RTRIM(ISNULL(A.CName, N''))), N'')"
            ")))"
        ), True
    return "LTRIM(RTRIM(ISNULL(C.CName, N'')))", False


def _supplier_join_sql(use_alias):
    join = (
        "LEFT JOIN CustMast C ON "
        "LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(C.Id, N'')))) "
        "= LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(m.cid, N''))))"
    )
    if use_alias:
        join += (
            " LEFT JOIN CustAliasMast A ON "
            "LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(A.Id, N'')))) "
            "= LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(m.cid, N''))))"
        )
    return join


def _supplier_filter_sql(request, cursor, table_alias="m", join_if_needed=False):
    """
    Parses request.GET.get("supplier") and returns (join_sql, where_sql, params).
    Handles comma-separated list of suppliers and maps to SQL IN clause using CustMast/CustAliasMast.
    """
    supplier_filter = (request.GET.get("supplier") or "").strip()
    if not supplier_filter or supplier_filter.lower() == "all suppliers":
        return "", "", []

    sups = [s.strip() for s in supplier_filter.split(",") if s.strip()]
    if not sups:
        return "", "", []

    placeholders = ",".join(["?"] * len(sups))

    if join_if_needed:
        has_alias = table_exists(cursor, "CustAliasMast")
        sch_cm, nm_cm, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST", "CustMast"])
        cm_id = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId", "custid"])
        cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName", "Name"])
        cm_del = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"])

        if not q_cm or not cm_id or not cm_name:
            return "", "", []

        cm_del_sql = f" AND ISNULL(C_FLT.[{cm_del}], 0) = 0" if cm_del else ""
        join_sql = f"""
            LEFT JOIN {q_cm} C_FLT ON 
                LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(C_FLT.[{cm_id}], N'')))) 
                = LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL({table_alias}.cid, N''))))
                {cm_del_sql}
        """

        if has_alias:
            sch_cam, nm_cam, q_cam = resolve_erp_table(cursor, ["CustAliasMast", "custaliasmast"])
            cam_id = find_column_ci(cursor, sch_cam, nm_cam, ["Id", "id", "ID", "CustId"])
            cam_name = find_column_ci(cursor, sch_cam, nm_cam, ["CName", "cname", "CNAME"])
            cam_del = find_column_ci(cursor, sch_cam, nm_cam, ["deleted", "Deleted", "IsDeleted"])

            cam_del_sql = f" AND ISNULL(A_FLT.[{cam_del}], 0) = 0" if cam_del else ""
            join_sql += f"""
                LEFT JOIN {q_cam} A_FLT ON 
                    LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(A_FLT.[{cam_id}], N'')))) 
                    = LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL({table_alias}.cid, N''))))
                    {cam_del_sql}
            """
            where_sql = f"""
                AND LTRIM(RTRIM(ISNULL(
                    NULLIF(LTRIM(RTRIM(ISNULL(C_FLT.[{cm_name}], N''))), N''), 
                    NULLIF(LTRIM(RTRIM(ISNULL(A_FLT.[{cam_name}], N''))), N'')
                ))) IN ({placeholders})
            """
        else:
            where_sql = f" AND LTRIM(RTRIM(ISNULL(C_FLT.[{cm_name}], N''))) IN ({placeholders}) "
    else:
        name_expr, _ = _supplier_name_expr(cursor)
        where_sql = f" AND {name_expr} IN ({placeholders}) "
        join_sql = ""

    return join_sql, where_sql, sups


def _get_table_search_columns(cursor, table_name, candidates):
    if not table_exists(cursor, table_name):
        return []
    valid_cols = []
    for col in candidates:
        cursor.execute(
            """
            SELECT TOP 1 COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = 'dbo' 
              AND TABLE_NAME = ? 
              AND UPPER(LTRIM(RTRIM(COLUMN_NAME))) = UPPER(LTRIM(RTRIM(?)))
            """,
            (table_name, col)
        )
        row = cursor.fetchone()
        if row and row[0] not in valid_cols:
            valid_cols.append(row[0])
    return valid_cols


def _build_po_search_sql(request, cursor, po_alias="m"):
    """
    Parses request.GET.get("search") or request.GET.get("q") and returns (where_sql, params).
    Matches RM Name / RM Desc / RM Code / Item Code / Item Description / Material Code / Desc / PO Number / Supplier Name.
    """
    search_q = (request.GET.get("search") or request.GET.get("q") or "").strip()
    if not search_q:
        return "", []

    like_pat = f"%{search_q}%"
    has_alias = table_exists(cursor, "CustAliasMast")

    candidates = [
        'rmname', 'rmdesc', 'rmcode', 'icode', 'itcode', 'itdesc', 'ItCode', 'ItDesc',
        'description', 'Description', 'matcode', 'matdesc', 'mattype', 'partno', 'PartNo',
        'PRINTPartNO', 'Part_No', 'rmtype', 'ShotClsReason', 'ShotClsUser'
    ]

    # Check PODet / In_PoDet
    po_det_tbl = "PODet" if table_exists(cursor, "PODet") else ("In_PoDet" if table_exists(cursor, "In_PoDet") else None)
    po_det_cols = _get_table_search_columns(cursor, po_det_tbl, candidates) if po_det_tbl else []

    # Check grninsubdet
    grn_det_tbl = "grninsubdet" if table_exists(cursor, "grninsubdet") else None
    grn_det_cols = _get_table_search_columns(cursor, grn_det_tbl, candidates) if grn_det_tbl else []

    # Check POAmndDet
    amnd_det_tbl = "POAmndDet" if table_exists(cursor, "POAmndDet") else ("poamnddet" if table_exists(cursor, "poamnddet") else None)
    amnd_det_cols = _get_table_search_columns(cursor, amnd_det_tbl, candidates) if amnd_det_tbl else []

    or_conditions = []
    params = []

    # 1. PO Number
    or_conditions.append(f"LOWER(CAST({po_alias}.pono AS NVARCHAR(200))) LIKE LOWER(?)")
    params.append(like_pat)

    # 2. Supplier Name
    alias_sub = (
        "UNION SELECT A_SRCH.Id FROM CustAliasMast A_SRCH WHERE ISNULL(A_SRCH.deleted, 0) = 0 "
        "AND LOWER(CAST(A_SRCH.CName AS NVARCHAR(500))) LIKE LOWER(?)"
        if has_alias else ""
    )
    or_conditions.append(f"""{po_alias}.cid IN (
        SELECT C_SRCH.Id FROM CustMast C_SRCH 
        WHERE ISNULL(C_SRCH.deleted, 0) = 0 
          AND LOWER(CAST(C_SRCH.CName AS NVARCHAR(500))) LIKE LOWER(?)
        {alias_sub}
    )""")
    params.append(like_pat)
    if has_alias:
        params.append(like_pat)

    # 3. PODet / In_PoDet subquery
    if po_det_cols:
        clauses = [f"LOWER(CAST(pd_srch.[{c}] AS NVARCHAR(512))) LIKE LOWER(?)" for c in po_det_cols]
        or_conditions.append(f"""{po_alias}.pono IN (
            SELECT DISTINCT pd_srch.pono
            FROM {po_det_tbl} pd_srch
            WHERE ISNULL(pd_srch.deleted, 0) = 0
              AND ({" OR ".join(clauses)})
        )""")
        params.extend([like_pat] * len(po_det_cols))

    # 4. GRN subquery (grninsubdet)
    if grn_det_cols:
        clauses = [f"LOWER(CAST(gd_srch.[{c}] AS NVARCHAR(512))) LIKE LOWER(?)" for c in grn_det_cols]
        or_conditions.append(f"""{po_alias}.pono IN (
            SELECT DISTINCT gd_srch.pono
            FROM {grn_det_tbl} gd_srch
            WHERE ISNULL(gd_srch.deleted, 0) = 0
              AND ({" OR ".join(clauses)})
        )""")
        params.extend([like_pat] * len(grn_det_cols))

    # 5. POAmndDet subquery
    if amnd_det_cols:
        clauses = [f"LOWER(CAST(ad_srch.[{c}] AS NVARCHAR(512))) LIKE LOWER(?)" for c in amnd_det_cols]
        or_conditions.append(f"""{po_alias}.pono IN (
            SELECT DISTINCT PAM_SRCH.manualpono
            FROM {amnd_det_tbl} ad_srch
            INNER JOIN POAmndMas PAM_SRCH ON ad_srch.amdno = PAM_SRCH.amdno
            WHERE ISNULL(ad_srch.deleted, 0) = 0
              AND ISNULL(PAM_SRCH.deleted, 0) = 0
              AND ({" OR ".join(clauses)})
        )""")
        params.extend([like_pat] * len(amnd_det_cols))

    where_sql = f" AND (" + " OR ".join(or_conditions) + ")"
    return where_sql, params


# ─────────────────────────────────────────────────────────────
#  ENDPOINT 1 — Summary Strip + KPI Cards
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_summary(request):
    """
    Returns KPI values for the Purchase Analysis page:
      - total_po_value, total_pos, active_suppliers
      - grn_received, grn_pending, grn_compliance_pct
      - avg_lead_time_days
      - period label, from / to dates
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    total_po_value    = 0.0
    total_pos         = 0
    active_suppliers  = 0
    grn_received      = 0.0
    grn_pending       = 0.0
    avg_lead_time     = 0.0

    try:
        cursor = conn.cursor()

        # ── PO Summary Filters ──
        dtype_clause_po = ""
        dtype_params_po = []
        if apply_dtype:
            dtype_clause_po = " AND LTRIM(RTRIM(ISNULL(dtype, ''))) = ?"
            dtype_params_po.append(dtype_param)
        else:
            dtype_clause_po = " AND UPPER(LTRIM(RTRIM(ISNULL(dtype, '')))) <> 'JOB ORDER'"

        # Supplier filters
        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "POMas", join_if_needed=True)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "POMas")

        # ── PO summary ──────────────────────────────────────────────
        cursor.execute(
            f"""
            SELECT
                ISNULL(SUM(CAST(totamt AS FLOAT)), 0) AS po_value,
                COUNT(DISTINCT pono)                  AS po_count,
                COUNT(DISTINCT cid)                   AS suppliers
            FROM POMas
            {join_flt}
            WHERE ISNULL(POMas.deleted, 0) = 0
              {dtype_clause_po}
              {where_flt}
              {srch_sql}
              AND CAST(podate AS DATE) BETWEEN ? AND ?
            """,
            tuple(dtype_params_po + params_flt + srch_params + [start_date, end_date]),
        )
        row = cursor.fetchone()
        if row:
            total_po_value   = float(row[0] or 0)
            total_pos        = int(row[1] or 0)
            active_suppliers = int(row[2] or 0)

        # ── GRN received value against POs in the selected period ─────
        join_flt_grn, where_flt_grn, params_flt_grn = _supplier_filter_sql(request, cursor, "m", join_if_needed=True)
        srch_sql_m, srch_params_m = _build_po_search_sql(request, cursor, "m")
        try:
            cursor.execute(
                f"""
                SELECT ISNULL(SUM(CAST(rd.Amount AS FLOAT)), 0)
                FROM Grn_RateDet rd
                INNER JOIN grninsubdet gs ON rd.grnno = gs.grnno
                INNER JOIN grn_mas gm ON gs.grnno = gm.grnno
                INNER JOIN POMas m ON gs.pono = m.pono
                {join_flt_grn}
                WHERE ISNULL(rd.deleted, 0) = 0
                  AND ISNULL(gs.deleted, 0) = 0
                  AND ISNULL(gm.deleted, 0) = 0
                  AND ISNULL(m.deleted, 0) = 0
                  {dtype_clause_po.replace("dtype", "m.dtype")}
                  {where_flt_grn}
                  {srch_sql_m}
                  AND CAST(m.podate AS DATE) BETWEEN ? AND ?
                """,
                tuple(dtype_params_po + params_flt_grn + srch_params_m + [start_date, end_date]),
            )
            grn_row = cursor.fetchone()
            grn_received = float(grn_row[0] or 0) if grn_row else 0.0
        except Exception:
            # Fall back to grn_mas namt if Grn_RateDet not available
            try:
                cursor.execute(
                    f"""
                    SELECT ISNULL(SUM(CAST(gm.namt AS FLOAT)), 0)
                    FROM grn_mas gm
                    WHERE ISNULL(gm.deleted, 0) = 0
                      AND gm.grnno IN (
                          SELECT DISTINCT gs.grnno
                          FROM grninsubdet gs
                          INNER JOIN POMas m ON gs.pono = m.pono
                          {join_flt_grn}
                          WHERE ISNULL(gs.deleted, 0) = 0
                            AND ISNULL(m.deleted, 0) = 0
                            {dtype_clause_po.replace("dtype", "m.dtype")}
                            {where_flt_grn}
                            {srch_sql_m}
                            AND CAST(m.podate AS DATE) BETWEEN ? AND ?
                      )
                    """,
                    tuple(dtype_params_po + params_flt_grn + srch_params_m + [start_date, end_date]),
                )
                grn_row = cursor.fetchone()
                grn_received = float(grn_row[0] or 0) if grn_row else 0.0
            except Exception:
                grn_received = 0.0

        grn_pending = max(0.0, total_po_value - grn_received)

        # ── Average lead time (PO date → GRN date) ──────────────────
        try:
            cursor.execute(
                f"""
                SELECT AVG(CAST(DATEDIFF(DAY, m.podate, gm.grndate) AS FLOAT))
                FROM grn_mas gm
                INNER JOIN grninsubdet gs ON gm.grnno = gs.grnno
                INNER JOIN POMas m ON gs.pono = m.pono
                {join_flt_grn}
                WHERE ISNULL(gm.deleted, 0) = 0
                  AND ISNULL(gs.deleted, 0) = 0
                  AND ISNULL(m.deleted, 0) = 0
                  {dtype_clause_po.replace("dtype", "m.dtype")}
                  {where_flt_grn}
                  {srch_sql_m}
                  AND CAST(m.podate AS DATE) BETWEEN ? AND ?
                """,
                tuple(dtype_params_po + params_flt_grn + srch_params_m + [start_date, end_date]),
            )
            lt_row = cursor.fetchone()
            avg_lead_time = round(float(lt_row[0] or 0), 1) if lt_row and lt_row[0] else 0.0
        except Exception:
            avg_lead_time = 0.0

        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    grn_compliance = _pct(grn_received, total_po_value)

    return Response({
        "company":            tenant.get("company_name", ""),
        "from":               str(start_date),
        "to":                 str(end_date),
        "period":             _fmt_period(start_date, end_date),
        "total_po_value":     total_po_value,
        "total_po_value_lakhs": _to_lakhs(total_po_value),
        "total_pos":          total_pos,
        "active_suppliers":   active_suppliers,
        "grn_received":       grn_received,
        "grn_received_lakhs":  _to_lakhs(grn_received),
        "grn_pending":        grn_pending,
        "grn_pending_lakhs":   _to_lakhs(grn_pending),
        "grn_compliance_pct": grn_compliance,
        "avg_lead_time_days":  avg_lead_time,
    })


# ─────────────────────────────────────────────────────────────
#  ENDPOINT 2 — Weekly Trend (PO Value + GRN Received)
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_weekly_trend(request):
    """
    Returns week-by-week PO value and GRN received for Chart.js mixed bar+line.
    Accepts optional ?dtype=Raw Material to filter by PO type.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param  = (request.GET.get("dtype") or "").strip()
    apply_dtype  = dtype_param and dtype_param.lower() != "all types"
    labels, keys = _weekly_slots(start_date, end_date)

    if not keys:
        return Response({
            "period": _fmt_period(start_date, end_date),
            "labels": [],
            "po_value": [],
            "grn_received": [],
        })

    po_map  = {k: 0.0 for k in keys}
    grn_map = {k: 0.0 for k in keys}

    try:
        cursor = conn.cursor()

        # Supplier filter
        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "POMas", join_if_needed=True)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "POMas")

        # ── PO weekly ────────────────────────────────────────────────
        dtype_clause = ""
        dtype_params_list = []
        if apply_dtype:
            dtype_clause = " AND LTRIM(RTRIM(ISNULL(dtype, ''))) = ?"
            dtype_params_list = [dtype_param]

        cursor.execute(
            f"""
            SELECT
                YEAR(CAST(podate AS DATE)) AS yr,
                MONTH(CAST(podate AS DATE)) AS mo,
                {_WEEK_OF_MONTH_CASE} AS wk,
                ISNULL(SUM(CAST(totamt AS FLOAT)), 0) AS po_val
            FROM POMas
            {join_flt}
            WHERE ISNULL(POMas.deleted, 0) = 0
              AND UPPER(LTRIM(RTRIM(ISNULL(POMas.dtype, '')))) <> 'JOB ORDER'
              AND CAST(podate AS DATE) BETWEEN ? AND ?
              {dtype_clause}
              {where_flt}
              {srch_sql}
            GROUP BY
                YEAR(CAST(podate AS DATE)),
                MONTH(CAST(podate AS DATE)),
                {_WEEK_OF_MONTH_CASE}
            ORDER BY yr, mo, wk
            """,
            [start_date, end_date] + dtype_params_list + params_flt + srch_params,
        )
        for yr, mo, wk, val in cursor.fetchall():
            k = (int(yr), int(mo), int(wk))
            if k in po_map:
                po_map[k] = float(val or 0)

        # ── GRN weekly ───────────────────────────────────────────────
        join_flt_grn, where_flt_grn, params_flt_grn = _supplier_filter_sql(request, cursor, "m", join_if_needed=True)
        srch_sql_m, srch_params_m = _build_po_search_sql(request, cursor, "m")
        has_extra_filters = apply_dtype or where_flt_grn or srch_sql_m
        try:
            if has_extra_filters:
                cursor.execute(
                    f"""
                    SELECT
                        YEAR(CAST(gm.grndate AS DATE)) AS yr,
                        MONTH(CAST(gm.grndate AS DATE)) AS mo,
                        {_GRN_WEEK_CASE} AS wk,
                        ISNULL(SUM(CAST(rd.Amount AS FLOAT)), 0) AS grn_val
                    FROM Grn_RateDet rd
                    INNER JOIN grn_mas gm ON rd.grnno = gm.grnno
                    WHERE ISNULL(gm.deleted, 0) = 0
                      AND ISNULL(rd.deleted, 0) = 0
                      AND CAST(gm.grndate AS DATE) BETWEEN ? AND ?
                      AND rd.grnno IN (
                          SELECT DISTINCT gs.grnno
                          FROM grninsubdet gs
                          INNER JOIN POMas m ON gs.pono = m.pono
                          {join_flt_grn}
                          WHERE ISNULL(gs.deleted, 0) = 0
                            AND ISNULL(m.deleted, 0) = 0
                            {dtype_clause.replace("dtype", "m.dtype")}
                            {where_flt_grn}
                            {srch_sql_m}
                      )
                    GROUP BY
                        YEAR(CAST(gm.grndate AS DATE)),
                        MONTH(CAST(gm.grndate AS DATE)),
                        {_GRN_WEEK_CASE}
                    ORDER BY yr, mo, wk
                    """,
                    [start_date, end_date] + dtype_params_list + params_flt_grn + srch_params_m,
                )
            else:
                cursor.execute(
                    f"""
                    SELECT
                        YEAR(CAST(gm.grndate AS DATE)) AS yr,
                        MONTH(CAST(gm.grndate AS DATE)) AS mo,
                        {_GRN_WEEK_CASE} AS wk,
                        ISNULL(SUM(CAST(rd.Amount AS FLOAT)), 0) AS grn_val
                    FROM Grn_RateDet rd
                    INNER JOIN grn_mas gm ON rd.grnno = gm.grnno
                    WHERE ISNULL(gm.deleted, 0) = 0
                      AND ISNULL(rd.deleted, 0) = 0
                      AND CAST(gm.grndate AS DATE) BETWEEN ? AND ?
                    GROUP BY
                        YEAR(CAST(gm.grndate AS DATE)),
                        MONTH(CAST(gm.grndate AS DATE)),
                        {_GRN_WEEK_CASE}
                    ORDER BY yr, mo, wk
                    """,
                    [start_date, end_date],
                )
            for yr, mo, wk, val in cursor.fetchall():
                k = (int(yr), int(mo), int(wk))
                if k in grn_map:
                    grn_map[k] = float(val or 0)
        except Exception:
            pass  # GRN data optional

        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    return Response({
        "company":     tenant.get("company_name", ""),
        "from":        str(start_date),
        "to":          str(end_date),
        "period":      _fmt_period(start_date, end_date),
        "labels":      labels,
        "po_value":    [round(_to_lakhs(po_map[k]), 2) for k in keys],
        "grn_received": [round(_to_lakhs(grn_map[k]), 2) for k in keys],
    })


# ─────────────────────────────────────────────────────────────
#  ENDPOINT 3 — Supplier Spend & Category Spend (Donuts)
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_charts(request):
    """
    Returns donut chart data:
      - supplier_labels / supplier_data  (% spend by supplier)
      - category_labels / category_data  (% spend by PO dtype/category)
      - supplier_ranking list for the bar-rank panel
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    try:
        cursor = conn.cursor()
        name_expr, use_alias = _supplier_name_expr(cursor)
        join_sql = _supplier_join_sql(use_alias)

        # Supplier filter (Spend by supplier query uses already joined CM)
        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, join_if_needed=False)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "m")

        # ── Spend by supplier ────────────────────────────────────────
        dtype_clause = ""
        dtype_params = []
        if apply_dtype:
            dtype_clause = " AND LTRIM(RTRIM(ISNULL(m.dtype, ''))) = ?"
            dtype_params.append(dtype_param)
        else:
            dtype_clause = " AND UPPER(LTRIM(RTRIM(ISNULL(m.dtype, '')))) <> 'JOB ORDER'"

        cursor.execute(
            f"""
            SELECT
                {name_expr} AS supplier_name,
                ISNULL(SUM(CAST(m.totamt AS FLOAT)), 0) AS spend
            FROM POMas m
            {join_sql}
            WHERE ISNULL(m.deleted, 0) = 0
              {dtype_clause}
              {where_flt}
              {srch_sql}
              AND CAST(m.podate AS DATE) BETWEEN ? AND ?
            GROUP BY m.cid, {name_expr}
            ORDER BY spend DESC
            """,
            tuple(dtype_params + params_flt + srch_params + [start_date, end_date]),
        )
        sup_rows = cursor.fetchall()
        total_spend = sum(float(r[1] or 0) for r in sup_rows)

        supplier_ranking = []
        for i, row in enumerate(sup_rows[:8]):
            name  = (row[0] or "").strip() or "Unknown"
            spend = float(row[1] or 0)
            supplier_ranking.append({
                "rank":         i + 1,
                "name":         name,
                "spend":        spend,
                "spend_lakhs":  _to_lakhs(spend),
                "pct":          _pct(spend, total_spend),
            })

        top_sup = sup_rows[:5]
        others_sup = sum(float(r[1] or 0) for r in sup_rows[5:])
        sup_labels = [(r[0] or "").strip() or "Unknown" for r in top_sup]
        sup_data   = [_pct(float(r[1] or 0), total_spend) for r in top_sup]
        if others_sup > 0:
            sup_labels.append("Others")
            sup_data.append(_pct(others_sup, total_spend))

        # ── Spend by category (dtype) ────────────────────────────────
        join_flt_cat, where_flt_cat, params_flt_cat = _supplier_filter_sql(request, cursor, "POMas", join_if_needed=True)
        srch_sql_cat, srch_params_cat = _build_po_search_sql(request, cursor, "POMas")

        dtype_clause_cat = ""
        dtype_params_cat = []
        if apply_dtype:
            dtype_clause_cat = " AND LTRIM(RTRIM(ISNULL(POMas.dtype, ''))) = ?"
            dtype_params_cat.append(dtype_param)
        else:
            dtype_clause_cat = " AND UPPER(LTRIM(RTRIM(ISNULL(POMas.dtype, '')))) <> 'JOB ORDER'"

        cursor.execute(
            f"""
            SELECT
                LTRIM(RTRIM(ISNULL(POMas.dtype, 'General'))) AS category,
                ISNULL(SUM(CAST(totamt AS FLOAT)), 0)  AS spend
            FROM POMas
            {join_flt_cat}
            WHERE ISNULL(POMas.deleted, 0) = 0
              {dtype_clause_cat}
              {where_flt_cat}
              {srch_sql_cat}
              AND CAST(podate AS DATE) BETWEEN ? AND ?
            GROUP BY LTRIM(RTRIM(ISNULL(POMas.dtype, 'General')))
            ORDER BY spend DESC
            """,
            tuple(dtype_params_cat + params_flt_cat + srch_params_cat + [start_date, end_date]),
        )
        cat_rows = cursor.fetchall()
        total_cat = sum(float(r[1] or 0) for r in cat_rows)

        top_cat = cat_rows[:5]
        others_cat = sum(float(r[1] or 0) for r in cat_rows[5:])
        cat_labels = [(r[0] or "").strip() or "General" for r in top_cat]
        cat_data   = [_pct(float(r[1] or 0), total_cat) for r in top_cat]
        if others_cat > 0:
            cat_labels.append("Others")
            cat_data.append(_pct(others_cat, total_cat))

        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    return Response({
        "company":           tenant.get("company_name", ""),
        "from":              str(start_date),
        "to":                str(end_date),
        "period":            _fmt_period(start_date, end_date),
        "supplier_labels":   sup_labels,
        "supplier_data":     sup_data,
        "category_labels":   cat_labels,
        "category_data":     cat_data,
        "supplier_ranking":  supplier_ranking,
        "total_spend":       total_spend,
        "total_spend_lakhs": _to_lakhs(total_spend),
    })



# ─────────────────────────────────────────────────────────────
#  ENDPOINT 4 — PO Pipeline Summary
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_pipeline(request):
    """
    Returns PO pipeline counts and values:
      - pos_raised, value_raised
      - grn_closed (fully received), value_closed
      - partial_grn, value_partial
      - pending (no GRN), value_pending
      - overdue_pos (GRN date exceeded expected date)
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)

    pos_raised    = 0
    value_raised  = 0.0
    grn_closed    = 0
    value_closed  = 0.0
    partial_grn   = 0
    value_partial = 0.0
    pending_pos   = 0
    value_pending = 0.0
    overdue_pos   = 0

    try:
        cursor = conn.cursor()
        srch_sql_po, srch_params_po = _build_po_search_sql(request, cursor, "POMas")

        # ── Total POs raised ─────────────────────────────────────────
        cursor.execute(
            f"""
            SELECT
                COUNT(DISTINCT pono) AS po_count,
                ISNULL(SUM(CAST(totamt AS FLOAT)), 0) AS po_value
            FROM POMas
            WHERE ISNULL(deleted, 0) = 0
              AND ISNULL(dtype, '') <> 'Job Order'
              {srch_sql_po}
              AND CAST(podate AS DATE) BETWEEN ? AND ?
            """,
            tuple(srch_params_po + [start_date, end_date]),
        )
        row = cursor.fetchone()
        if row:
            pos_raised   = int(row[0] or 0)
            value_raised = float(row[1] or 0)

        # ── PO status via GRN linkage ────────────────────────────────
        try:
            srch_sql_m, srch_params_m = _build_po_search_sql(request, cursor, "m")
            cursor.execute(
                f"""
                SELECT
                    m.pono,
                    ISNULL(m.totamt, 0)                                AS po_value,
                    ISNULL(SUM(CAST(gs.qty AS FLOAT)), 0)              AS grn_qty,
                    ISNULL(SUM(CAST(pd.qty AS FLOAT)), 0)              AS ord_qty,
                    MAX(CAST(gm.grndate AS DATE))                      AS last_grn_date,
                    MIN(CAST(m.podate AS DATE))                        AS po_date
                FROM POMas m
                LEFT JOIN grninsubdet gs
                    ON gs.pono = m.pono AND ISNULL(gs.deleted, 0) = 0
                LEFT JOIN grn_mas gm
                    ON gs.grnno = gm.grnno AND ISNULL(gm.deleted, 0) = 0
                LEFT JOIN PODet pd
                    ON pd.pono = m.pono AND ISNULL(pd.deleted, 0) = 0
                WHERE ISNULL(m.deleted, 0) = 0
                  AND ISNULL(m.dtype, '') <> 'Job Order'
                  {srch_sql_m}
                  AND CAST(m.podate AS DATE) BETWEEN ? AND ?
                GROUP BY m.pono, m.totamt
                """,
                tuple(srch_params_m + [start_date, end_date]),
            )
            rows = cursor.fetchall()
            today = date.today()
            for pono, po_val, grn_qty, ord_qty, last_grn, po_date in rows:
                pv = float(po_val or 0)
                gq = float(grn_qty or 0)
                oq = float(ord_qty or 0)
                if oq > 0 and gq >= oq:
                    grn_closed  += 1
                    value_closed += pv
                elif gq > 0:
                    partial_grn  += 1
                    value_partial += pv
                    # Check overdue: no full GRN and PO is older than 30 days
                    if po_date and (today - po_date).days > 30:
                        overdue_pos += 1
                else:
                    pending_pos  += 1
                    value_pending += pv
                    if po_date and (today - po_date).days > 30:
                        overdue_pos += 1
        except Exception:
            pass  # Pipeline detail is best-effort

        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    return Response({
        "company":       tenant.get("company_name", ""),
        "from":          str(start_date),
        "to":            str(end_date),
        "period":        _fmt_period(start_date, end_date),
        "pos_raised":    pos_raised,
        "value_raised":  value_raised,
        "value_raised_lakhs": _to_lakhs(value_raised),
        "grn_closed":    grn_closed,
        "value_closed":  value_closed,
        "value_closed_lakhs": _to_lakhs(value_closed),
        "partial_grn":   partial_grn,
        "value_partial": value_partial,
        "value_partial_lakhs": _to_lakhs(value_partial),
        "pending_pos":   pending_pos,
        "value_pending": value_pending,
        "value_pending_lakhs": _to_lakhs(value_pending),
        "overdue_pos":   overdue_pos,
        "received_pct":  _pct(value_closed, value_raised),
        "partial_pct":   _pct(value_partial, value_raised),
        "pending_pct":   _pct(value_pending, value_raised),
    })


# ─────────────────────────────────────────────────────────────
#  ENDPOINT 5 — PO Detail Table
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_po_details(request):
    """
    Returns paginated PO line-item detail table rows.
    Query params: ?from=&to=&page=1&page_size=50&supplier=&status=
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    page      = max(1, int(request.GET.get("page", 1) or 1))
    page_size = min(200, max(10, int(request.GET.get("page_size", 50) or 50)))
    supplier_filter = (request.GET.get("supplier") or "").strip()
    status_filter   = (request.GET.get("status") or "").strip().lower()
    search_q        = (request.GET.get("search") or request.GET.get("q") or "").strip()

    rows_out = []
    total_rows = 0

    try:
        cursor = conn.cursor()
        name_expr, use_alias = _supplier_name_expr(cursor)
        join_sql = _supplier_join_sql(use_alias)

        supplier_where = ""
        params_extra: list = []
        if supplier_filter:
            supplier_where = f"AND {name_expr} LIKE ?"
            params_extra.append(f"%{supplier_filter}%")

        search_where = ""
        if search_q:
            like_pat = f"%{search_q}%"
            candidates = [
                'rmname', 'rmdesc', 'rmcode', 'icode', 'itcode', 'itdesc', 'ItCode', 'ItDesc',
                'description', 'Description', 'matcode', 'matdesc', 'mattype', 'partno', 'PartNo',
                'PRINTPartNO', 'Part_No', 'rmtype'
            ]
            det_cols = _get_table_search_columns(cursor, "PODet", candidates) or _get_table_search_columns(cursor, "In_PoDet", candidates)
            or_list = [
                f"LOWER(CAST(m.pono AS NVARCHAR(200))) LIKE LOWER(?)",
                f"LOWER(CAST({name_expr} AS NVARCHAR(500))) LIKE LOWER(?)"
            ]
            params_extra.extend([like_pat, like_pat])
            if det_cols:
                for c in det_cols:
                    or_list.append(f"LOWER(CAST(pd.[{c}] AS NVARCHAR(512))) LIKE LOWER(?)")
                    params_extra.append(like_pat)
            else:
                or_list.extend([
                    "LOWER(CAST(pd.icode AS NVARCHAR(256))) LIKE LOWER(?)",
                    "LOWER(CAST(pd.itdesc AS NVARCHAR(512))) LIKE LOWER(?)",
                    "LOWER(CAST(pd.rmname AS NVARCHAR(512))) LIKE LOWER(?)"
                ])
                params_extra.extend([like_pat, like_pat, like_pat])
            search_where = f" AND (" + " OR ".join(or_list) + ")"

        # Build status CASE for closed / partial / overdue / open
        status_case = """
            CASE
                WHEN ISNULL(gs.grn_qty, 0) = 0 THEN 'Open'
                WHEN ISNULL(gs.grn_qty, 0) >= ISNULL(pd.qty, 0) THEN 'Closed'
                ELSE 'Partial'
            END
        """

        base_sql = f"""
            SELECT
                m.pono,
                CONVERT(VARCHAR(10), CAST(m.podate AS DATE), 103) AS podate,
                {name_expr}                                        AS supplier_name,
                pd.icode                                           AS part_no,
                ISNULL(pd.itdesc, pd.icode)                        AS description,
                ISNULL(CAST(pd.qty AS FLOAT), 0)                   AS ord_qty,
                ISNULL(gs.grn_qty, 0)                              AS rcv_qty,
                ISNULL(CAST(pd.rate AS FLOAT), 0)                  AS rate,
                ISNULL(CAST(pd.amount AS FLOAT), 0)                AS amount,
                {status_case}                                       AS status
            FROM POMas m
            {join_sql}
            LEFT JOIN PODet pd
                ON pd.pono = m.pono AND ISNULL(pd.deleted, 0) = 0
            LEFT JOIN (
                SELECT gs2.pono, gs2.rmname AS icode,
                       SUM(CAST(gs2.qty AS FLOAT)) AS grn_qty
                FROM grninsubdet gs2
                INNER JOIN grn_mas gm2 ON gs2.grnno = gm2.grnno
                WHERE ISNULL(gs2.deleted, 0) = 0
                  AND ISNULL(gm2.deleted, 0) = 0
                  AND CAST(gm2.grndate AS DATE) BETWEEN ? AND ?
                GROUP BY gs2.pono, gs2.rmname
            ) gs ON gs.pono = m.pono AND gs.icode = pd.icode
            WHERE ISNULL(m.deleted, 0) = 0
              AND ISNULL(m.dtype, '') <> 'Job Order'
              AND CAST(m.podate AS DATE) BETWEEN ? AND ?
              {supplier_where}
              {search_where}
        """

        count_sql  = f"SELECT COUNT(*) FROM ({base_sql}) AS T"
        paged_sql  = (
            f"SELECT * FROM ({base_sql}) AS T "
            f"ORDER BY podate DESC, pono, part_no "
            f"OFFSET ? ROWS FETCH NEXT ? ROWS ONLY"
        )

        base_params = [start_date, end_date, start_date, end_date] + params_extra

        cursor.execute(count_sql, base_params)
        count_row  = cursor.fetchone()
        total_rows = int(count_row[0] or 0) if count_row else 0

        offset = (page - 1) * page_size
        cursor.execute(paged_sql, base_params + [offset, page_size])

        for row in cursor.fetchall():
            pono, podate, sup, part, desc, oq, rq, rate, amt, status = row
            if status_filter and status_filter != status.lower():
                continue
            rows_out.append({
                "po_no":       str(pono or "").strip(),
                "date":        str(podate or "").strip(),
                "supplier":    str(sup or "").strip() or "Unknown",
                "part_no":     str(part or "").strip(),
                "description": str(desc or "").strip(),
                "ord_qty":     round(float(oq or 0), 2),
                "rcv_qty":     round(float(rq or 0), 2),
                "rate":        round(float(rate or 0), 2),
                "amount":      round(float(amt or 0), 2),
                "status":      str(status or "Open").strip(),
            })

        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    return Response({
        "company":    tenant.get("company_name", ""),
        "from":       str(start_date),
        "to":         str(end_date),
        "period":     _fmt_period(start_date, end_date),
        "page":       page,
        "page_size":  page_size,
        "total_rows": total_rows,
        "total_pages": max(1, -(-total_rows // page_size)),
        "rows":       rows_out,
    })


# ─────────────────────────────────────────────────────────────
#  ENDPOINT 6 — GRN Aging (Outstanding Receipts)
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_grn_aging(request):
    """
    Returns GRN aging list: open PO lines with their overdue days.
    Sorted by days_overdue DESC (most critical first).
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    aging_rows = []

    try:
        cursor = conn.cursor()
        name_expr, use_alias = _supplier_name_expr(cursor)
        join_sql = _supplier_join_sql(use_alias)
        today = date.today()

        # ── PO Summary Filters ──
        dtype_clause_po = ""
        dtype_params_po = []
        if apply_dtype:
            dtype_clause_po = " AND LTRIM(RTRIM(ISNULL(m.dtype, ''))) = ?"
            dtype_params_po.append(dtype_param)
        else:
            dtype_clause_po = " AND UPPER(LTRIM(RTRIM(ISNULL(m.dtype, '')))) NOT IN ('', 'JOB ORDER', 'GENERAL')"

        cursor.execute(
            f"""
            SELECT
                m.pono,
                {name_expr}                             AS supplier_name,
                pd.icode                                AS part_no,
                ISNULL(pd.itdesc, pd.icode)              AS description,
                ISNULL(CAST(pd.qty AS FLOAT), 0)         AS ord_qty,
                ISNULL(gs.grn_qty, 0)                   AS rcv_qty,
                CAST(m.podate AS DATE)                  AS po_date,
                DATEDIFF(DAY, CAST(m.podate AS DATE), ?) AS days_open
            FROM POMas m
            {join_sql}
            LEFT JOIN PODet pd
                ON pd.pono = m.pono AND ISNULL(pd.deleted, 0) = 0
            LEFT JOIN (
                SELECT gs2.pono, gs2.rmname AS icode,
                       SUM(CAST(gs2.qty AS FLOAT)) AS grn_qty
                FROM grninsubdet gs2
                INNER JOIN grn_mas gm2 ON gs2.grnno = gm2.grnno
                WHERE ISNULL(gs2.deleted, 0) = 0
                  AND ISNULL(gm2.deleted, 0) = 0
                GROUP BY gs2.pono, gs2.rmname
            ) gs ON gs.pono = m.pono AND gs.icode = pd.icode
            WHERE ISNULL(m.deleted, 0) = 0
              {dtype_clause_po}
              AND CAST(m.podate AS DATE) BETWEEN ? AND ?
              AND ISNULL(gs.grn_qty, 0) < ISNULL(CAST(pd.qty AS FLOAT), 0)
            ORDER BY days_open DESC
            """,
            tuple([today] + dtype_params_po + [start_date, end_date]),
        )

        for pono, sup, part, desc, oq, rq, po_date, days_open in cursor.fetchall():
            d_open = int(days_open or 0)
            if d_open > 14:
                urgency = "overdue"
                days_lbl = f"+{d_open} days"
            elif d_open > 7:
                urgency = "warning"
                days_lbl = f"+{d_open} days"
            else:
                urgency = "ok"
                days_lbl = f"{d_open} days"

            aging_rows.append({
                "po_no":       str(pono or "").strip(),
                "supplier":    str(sup or "").strip() or "Unknown",
                "part_no":     str(part or "").strip(),
                "description": str(desc or "").strip(),
                "ord_qty":     round(float(oq or 0), 2),
                "rcv_qty":     round(float(rq or 0), 2),
                "pending_qty": round(max(0.0, float(oq or 0) - float(rq or 0)), 2),
                "po_date":     str(po_date) if po_date else "",
                "days_open":   d_open,
                "days_label":  days_lbl,
                "urgency":     urgency,
            })

        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    overdue_count = sum(1 for r in aging_rows if r["urgency"] == "overdue")
    warning_count = sum(1 for r in aging_rows if r["urgency"] == "warning")

    return Response({
        "company":       tenant.get("company_name", ""),
        "from":          str(start_date),
        "to":            str(end_date),
        "period":        _fmt_period(start_date, end_date),
        "overdue_count": overdue_count,
        "warning_count": warning_count,
        "rows":          aging_rows,
    })


# ─────────────────────────────────────────────────────────────
#  ENDPOINT 7 — Month-wise Summary (for drill-down table)
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_month_summary(request):
    """
    Month-wise PO value and GRN received for the selected date range.
    Useful for the month-by-month breakdown table.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)

    month_data = {}

    try:
        cursor = conn.cursor()

        # ── Filters ──────────────────────────────────────────────────
        dtype_param = (request.GET.get("dtype") or "").strip()
        apply_dtype = dtype_param and dtype_param.lower() != "all types"
        dtype_clause_po = ""
        dtype_params_po = []
        if apply_dtype:
            dtype_clause_po = " AND LTRIM(RTRIM(ISNULL(m.dtype, ''))) = ?"
            dtype_params_po.append(dtype_param)
        else:
            dtype_clause_po = " AND UPPER(LTRIM(RTRIM(ISNULL(m.dtype, '')))) <> 'JOB ORDER'"

        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "m", join_if_needed=True)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "m")

        # ── Monthly PO value ─────────────────────────────────────────
        cursor.execute(
            f"""
            SELECT
                YEAR(CAST(m.podate AS DATE)) AS yr,
                MONTH(CAST(m.podate AS DATE)) AS mo,
                ISNULL(SUM(CAST(m.totamt AS FLOAT)), 0) AS po_val,
                COUNT(DISTINCT m.pono) AS po_count
            FROM POMas m
            {join_flt}
            WHERE ISNULL(m.deleted, 0) = 0
              {dtype_clause_po}
              {where_flt}
              {srch_sql}
              AND CAST(m.podate AS DATE) BETWEEN ? AND ?
            GROUP BY
                YEAR(CAST(m.podate AS DATE)),
                MONTH(CAST(m.podate AS DATE))
            ORDER BY yr, mo
            """,
            tuple(dtype_params_po + params_flt + srch_params + [start_date, end_date]),
        )
        for yr, mo, po_val, po_cnt in cursor.fetchall():
            k = (int(yr), int(mo))
            month_data.setdefault(k, {"po_value": 0.0, "po_count": 0, "grn_received": 0.0})
            month_data[k]["po_value"]  = float(po_val or 0)
            month_data[k]["po_count"]  = int(po_cnt or 0)

        # ── Monthly GRN received against those POs ───────────────────
        try:
            cursor.execute(
                f"""
                SELECT
                    YEAR(CAST(m.podate AS DATE)) AS yr,
                    MONTH(CAST(m.podate AS DATE)) AS mo,
                    ISNULL(SUM(CAST(rd.Amount AS FLOAT)), 0) AS grn_val
                FROM Grn_RateDet rd
                INNER JOIN grninsubdet gs ON rd.grnno = gs.grnno
                INNER JOIN grn_mas gm ON gs.grnno = gm.grnno
                INNER JOIN POMas m ON gs.pono = m.pono
                {join_flt}
                WHERE ISNULL(gm.deleted, 0) = 0
                  AND ISNULL(rd.deleted, 0) = 0
                  AND ISNULL(gs.deleted, 0) = 0
                  AND ISNULL(m.deleted, 0) = 0
                  {dtype_clause_po}
                  {where_flt}
                  {srch_sql}
                  AND CAST(m.podate AS DATE) BETWEEN ? AND ?
                GROUP BY
                    YEAR(CAST(m.podate AS DATE)),
                    MONTH(CAST(m.podate AS DATE))
                ORDER BY yr, mo
                """,
                tuple(dtype_params_po + params_flt + srch_params + [start_date, end_date]),
            )
            for yr, mo, grn_val in cursor.fetchall():
                k = (int(yr), int(mo))
                month_data.setdefault(k, {"po_value": 0.0, "po_count": 0, "grn_received": 0.0})
                month_data[k]["grn_received"] = float(grn_val or 0)
        except Exception:
            pass

        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    months_out = []
    for (yr, mo), vals in sorted(month_data.items()):
        pv  = vals["po_value"]
        grn = vals["grn_received"]
        months_out.append({
            "year":           yr,
            "month":          mo,
            "month_label":    f"{_MONTH_ABB[mo - 1]} {yr}",
            "po_value":       pv,
            "po_value_lakhs": _to_lakhs(pv),
            "po_count":       vals["po_count"],
            "grn_received":        grn,
            "grn_received_lakhs":  _to_lakhs(grn),
            "grn_compliance_pct":  _pct(grn, pv),
        })

    return Response({
        "company": tenant.get("company_name", ""),
        "from":    str(start_date),
        "to":      str(end_date),
        "period":  _fmt_period(start_date, end_date),
        "months":  months_out,
    })


# ─────────────────────────────────────────────────────────────
#  ENDPOINT 8 — PO Types (distinct dtype from POMas)
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_po_types(request):
    """
    Returns all distinct PO types (dtype) from POMas for the filter dropdown.

    Response:
      {
        "po_types": ["Raw Material", "Consumables", "Tooling", ...]
      }

    Excludes 'Job Order' entries (same exclusion used across all other endpoints).
    Always prepends "All Types" so the frontend can use the list directly.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    try:
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT DISTINCT
                LTRIM(RTRIM(ISNULL(dtype, ''))) AS po_type
            FROM POMas
            WHERE ISNULL(deleted, 0) = 0
              AND UPPER(LTRIM(RTRIM(ISNULL(dtype, '')))) <> 'JOB ORDER'
            ORDER BY po_type ASC
            """
        )
        rows = cursor.fetchall()
        cursor.close()
        conn.close()

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)

    po_types = [str(row[0]).strip() for row in rows if row[0] and str(row[0]).strip()]

    return Response({
        "company":  tenant.get("company_name", ""),
        "po_types": ["All Types"] + po_types,
    })


# ────────────────────────────────────────────────────────────
#  ENDPOINT 9 — PO Table (Dashboard2-style)
# ────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_po_table(request):
    """
    Returns PO rows in the same structure as dashboard2_po_pipeline:
      po_number, po_type, vendor_name, material, po_qty,
      value, po_date, grn_no, grn_date

    Optional query params:
      ?from=YYYY-MM-DD  &to=YYYY-MM-DD
      &dtype=Raw Material   (filter by PO type; omit or 'All Types' = no filter)
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    company_code = tenant.get("company_code")
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]

    cursor = None
    try:
        cursor = conn.cursor()

        sch_po, nm_po, q_po = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        sch_det, nm_det, q_det = resolve_erp_table(cursor, ["PODet", "podet", "PODET", "PoDet"])
        sch_grn, nm_grn, q_grn = resolve_erp_table(cursor, ["grninsubdet", "GRNInSubDet", "GrnInSubDet", "GRNINSUBDET"])
        sch_gm, nm_gm, q_gm   = resolve_erp_table(cursor, ["grn_mas", "GRN_MAS", "Grn_Mas", "GrnMas"])
        sch_cm, nm_cm, q_cm   = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST"])
        sch_amnd, nm_amnd, q_amnd = resolve_erp_table(cursor, ["POAmndMas", "poamndmas", "POAMNDMAS", "PoAmndMas"])
        sch_ind, nm_ind, q_ind = resolve_erp_table(cursor, ["PO_InSubIndDet", "po_insubinddet", "PO_INSUBINDDET", "Po_InSubIndDet"])
        sch_pim, nm_pim, q_pim = resolve_erp_table(cursor, ["POInd_Mas", "poind_mas", "POIND_MAS", "PoInd_Mas"])
        sch_pid, nm_pid, q_pid = resolve_erp_table(cursor, ["POInd_Det", "poind_det", "POIND_DET", "PoInd_Det", "poinddet"])
        sch_dm, nm_dm, q_dm   = resolve_erp_table(cursor, ["DepartmentMast", "departmentmast", "DEPARTMENTMAST", "DeptMast"])

        if not q_po or not q_det or not q_grn:
            if cursor: cursor.close()
            conn.close()
            return Response({"error": "Required tables not found.", "rows": [], "summary": None}, status=404)

        # ── column discovery (same as dashboard2_po_pipeline) ──────────────────
        po_pono  = find_column_ci(cursor, sch_po, nm_po, ["pono", "PONo", "PONO", "PoNo", "PONumber"])
        po_date  = find_column_ci(cursor, sch_po, nm_po, ["podate", "PODate", "PO_Date", "po_date", "PODt"])
        po_del   = find_column_ci(cursor, sch_po, nm_po, ["deleted", "Deleted", "IsDeleted"])
        po_dtype = find_column_ci(cursor, sch_po, nm_po, ["dtype", "DType", "POType", "potype", "Type"])
        po_cid   = find_column_ci(cursor, sch_po, nm_po, ["cid", "CId", "CID", "CustId", "custid"])
        po_cc    = find_column_ci(cursor, sch_po, nm_po, company_candidates)

        det_pono = find_column_ci(cursor, sch_det, nm_det, ["pono", "PONo", "PONO", "PoNo"])
        det_del  = find_column_ci(cursor, sch_det, nm_det, ["deleted", "Deleted", "IsDeleted"])
        det_rm   = find_column_ci(cursor, sch_det, nm_det, ["rmname", "RMName", "RMNAME", "RmName", "ItemName"])
        det_mt   = find_column_ci(cursor, sch_det, nm_det, ["mattype", "MatType", "MATTYPE", "Mat_Type"])
        det_uom  = find_column_ci(cursor, sch_det, nm_det, ["uom", "UOM", "Uom", "Unit"])
        det_qty  = find_column_ci(cursor, sch_det, nm_det, ["qty", "Qty", "QTY", "Quantity"])
        det_qtykgs = find_column_ci(cursor, sch_det, nm_det, ["QtyKgs", "qtykgs", "QTYKGS", "Qty_Kgs", "qty_kgs", "QtyMtrsKgs"])
        det_amt  = find_column_ci(cursor, sch_det, nm_det, ["amount", "Amount", "AMOUNT", "Amt", "Value"])
        det_icode = find_column_ci(cursor, sch_det, nm_det, ["icode", "ICode", "ICODE", "itmcode", "ItemCode"])
        det_rate = find_column_ci(cursor, sch_det, nm_det, ["rate", "Rate", "RATE"])

        g_pono  = find_column_ci(cursor, sch_grn, nm_grn, ["pono", "PONo", "PONO", "PoNo"])
        g_grnno = find_column_ci(cursor, sch_grn, nm_grn, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        g_del   = find_column_ci(cursor, sch_grn, nm_grn, ["deleted", "Deleted", "IsDeleted"])

        gm_grn = gm_date = gm_del = gm_namt = None
        if q_gm:
            gm_grn  = find_column_ci(cursor, sch_gm, nm_gm, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
            gm_date = find_column_ci(cursor, sch_gm, nm_gm, ["grndate", "GRNDate", "GRNDATE", "Grn_Date"])
            gm_del  = find_column_ci(cursor, sch_gm, nm_gm, ["deleted", "Deleted", "IsDeleted"])
            gm_namt = find_column_ci(cursor, sch_gm, nm_gm, ["namt", "NAMT", "NetAmt", "GrandTotal", "TotAmt", "Amount"])

        cm_id = cm_name = cm_del = None
        if q_cm:
            cm_id   = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId", "custid"])
            cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName", "Name"])
            cm_del  = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"])

        ind_pono = ind_pino = ind_rm = ind_del = None
        if q_ind:
            ind_pono = find_column_ci(cursor, sch_ind, nm_ind, ["pono", "PONo", "PONO", "PoNo"])
            ind_pino = find_column_ci(cursor, sch_ind, nm_ind, ["pino", "PINo", "PINO", "PiNo"])
            ind_rm   = find_column_ci(cursor, sch_ind, nm_ind, ["rmname", "RMName", "RMNAME", "RmName"])
            ind_del  = find_column_ci(cursor, sch_ind, nm_ind, ["deleted", "Deleted", "IsDeleted"])

        pim_pino = pim_deptcode = pim_date = pim_del = pim_reqby = None
        if q_pim:
            pim_pino = find_column_ci(cursor, sch_pim, nm_pim, ["pino", "PINo", "PINO", "PiNo", "indentno", "IndentNo"])
            pim_date = find_column_ci(cursor, sch_pim, nm_pim, ["pidate", "PIDate", "PIDATE", "PiDate", "pdate", "PDate", "inddate", "IndDate"])
            pim_deptcode = find_column_ci(cursor, sch_pim, nm_pim, ["deptcode", "DeptCode", "DEPTCODE", "Deptcode"])
            pim_reqby = find_column_ci(cursor, sch_pim, nm_pim, [
                "requested_by", "RequestedBy", "requestedby", "Requested_By",
                "reqby", "ReqBy", "REQBY", "Req_By", "req_by",
                "prepared_by", "PreparedBy", "preparedby", "PREPAREDBY", "PrepBy", "prepby",
                "created_by", "CreatedBy", "createdby", "CREATEDBY",
                "username", "UserName", "USERNAME", "user_name", "User_Name", "USER_NAME",
                "emp_name", "EmpName", "EMPNAME", "EmployeeName", "employee_name",
                "indent_by", "IndentBy", "INDENTBY", "IndBy", "indby",
                "request_by", "RequestBy", "requestby", "REQUESTBY"
            ])
            pim_del  = find_column_ci(cursor, sch_pim, nm_pim, ["deleted", "Deleted", "IsDeleted"])

        po_reqby = find_column_ci(cursor, sch_po, nm_po, [
            "requested_by", "RequestedBy", "requestedby", "Requested_By",
            "reqby", "ReqBy", "REQBY", "Req_By", "req_by",
            "prepared_by", "PreparedBy", "preparedby", "PREPAREDBY", "PrepBy", "prepby",
            "created_by", "CreatedBy", "createdby", "CREATEDBY",
            "username", "UserName", "USERNAME", "user_name", "User_Name", "USER_NAME",
            "emp_name", "EmpName", "EMPNAME", "EmployeeName", "employee_name",
            "request_by", "RequestBy", "requestby", "REQUESTBY"
        ]) if q_po else None

        dm_deptcode = dm_department = dm_del = None
        if q_dm:
            dm_deptcode = find_column_ci(cursor, sch_dm, nm_dm, ["DeptCode", "deptcode", "DEPTCODE", "Deptcode"])
            dm_department = find_column_ci(cursor, sch_dm, nm_dm, ["Department", "department", "DEPARTMENT", "DeptName", "deptname"])
            dm_del   = find_column_ci(cursor, sch_dm, nm_dm, ["Deleted", "deleted", "IsDeleted"])

        if not po_pono or not po_date or not det_pono or not det_amt or not g_pono or not g_grnno:
            if cursor: cursor.close()
            conn.close()
            return Response({"error": "Required columns not found.", "rows": [], "summary": None}, status=500)

        # ── SQL fragments ─────────────────────────────────────────────
        del_po_sql  = f"ISNULL(M.[{po_del}], 0) = 0" if po_del else "1=1"
        del_det_sql = f"ISNULL(D.[{det_del}], 0) = 0" if det_del else "1=1"
        grn_dist_where = f"ISNULL(gx.[{g_del}], 0) = 0" if g_del else "1=1"

        # Exclude always-excluded types
        exclude_filter = ""
        if po_dtype:
            exclude_filter = f" AND UPPER(LTRIM(RTRIM(ISNULL(M.[{po_dtype}], N'')))) <> N'JOB ORDER'"

        # Apply user-selected dtype filter
        dtype_filter_sql = ""
        dtype_params = []
        if apply_dtype and po_dtype:
            dtype_filter_sql = f" AND LTRIM(RTRIM(ISNULL(M.[{po_dtype}], N''))) = ?"
            dtype_params.append(dtype_param)

        company_sql = ""
        if po_cc and company_code:
            company_sql = f" AND M.[{po_cc}] = ?"

        # Material concat
        rm_a  = f"D.[{det_rm}]"  if det_rm  else "CAST(NULL AS NVARCHAR(256))"
        mt_a  = f"D.[{det_mt}]"  if det_mt  else "CAST(NULL AS NVARCHAR(256))"
        mat_concat = (
            f"ISNULL(CAST({rm_a} AS NVARCHAR(256)), N'')"
            f" + N' - '"
            f" + ISNULL(CAST({mt_a} AS NVARCHAR(256)), N'')"
        )

        # Qty with UOM
        if det_qty and det_uom:
            if det_qtykgs:
                effective_qty_sql = (
                    f"CASE WHEN UPPER(LTRIM(RTRIM(ISNULL(CAST(D.[{det_uom}] AS NVARCHAR(32)), N'')))) NOT IN (N'NOS', N'NOS.') "
                    f"THEN ISNULL(D.[{det_qtykgs}], 0) ELSE ISNULL(D.[{det_qty}], 0) END"
                )
            else:
                effective_qty_sql = f"ISNULL(D.[{det_qty}], 0)"

            po_qty_sql = (
                f"CAST(ROUND({effective_qty_sql}, 2) AS NVARCHAR(50))"
                f" + N' ' + ISNULL(CAST(D.[{det_uom}] AS NVARCHAR(32)), N'')"
            )
        elif det_qty:
            po_qty_sql = f"CAST(ROUND(ISNULL(D.[{det_qty}], 0), 2) AS NVARCHAR(50))"
        else:
            po_qty_sql = "N''"

        # Vendor name join
        vendor_sql = "CAST(NULL AS NVARCHAR(512))"
        cm_join = ""
        if q_cm and cm_id and cm_name and po_cid:
            cm_del_sql = f" AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
            cm_join = f"LEFT JOIN {q_cm} CM ON M.[{po_cid}] = CM.[{cm_id}]{cm_del_sql}"
            vendor_sql = f"CAST(CM.[{cm_name}] AS NVARCHAR(512))"

        # GRN join (latest grnno per pono)
        g_agg = (
            f"LEFT JOIN ("
            f"  SELECT gx.[{g_pono}] AS pono_g, MAX(gx.[{g_grnno}]) AS grnno_g"
            f"  FROM {q_grn} gx WHERE {grn_dist_where}"
            f"  GROUP BY gx.[{g_pono}]"
            f") G ON M.[{po_pono}] = G.pono_g"
        )
        gm_join = ""
        grn_no_sel = "CAST(G.grnno_g AS NVARCHAR(64))"
        grn_dt_sel = "CAST(NULL AS DATE)"
        if q_gm and gm_grn and gm_date:
            gm_del_j = f" AND ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else ""
            gm_join = f"LEFT JOIN {q_gm} GM ON G.grnno_g = GM.[{gm_grn}]{gm_del_j}"
            grn_dt_sel = f"GM.[{gm_date}]"

        # dtype SELECT expression
        dtype_sel = f"M.[{po_dtype}]" if po_dtype else "CAST(NULL AS NVARCHAR(64))"

        # icode for material code column
        icode_sel = f"D.[{det_icode}]" if det_icode else "CAST(NULL AS NVARCHAR(128))"

        # Amendment status expression
        amnd_sel = "N'N'"
        if q_amnd:
            amnd_mpono = find_column_ci(cursor, sch_amnd, nm_amnd, ["Manualpono", "manualpono", "MANUALPONO", "pono", "PONo"])
            amnd_del = find_column_ci(cursor, sch_amnd, nm_amnd, ["deleted", "Deleted", "IsDeleted"])
            amnd_mpono_col = amnd_mpono or "Manualpono"
            amnd_del_col = f"AND ISNULL(AM.[{amnd_del}], 0) = 0" if amnd_del else ""
            amnd_sel = f"""
                CASE
                    WHEN EXISTS (
                        SELECT 1 FROM {q_amnd} AM
                        WHERE LTRIM(RTRIM(AM.[{amnd_mpono_col}])) = LTRIM(RTRIM(M.[{po_pono}]))
                          {amnd_del_col}
                    ) THEN N'Y'
                    ELSE N'N'
                END
            """

        # Department and PI Number & Date joins via PO_InSubIndDet -> POInd_Mas -> DepartmentMast
        dept_sel = "CAST(NULL AS NVARCHAR(256))"
        pi_no_sel = "CAST(NULL AS NVARCHAR(64))"
        pi_dt_sel = "CAST(NULL AS DATE)"
        reqby_sel = "CAST(NULL AS NVARCHAR(256))"
        dept_line_join = ""
        dept_po_join = ""

        if q_ind and ind_pono and ind_pino:
            del_ind_sql = f"ISNULL(PIS.[{ind_del}], 0) = 0" if ind_del else "1=1"

            pim_join_sql = ""
            pidate_col_sql = "CAST(NULL AS DATE) AS pidate"
            reqby_col_sql = "CAST(NULL AS NVARCHAR(256)) AS RequestedBy"
            if q_pim and pim_pino:
                del_pim_sql = f" AND ISNULL(PIM.[{pim_del}], 0) = 0" if pim_del else ""
                pim_join_sql = f"LEFT JOIN {q_pim} PIM ON LTRIM(RTRIM(PIS.[{ind_pino}])) = LTRIM(RTRIM(PIM.[{pim_pino}])){del_pim_sql}"
                if pim_date:
                    pidate_col_sql = f"MAX(PIM.[{pim_date}]) AS pidate"
                if pim_reqby:
                    reqby_col_sql = f"MAX(LTRIM(RTRIM(PIM.[{pim_reqby}]))) AS RequestedBy"

            dm_join_sql = ""
            dept_col_sql = "CAST(NULL AS NVARCHAR(256)) AS Department"
            if q_pim and pim_deptcode and q_dm and dm_deptcode and dm_department:
                del_dm_sql = f" AND ISNULL(DM.[{dm_del}], 0) = 0" if dm_del else ""
                dm_join_sql = f"LEFT JOIN {q_dm} DM ON LTRIM(RTRIM(PIM.[{pim_deptcode}])) = LTRIM(RTRIM(DM.[{dm_deptcode}])){del_dm_sql}"
                dept_col_sql = f"MAX(LTRIM(RTRIM(DM.[{dm_department}]))) AS Department"

            rm_match_sql = f" AND LTRIM(RTRIM(D.[{det_rm}])) = DEPT_LINE.rmname" if det_rm and ind_rm else ""

            if det_rm and ind_rm:
                dept_line_join = f"""
                    LEFT JOIN (
                        SELECT 
                            LTRIM(RTRIM(PIS.[{ind_pono}])) AS pono,
                            LTRIM(RTRIM(PIS.[{ind_rm}])) AS rmname,
                            MAX(LTRIM(RTRIM(PIS.[{ind_pino}]))) AS pino,
                            {pidate_col_sql},
                            {dept_col_sql},
                            {reqby_col_sql}
                        FROM {q_ind} PIS
                        {pim_join_sql}
                        {dm_join_sql}
                        WHERE {del_ind_sql}
                          AND ISNULL(LTRIM(RTRIM(PIS.[{ind_pono}])), '') <> ''
                        GROUP BY LTRIM(RTRIM(PIS.[{ind_pono}])), LTRIM(RTRIM(PIS.[{ind_rm}]))
                    ) DEPT_LINE ON LTRIM(RTRIM(M.[{po_pono}])) = DEPT_LINE.pono {rm_match_sql}
                """

            dept_po_join = f"""
                LEFT JOIN (
                    SELECT 
                        LTRIM(RTRIM(PIS.[{ind_pono}])) AS pono,
                        MAX(LTRIM(RTRIM(PIS.[{ind_pino}]))) AS pino,
                        {pidate_col_sql},
                        {dept_col_sql},
                        {reqby_col_sql}
                    FROM {q_ind} PIS
                    {pim_join_sql}
                    {dm_join_sql}
                    WHERE {del_ind_sql}
                      AND ISNULL(LTRIM(RTRIM(PIS.[{ind_pono}])), '') <> ''
                    GROUP BY LTRIM(RTRIM(PIS.[{ind_pono}]))
                ) DEPT_PO ON LTRIM(RTRIM(M.[{po_pono}])) = DEPT_PO.pono
            """

            po_reqby_sel = f"M.[{po_reqby}]" if po_reqby else "CAST(NULL AS NVARCHAR(256))"
            if dept_line_join:
                pi_no_sel = f"CAST(COALESCE(DEPT_LINE.pino, DEPT_PO.pino, N'') AS NVARCHAR(64))"
                pi_dt_sel = f"COALESCE(DEPT_LINE.pidate, DEPT_PO.pidate)"
                dept_sel  = f"CAST(COALESCE(DEPT_LINE.Department, DEPT_PO.Department, N'') AS NVARCHAR(256))"
                reqby_sel = f"CAST(COALESCE(DEPT_LINE.RequestedBy, DEPT_PO.RequestedBy, {po_reqby_sel}, N'') AS NVARCHAR(256))"
            else:
                pi_no_sel = f"CAST(ISNULL(DEPT_PO.pino, N'') AS NVARCHAR(64))"
                pi_dt_sel = f"DEPT_PO.pidate"
                dept_sel  = f"CAST(ISNULL(DEPT_PO.Department, N'') AS NVARCHAR(256))"
                reqby_sel = f"CAST(COALESCE(DEPT_PO.RequestedBy, {po_reqby_sel}, N'') AS NVARCHAR(256))"
        elif po_reqby:
            reqby_sel = f"CAST(ISNULL(M.[{po_reqby}], N'') AS NVARCHAR(256))"

        # rate select expression
        rate_sel = f"ISNULL(CAST(D.[{det_rate}] AS FLOAT), 0)" if det_rate else "0"

        # Supplier filters
        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "M", join_if_needed=True)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "M")

        # Build params
        params = [start_date, end_date] + dtype_params + params_flt + srch_params
        if po_cc and company_code:
            params.append(company_code)

        where_clause = (
            f"CAST(M.[{po_date}] AS DATE) BETWEEN ? AND ?"
            f" AND {del_po_sql}"
            f"{exclude_filter}"
            f"{dtype_filter_sql}"
            f"{company_sql}"
            f"{where_flt}"
            f"{srch_sql}"
        )

        detail_sql = f"""
            SELECT TOP 3000
                M.[{po_pono}]                           AS PO_Number,
                {dtype_sel}                             AS PO_Type,
                {vendor_sql}                            AS Vendor_Name,
                CAST({icode_sel} AS NVARCHAR(128))       AS Material_Code,
                CAST({mat_concat} AS NVARCHAR(520))      AS Material,
                CAST({po_qty_sql} AS NVARCHAR(120))      AS PO_Qty,
                {rate_sel}                              AS Rate,
                ISNULL(CAST(D.[{det_amt}] AS FLOAT), 0) AS Value,
                M.[{po_date}]                           AS PO_Date,
                {grn_no_sel}                            AS GRN_No,
                {grn_dt_sel}                            AS GRN_Date,
                {amnd_sel}                              AS Amnd,
                {dept_sel}                              AS Department,
                {pi_no_sel}                             AS PI_No,
                {pi_dt_sel}                             AS PI_Date,
                {reqby_sel}                             AS Requested_By
            FROM {q_po} M
            INNER JOIN {q_det} D
                ON M.[{po_pono}] = D.[{det_pono}] AND {del_det_sql}
            {cm_join}
            {g_agg}
            {gm_join}
            {dept_line_join}
            {dept_po_join}
            {join_flt}
            WHERE {where_clause}
            ORDER BY M.[{po_date}], M.[{po_pono}]
        """

        cursor.execute(detail_sql, params)
        rows_out = []
        for row in cursor.fetchall() or []:
            po_dt  = row[8]
            grn_dt = row[10]
            pi_dt  = row[14]

            def _iso(d):
                if d is None: return ""
                if hasattr(d, "isoformat"): return d.isoformat()[:10]
                return str(d)[:10]

            rows_out.append({
                "po_number":     str(row[0] or "").strip(),
                "po_type":       str(row[1] or "").strip(),
                "vendor_name":   str(row[2] or "").strip(),
                "material_code": str(row[3] or "").strip(),
                "material":      str(row[4] or "").strip(),
                "po_qty":        str(row[5] or "").strip(),
                "rate":          float(row[6] or 0),
                "value":         float(row[7] or 0),
                "po_date":       _iso(po_dt),
                "grn_no":        str(row[9] or "").strip(),
                "grn_date":      _iso(grn_dt),
                "amnd":          str(row[11] or "N").strip(),
                "department":    str(row[12] or "").strip(),
                "pi_no":         str(row[13] or "").strip(),
                "pi_date":       _iso(pi_dt),
                "requested_by":  str(row[15] or "").strip(),
            })

        # ── Also query Pending PIs (Purchase Indents awaiting PO generation) ──
        if q_pim and q_pid:
            pi_dtype_flt = ""
            pi_dtype_params = []
            if apply_dtype and po_dtype:
                pi_dtype_flt = " AND LTRIM(RTRIM(ISNULL(PIM.[dtype], N''))) = ?"
                pi_dtype_params.append(dtype_param)

            pi_cm_join = f"LEFT JOIN {q_cm} CM ON PID.[sid] = CM.[{cm_id}] AND ISNULL(CM.[{cm_del}], 0) = 0" if (q_cm and cm_id and cm_del) else ""
            vendor_expr = f"ISNULL(CM.[{cm_name}], N'–')" if (q_cm and cm_name) else "N'–'"

            pi_dm_sub = ""
            if q_dm and dm_deptcode and dm_department:
                dm_del_cond = f" AND ISNULL(DM.[{dm_del}], 0) = 0" if dm_del else ""
                pi_dm_sub = f"ISNULL((SELECT TOP 1 DM.[{dm_department}] FROM {q_dm} DM WHERE DM.[{dm_deptcode}] = PIM.[deptcode]{dm_del_cond}), N'–')"
            else:
                pi_dm_sub = "N'–'"

            pi_reqby_sub = f"ISNULL(PIM.[{pim_reqby}], N'–')" if (q_pim and pim_reqby) else "N'–'"

            pis_del_cond = f" AND ISNULL(PIS.[{ind_del}], 0) = 0" if (q_ind and ind_del) else ""
            pis_not_exists = ""
            if q_ind and ind_pono and ind_pino:
                rm_cond = f" AND PIS.[{ind_rm}] = PID.[rmname]" if ind_rm else ""
                pis_not_exists = f"""
                    AND NOT EXISTS (
                        SELECT 1 FROM {q_ind} PIS
                        WHERE PIS.[{ind_pino}] = PID.[pino]
                          {rm_cond}
                          {pis_del_cond}
                          AND ISNULL(PIS.[{ind_pono}], '') <> ''
                    )
                """

            pi_sql = f"""
                SELECT TOP 1000
                    N'–' AS PO_Number,
                    ISNULL(PIM.[dtype], N'') AS PO_Type,
                    {vendor_expr} AS Vendor_Name,
                    N'' AS Material_Code,
                    ISNULL(CAST(PID.[rmname] AS NVARCHAR(256)), N'') + N' - ' + ISNULL(CAST(PID.[mattype] AS NVARCHAR(256)), N'') AS Material,
                    CAST(ROUND(ISNULL(PID.[qty], 0), 2) AS NVARCHAR(50)) + N' ' + ISNULL(CAST(PID.[uom] AS NVARCHAR(32)), N'') AS PO_Qty,
                    ISNULL(CAST(PID.[Rate] AS FLOAT), 0) AS Rate,
                    ROUND(ISNULL(PID.[qty], 0) * ISNULL(CAST(PID.[Rate] AS FLOAT), 0), 2) AS Value,
                    CAST(NULL AS DATE) AS PO_Date,
                    N'–' AS GRN_No,
                    CAST(NULL AS DATE) AS GRN_Date,
                    N'N' AS Amnd,
                    {pi_dm_sub} AS Department,
                    PIM.[pino] AS PI_No,
                    PIM.[pidate] AS PI_Date,
                    {pi_reqby_sub} AS Requested_By,
                    1 AS is_pi_pending
                FROM {q_pim} PIM
                INNER JOIN {q_pid} PID 
                    ON PIM.[pino] = PID.[pino] 
                   AND ISNULL(PID.[deleted], 0) = 0
                   AND ISNULL(PID.[poindclose], 0) = 0
                   AND ISNULL(PID.[poindcancel], 0) = 0
                {pi_cm_join}
                WHERE ISNULL(PIM.[deleted], 0) = 0
                  AND CAST(PIM.[pidate] AS DATE) BETWEEN ? AND ?
                  AND (PID.[pono] IS NULL OR ISNULL(PID.[pono], '') = '')
                  {pi_dtype_flt}
                  {pis_not_exists}
                ORDER BY PIM.[pidate], PIM.[pino]
            """
            pi_params = [start_date, end_date] + pi_dtype_params
            try:
                cursor.execute(pi_sql, pi_params)
                for row in cursor.fetchall() or []:
                    pi_dt = row[14]
                    rows_out.append({
                        "po_number":     str(row[0] or "–").strip(),
                        "po_type":       str(row[1] or "").strip(),
                        "vendor_name":   str(row[2] or "–").strip(),
                        "material_code": str(row[3] or "").strip(),
                        "material":      str(row[4] or "").strip(),
                        "po_qty":        str(row[5] or "").strip(),
                        "rate":          float(row[6] or 0),
                        "value":         float(row[7] or 0),
                        "po_date":       "",
                        "grn_no":        str(row[9] or "–").strip(),
                        "grn_date":      "",
                        "amnd":          str(row[11] or "N").strip(),
                        "department":    str(row[12] or "–").strip(),
                        "pi_no":         str(row[13] or "").strip(),
                        "pi_date":       _iso(pi_dt),
                        "requested_by":  str(row[15] or "–").strip(),
                        "is_pi_pending": True,
                    })
            except Exception as e:
                logger.warning(f"Error fetching pending PIs: {e}")

        # ── Compute pipeline summary ─────────────────────────────────────
        # Determine per-PO GRN status from the rows we already have
        po_grn_map = {}
        for r in rows_out:
            pono = r["po_number"]
            if not pono or pono == "–" or pono == "-" or r.get("is_pi_pending"):
                continue
            if pono not in po_grn_map:
                po_grn_map[pono] = bool(r["grn_no"] and r["grn_no"] != "–")
            elif r["grn_no"] and r["grn_no"] != "–":
                po_grn_map[pono] = True

        s_total_pos      = len(po_grn_map)
        s_grn_done       = sum(1 for v in po_grn_map.values() if v)
        s_grn_pending    = s_total_pos - s_grn_done
        s_total_po_value = round(sum(r["value"] for r in rows_out if not r.get("is_pi_pending")), 2)

        # Total GRN value from grn_mas (separate query)
        s_total_grn_value = 0.0
        if q_gm and gm_grn and gm_namt:
            gm_del_sql2  = f"ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else "1=1"
            gjoin_del2   = f"ISNULL(GX.[{g_del}], 0) = 0" if g_del else "1=1"
            grn_val_sql  = f"""
                SELECT ISNULL(SUM(ISNULL(CAST(GM.[{gm_namt}] AS FLOAT), 0)), 0)
                FROM {q_gm} GM
                INNER JOIN {q_grn} GX ON GM.[{gm_grn}] = GX.[{g_grnno}]
                WHERE {gjoin_del2} AND {gm_del_sql2}
                  AND GX.[{g_pono}] IN (
                      SELECT DISTINCT M.[{po_pono}]
                      FROM {q_po} M
                      WHERE {where_clause}
                  )
            """
            try:
                cursor.execute(grn_val_sql, params)
                grn_row = cursor.fetchone()
                if grn_row and grn_row[0] is not None:
                    s_total_grn_value = round(float(grn_row[0]), 2)
            except Exception:
                pass  # non-fatal; leave total_grn_value = 0

        cursor.close()
        conn.close()

    except Exception as e:
        if cursor:
            try: cursor.close()
            except Exception: pass
        try: conn.close()
        except Exception: pass
        return Response({"error": f"Database error: {str(e)}", "rows": []}, status=500)

    return Response({
        "company": tenant.get("company_name", ""),
        "from":    str(start_date),
        "to":      str(end_date),
        "dtype":   dtype_param or "All Types",
        "count":   len(rows_out),
        "summary": {
            "total_pos":       s_total_pos,
            "total_po_value":  s_total_po_value,
            "grn_done":        s_grn_done,
            "grn_pending":     s_grn_pending,
            "total_grn_value": s_total_grn_value,
        },
        "rows":    rows_out,
    })


@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_amended_po_table(request):
    """
    Returns actual amended PO rows matching the specified SQL query logic.
    Supports tenant resolution, date range parsing, and dtype selection filters.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e), "rows": []}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    cursor = None
    try:
        cursor = conn.cursor()

        sch_po, nm_po, q_po = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        sch_grn, nm_grn, q_grn = resolve_erp_table(cursor, ["grninsubdet", "GRNInSubDet", "GrnInSubDet", "GRNINSUBDET"])
        sch_gm, nm_gm, q_gm   = resolve_erp_table(cursor, ["grn_mas", "GRN_MAS", "Grn_Mas", "GrnMas"])
        sch_cm, nm_cm, q_cm   = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST"])
        sch_amnd, nm_amnd, q_amnd = resolve_erp_table(cursor, ["POAmndMas", "poamndmas", "POAMNDMAS", "PoAmndMas"])
        sch_adet, nm_adet, q_adet = resolve_erp_table(cursor, ["POAmndDet", "poamnddet", "POAMNDDET", "PoAmndDet"])

        if not q_po or not q_grn or not q_amnd or not q_adet:
            if cursor: cursor.close()
            conn.close()
            return Response({"rows": []}, status=200)

        # Discovery of column names
        po_pono  = find_column_ci(cursor, sch_po, nm_po, ["pono", "PONo", "PONO", "PoNo"])
        po_date  = find_column_ci(cursor, sch_po, nm_po, ["podate", "PODate", "PO_Date", "po_date"])
        po_del   = find_column_ci(cursor, sch_po, nm_po, ["deleted", "Deleted", "IsDeleted"])
        po_dtype = find_column_ci(cursor, sch_po, nm_po, ["dtype", "DType", "POType", "potype", "Type"])
        po_cid   = find_column_ci(cursor, sch_po, nm_po, ["cid", "CId", "CID", "CustId"])

        amnd_mpono = find_column_ci(cursor, sch_amnd, nm_amnd, ["Manualpono", "manualpono", "MANUALPONO", "pono"])
        amnd_no = find_column_ci(cursor, sch_amnd, nm_amnd, ["amdno", "AmdNo", "AMDNO", "AmendmentNo"])
        amnd_date = find_column_ci(cursor, sch_amnd, nm_amnd, ["amddate", "AmdDate", "AMDDATE", "AmendmentDate"])
        amnd_del = find_column_ci(cursor, sch_amnd, nm_amnd, ["deleted", "Deleted", "IsDeleted"])

        adet_no = find_column_ci(cursor, sch_adet, nm_adet, ["amdno", "AmdNo", "AMDNO", "AmendmentNo"])
        adet_rm = find_column_ci(cursor, sch_adet, nm_adet, ["rmname", "RMName", "RMNAME", "RmName"])
        adet_mt = find_column_ci(cursor, sch_adet, nm_adet, ["mattype", "MatType", "MATTYPE"])
        adet_uom = find_column_ci(cursor, sch_adet, nm_adet, ["uom", "UOM", "Uom", "Unit"])
        adet_qty = find_column_ci(cursor, sch_adet, nm_adet, ["qty", "Qty", "QTY", "Quantity"])
        adet_rate = find_column_ci(cursor, sch_adet, nm_adet, ["rate", "Rate", "RATE"])
        adet_amt = find_column_ci(cursor, sch_adet, nm_adet, ["amount", "Amount", "AMOUNT", "Amt"])
        adet_del = find_column_ci(cursor, sch_adet, nm_adet, ["deleted", "Deleted", "IsDeleted"])
        adet_seq = find_column_ci(cursor, sch_adet, nm_adet, ["seq", "Seq", "SEQ"])

        g_pono  = find_column_ci(cursor, sch_grn, nm_grn, ["pono", "PONo", "PONO", "PoNo"])
        g_grnno = find_column_ci(cursor, sch_grn, nm_grn, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
        g_del   = find_column_ci(cursor, sch_grn, nm_grn, ["deleted", "Deleted", "IsDeleted"])

        gm_grn = gm_date = gm_del = None
        if q_gm:
            gm_grn  = find_column_ci(cursor, sch_gm, nm_gm, ["grnno", "GRNNo", "GRNNO", "GrnNo"])
            gm_date = find_column_ci(cursor, sch_gm, nm_gm, ["grndate", "GRNDate", "GRNDATE"])
            gm_del  = find_column_ci(cursor, sch_gm, nm_gm, ["deleted", "Deleted", "IsDeleted"])

        cm_id = cm_name = cm_del = None
        if q_cm:
            cm_id   = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId"])
            cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName"])
            cm_del  = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"])

        # Supplier filters
        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "M", join_if_needed=True)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "M")

        # ── SQL fragments ─────────────────────────────────────────────
        del_po_sql  = f"ISNULL(M.[{po_del}], 0) = 0" if po_del else "1=1"
        del_amnd_sql = f"ISNULL(PAM.[{amnd_del}], 0) = 0" if amnd_del else "1=1"
        del_adet_sql = f"ISNULL(AMD.[{adet_del}], 0) = 0" if adet_del else "1=1"
        grn_dist_where = f"ISNULL(gx.[{g_del}], 0) = 0" if g_del else "1=1"

        exclude_filter = ""
        if po_dtype:
            exclude_filter = f" AND UPPER(LTRIM(RTRIM(ISNULL(M.[{po_dtype}], N'')))) <> N'JOB ORDER'"

        dtype_filter_sql = ""
        dtype_params = []
        if apply_dtype and po_dtype:
            dtype_filter_sql = f" AND LTRIM(RTRIM(ISNULL(M.[{po_dtype}], N''))) = ?"
            dtype_params.append(dtype_param)

        vendor_sql = "CAST(NULL AS NVARCHAR(512))"
        cm_join = ""
        if q_cm and cm_id and cm_name and po_cid:
            cm_del_sql = f" AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
            cm_join = f"LEFT JOIN {q_cm} CM ON M.[{po_cid}] = CM.[{cm_id}]{cm_del_sql}"
            vendor_sql = f"CAST(CM.[{cm_name}] AS NVARCHAR(512))"

        g_agg = (
            f"LEFT JOIN ("
            f"  SELECT gx.[{g_pono}] AS pono_g, MAX(gx.[{g_grnno}]) AS grnno_g"
            f"  FROM {q_grn} gx WHERE {grn_dist_where}"
            f"  GROUP BY gx.[{g_pono}]"
            f") G ON M.[{po_pono}] = G.pono_g"
        )
        gm_join = ""
        grn_no_sel = "CAST(G.grnno_g AS NVARCHAR(64))"
        grn_dt_sel = "CAST(NULL AS DATE)"
        if q_gm and gm_grn and gm_date:
            gm_del_j = f" AND ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else ""
            gm_join = f"LEFT JOIN {q_gm} GM ON G.grnno_g = GM.[{gm_grn}]{gm_del_j}"
            grn_dt_sel = f"GM.[{gm_date}]"

        dtype_sel = f"M.[{po_dtype}]" if po_dtype else "CAST(NULL AS NVARCHAR(64))"

        rm_col = f"AMD.[{adet_rm}]" if adet_rm else "CAST(NULL AS NVARCHAR(256))"
        mt_col = f"AMD.[{adet_mt}]" if adet_mt else "N''"
        mat_concat_sql = f"""
            CAST(
                ISNULL(CAST({rm_col} AS NVARCHAR(256)), N'')
                +
                CASE
                    WHEN ISNULL(LTRIM(RTRIM({mt_col})), '') <> ''
                    THEN N' - ' + CAST({mt_col} AS NVARCHAR(256))
                    ELSE N''
                END
                AS NVARCHAR(520)
            )
        """

        qty_col = f"AMD.[{adet_qty}]" if adet_qty else "0"
        uom_col = f"AMD.[{adet_uom}]" if adet_uom else "N''"
        qty_concat_sql = f"""
            CAST(
                CAST(ROUND(ISNULL({qty_col}, 0), 2) AS NVARCHAR(50))
                + N' '
                + ISNULL(CAST({uom_col} AS NVARCHAR(32)), N'')
                AS NVARCHAR(120)
            )
        """

        rate_sel = f"ISNULL(AMD.[{adet_rate}], 0)" if adet_rate else "0"
        val_sel = f"ISNULL(AMD.[{adet_amt}], 0)" if adet_amt else "0"
        seq_col = f"AMD.[{adet_seq}]" if adet_seq else "1"

        detail_sql = f"""
            SELECT TOP 3000
                M.[{po_pono}]                           AS PO_Number,
                AM.[{amnd_no}]                           AS PO_Amnd_No,
                AM.[{amnd_date}]                         AS PO_Amnd_Date,
                {dtype_sel}                             AS PO_Type,
                {vendor_sql}                            AS Vendor_Name,
                CAST(ISNULL({rm_col}, '') AS NVARCHAR(256)) AS Material_Code,
                {mat_concat_sql}                        AS Material,
                {qty_concat_sql}                        AS PO_Qty,
                {rate_sel}                              AS Rate,
                {val_sel}                               AS Value,
                M.[{po_date}]                           AS PO_Date,
                {grn_no_sel}                            AS GRN_No,
                {grn_dt_sel}                            AS GRN_Date
            FROM {q_po} M
            CROSS APPLY
            (
                SELECT TOP 1
                    PAM.[{amnd_no}],
                    PAM.[{amnd_date}]
                FROM {q_amnd} PAM
                WHERE LTRIM(RTRIM(PAM.[{amnd_mpono}])) = LTRIM(RTRIM(M.[{po_pono}]))
                  AND {del_amnd_sql}
                ORDER BY PAM.[{amnd_date}] DESC, PAM.[{amnd_no}] DESC
            ) AM
            INNER JOIN {q_adet} AMD
                ON LTRIM(RTRIM(AMD.[{adet_no}])) = LTRIM(RTRIM(AM.[{amnd_no}]))
                AND {del_adet_sql}
            {cm_join}
            {g_agg}
            {gm_join}
            {join_flt}
            WHERE CAST(M.[{po_date}] AS DATE) BETWEEN ? AND ?
              AND {del_po_sql}
              {exclude_filter}
              {dtype_filter_sql}
              {where_flt}
            ORDER BY M.[{po_date}], M.[{po_pono}], {seq_col}
        """

        params = [start_date, end_date] + dtype_params + params_flt
        cursor.execute(detail_sql, params)

        rows_out = []
        for row in cursor.fetchall() or []:
            amd_dt = row[2]
            po_dt  = row[10]
            grn_dt = row[12]

            def _iso(d):
                if d is None: return ""
                if hasattr(d, "isoformat"): return d.isoformat()[:10]
                return str(d)[:10]

            rows_out.append({
                "po_number":     str(row[0] or "").strip(),
                "po_amnd_no":    str(row[1] or "").strip(),
                "po_amnd_date":  _iso(amd_dt),
                "po_type":       str(row[3] or "").strip(),
                "vendor_name":   str(row[4] or "").strip(),
                "material_code": str(row[5] or "").strip(),
                "material":      str(row[6] or "").strip(),
                "po_qty":        str(row[7] or "").strip(),
                "rate":          float(row[8] or 0),
                "value":         float(row[9] or 0),
                "po_date":       _iso(po_dt),
                "grn_no":        str(row[11] or "").strip(),
                "grn_date":      _iso(grn_dt),
            })

        if cursor: cursor.close()
        conn.close()
        return Response({"rows": rows_out}, status=200)

    except Exception as e:
        if cursor: cursor.close()
        try: conn.close()
        except: pass
        return Response({"error": str(e), "rows": []}, status=500)


@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_short_close_table(request):
    """
    Returns actual Short Close PO Details matching the ShotClsReason / ShotClsUser filters.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e), "rows": []}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    cursor = None
    try:
        cursor = conn.cursor()

        sch_po, nm_po, q_po = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        sch_det, nm_det, q_det = resolve_erp_table(cursor, ["PODet", "podet", "PODET", "PoDet"])
        sch_cm, nm_cm, q_cm   = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST"])

        if not q_po or not q_det:
            if cursor: cursor.close()
            conn.close()
            return Response({"rows": []}, status=200)

        # Discovery of column names
        po_pono  = find_column_ci(cursor, sch_po, nm_po, ["pono", "PONo", "PONO", "PoNo"])
        po_date  = find_column_ci(cursor, sch_po, nm_po, ["podate", "PODate", "PO_Date", "po_date"])
        po_del   = find_column_ci(cursor, sch_po, nm_po, ["deleted", "Deleted", "IsDeleted"])
        po_dtype = find_column_ci(cursor, sch_po, nm_po, ["dtype", "DType", "POType", "potype", "Type"])
        po_cid   = find_column_ci(cursor, sch_po, nm_po, ["cid", "CId", "CID", "CustId"])

        det_pono = find_column_ci(cursor, sch_det, nm_det, ["pono", "PONo", "PONO", "PoNo"])
        det_del  = find_column_ci(cursor, sch_det, nm_det, ["deleted", "Deleted", "IsDeleted"])
        det_rm   = find_column_ci(cursor, sch_det, nm_det, ["rmname", "RMName", "RMNAME", "RmName"])
        det_mt   = find_column_ci(cursor, sch_det, nm_det, ["mattype", "MatType", "MATTYPE"])
        det_uom  = find_column_ci(cursor, sch_det, nm_det, ["uom", "UOM", "Uom", "Unit"])
        det_qty  = find_column_ci(cursor, sch_det, nm_det, ["qty", "Qty", "QTY", "Quantity"])
        det_clsreason = find_column_ci(cursor, sch_det, nm_det, ["ShotClsReason", "shotclsreason", "ShotCls_Reason", "shortclose_reason", "ShortCloseReason"])
        det_clsuser = find_column_ci(cursor, sch_det, nm_det, ["ShotClsUser", "shotclsuser", "ShotCls_User", "shortclose_user", "ShortCloseUser"])

        cm_id = cm_name = cm_del = None
        if q_cm:
            cm_id   = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId"])
            cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName"])
            cm_del  = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"])

        # Supplier filters
        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "M", join_if_needed=True)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "M")

        # ── SQL fragments ─────────────────────────────────────────────
        del_po_sql  = f"ISNULL(M.[{po_del}], 0) = 0" if po_del else "1=1"
        del_det_sql = f"ISNULL(D.[{det_del}], 0) = 0" if det_del else "1=1"

        exclude_filter = ""
        if po_dtype:
            exclude_filter = f" AND UPPER(LTRIM(RTRIM(ISNULL(M.[{po_dtype}], N'')))) <> N'JOB ORDER'"

        dtype_filter_sql = ""
        dtype_params = []
        if apply_dtype and po_dtype:
            dtype_filter_sql = f" AND LTRIM(RTRIM(ISNULL(M.[{po_dtype}], N''))) = ?"
            dtype_params.append(dtype_param)

        vendor_sql = "CAST(NULL AS NVARCHAR(512))"
        cm_join = ""
        if q_cm and cm_id and cm_name and po_cid:
            cm_del_sql = f" AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
            cm_join = f"LEFT JOIN {q_cm} CM ON M.[{po_cid}] = CM.[{cm_id}]{cm_del_sql}"
            vendor_sql = f"CAST(CM.[{cm_name}] AS NVARCHAR(512))"

        rm_col = f"D.[{det_rm}]" if det_rm else "CAST(NULL AS NVARCHAR(256))"
        mt_col = f"D.[{det_mt}]" if det_mt else "N''"
        mat_concat_sql = f"""
            CAST(
                ISNULL(CAST({rm_col} AS NVARCHAR(256)), N'')
                +
                CASE
                    WHEN ISNULL(LTRIM(RTRIM({mt_col})), '') <> ''
                    THEN N' - ' + CAST({mt_col} AS NVARCHAR(256))
                    ELSE N''
                END
                AS NVARCHAR(520)
            )
        """

        uom_col = f"ISNULL(D.[{det_uom}], N'')" if det_uom else "N''"
        qty_col = f"ISNULL(D.[{det_qty}], 0)" if det_qty else "0"
        reason_col = f"ISNULL(D.[{det_clsreason}], N'')" if det_clsreason else "N''"
        user_col = f"ISNULL(D.[{det_clsuser}], N'')" if det_clsuser else "N''"

        # Show only when ShotClsReason OR ShotClsUser has data
        where_condition = f"""
            (
                ISNULL(LTRIM(RTRIM({reason_col})), '') <> ''
                OR
                ISNULL(LTRIM(RTRIM({user_col})), '') <> ''
            )
        """

        detail_sql = f"""
            SELECT TOP 3000
                ROW_NUMBER() OVER (ORDER BY M.[{po_date}], M.[{po_pono}]) AS [#],
                M.[{po_pono}]                           AS PO_Number,
                M.[{po_date}]                           AS PO_Date,
                {vendor_sql}                            AS Supplier_Name,
                {mat_concat_sql}                        AS Material,
                {uom_col}                               AS UOM,
                {qty_col}                               AS Short_Close_Qty,
                {reason_col}                            AS Reason,
                {user_col}                              AS Short_Close_User
            FROM {q_po} M
            INNER JOIN {q_det} D
                ON M.[{po_pono}] = D.[{det_pono}] AND {del_det_sql}
            {cm_join}
            {join_flt}
            WHERE CAST(M.[{po_date}] AS DATE) BETWEEN ? AND ?
              AND {del_po_sql}
              AND {where_condition}
              {exclude_filter}
              {dtype_filter_sql}
              {where_flt}
              {srch_sql}
            ORDER BY M.[{po_date}], M.[{po_pono}]
        """

        params = [start_date, end_date] + dtype_params + params_flt + srch_params
        cursor.execute(detail_sql, params)

        rows_out = []
        for row in cursor.fetchall() or []:
            po_dt = row[2]

            def _iso(d):
                if d is None: return ""
                if hasattr(d, "isoformat"): return d.isoformat()[:10]
                return str(d)[:10]

            rows_out.append({
                "sno":               int(row[0] or 0),
                "po_number":         str(row[1] or "").strip(),
                "po_date":           _iso(po_dt),
                "supplier_name":     str(row[3] or "").strip(),
                "material":          str(row[4] or "").strip(),
                "uom":               str(row[5] or "").strip(),
                "short_close_qty":   float(row[6] or 0),
                "reason":            str(row[7] or "").strip(),
                "short_close_user":  str(row[8] or "").strip(),
            })

        if cursor: cursor.close()
        conn.close()
        return Response({"rows": rows_out}, status=200)

    except Exception as e:
        if cursor: cursor.close()
        try: conn.close()
        except: pass
        return Response({"error": str(e), "rows": []}, status=500)


@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_price_trend_table(request):
    """
    Calculates Price Trend details based on Commer_BaseRateDet (BReffdt rate changes),
    Commer_Mas, and CustMast for supplier name.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e), "rows": []}, status=401)

    start_date, end_date = parse_date_range(request)

    cursor = None
    try:
        cursor = conn.cursor()

        use_alias = table_exists(cursor, "CustAliasMast")
        if use_alias:
            sup_name_expr = (
                "LTRIM(RTRIM(ISNULL("
                "NULLIF(LTRIM(RTRIM(ISNULL(C.CName, N''))), N''), "
                "NULLIF(LTRIM(RTRIM(ISNULL(A.CName, N''))), N'')"
                ")))"
            )
            sup_join = """
                LEFT JOIN (
                    SELECT cmno, PartNo, cid,
                           ROW_NUMBER() OVER (PARTITION BY cmno, PartNo ORDER BY ISNULL(Beffdt, '1900-01-01') DESC) AS rn
                    FROM Commer_CustDet
                    WHERE ISNULL(deleted, 0) = 0
                ) CCD ON CBD.cmno = CCD.cmno AND (CBD.PartNo = CCD.PartNo OR CCD.PartNo IS NULL OR CCD.PartNo = '') AND CCD.rn = 1
                LEFT JOIN CustMast C ON LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(C.Id, N'')))) = LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(CCD.cid, ISNULL(CM.cid, N'')))))
                LEFT JOIN CustAliasMast A ON LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(A.Id, N'')))) = LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(CCD.cid, ISNULL(CM.cid, N'')))))
            """
        else:
            sup_name_expr = "LTRIM(RTRIM(ISNULL(C.CName, N'')))"
            sup_join = """
                LEFT JOIN (
                    SELECT cmno, PartNo, cid,
                           ROW_NUMBER() OVER (PARTITION BY cmno, PartNo ORDER BY ISNULL(Beffdt, '1900-01-01') DESC) AS rn
                    FROM Commer_CustDet
                    WHERE ISNULL(deleted, 0) = 0
                ) CCD ON CBD.cmno = CCD.cmno AND (CBD.PartNo = CCD.PartNo OR CCD.PartNo IS NULL OR CCD.PartNo = '') AND CCD.rn = 1
                LEFT JOIN CustMast C ON LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(C.Id, N'')))) = LTRIM(RTRIM(CONVERT(NVARCHAR(128), ISNULL(CCD.cid, ISNULL(CM.cid, N'')))))
            """

        search_q = (request.GET.get("search") or request.GET.get("q") or "").strip()
        search_sql = ""
        search_params = []
        if search_q:
            search_sql = f" AND (CBD.PartNo LIKE ? OR CM.Description LIKE ? OR ({sup_name_expr}) LIKE ?)"
            search_params = [f"%{search_q}%", f"%{search_q}%", f"%{search_q}%"]

        supplier_filter = (request.GET.get("supplier") or "").strip()
        supplier_sql = ""
        supplier_params = []
        if supplier_filter and supplier_filter.lower() != "all suppliers":
            sups = [s.strip() for s in supplier_filter.split(",") if s.strip()]
            if sups:
                placeholders = ",".join(["?"] * len(sups))
                supplier_sql = f" AND ({sup_name_expr}) IN ({placeholders})"
                supplier_params = sups

        sql = f"""
            WITH RateHistory AS (
                SELECT
                    CBD.cmno,
                    CBD.PartNo,
                    ISNULL(CM.Description, N'') AS Description,
                    {sup_name_expr} AS SupplierName,
                    CBD.BReffdt,
                    CAST(CBD.BReffdt AS DATE) AS EffDate,
                    ISNULL(CBD.BaseRate, 0) AS BaseRate,
                    LAG(ISNULL(CBD.BaseRate, 0)) OVER (
                        PARTITION BY CBD.PartNo, ISNULL(CCD.cid, ISNULL(CM.cid, 0))
                        ORDER BY CBD.BReffdt ASC, CBD.cmno ASC
                    ) AS PrevRate
                FROM Commer_BaseRateDet CBD
                INNER JOIN Commer_Mas CM ON CBD.cmno = CM.cmno
                {sup_join}
                WHERE ISNULL(CBD.deleted, 0) = 0
                  AND ISNULL(CM.deleted, 0) = 0
                  AND CBD.BReffdt IS NOT NULL
                  AND ISNULL(CBD.BaseRate, 0) > 0
                  {search_sql}
                  {supplier_sql}
            )
            SELECT
                PartNo,
                Description,
                SupplierName,
                EffDate,
                BaseRate,
                PrevRate
            FROM RateHistory
            WHERE EffDate BETWEEN ? AND ?
            ORDER BY EffDate DESC, PartNo ASC;
        """

        exec_params = search_params + supplier_params + [start_date, end_date]
        cursor.execute(sql, exec_params)

        rows_out = []
        sno = 1
        for row in cursor.fetchall() or []:
            part_no = str(row[0] or "").strip()
            description = str(row[1] or "").strip()
            supplier_name = str(row[2] or "").strip() or "—"
            eff_date = row[3]
            base_rate = float(row[4] or 0)
            prev_rate = float(row[5] or 0) if row[5] is not None else 0.0

            part_desc = f"{part_no} - {description}" if part_no and description else (part_no or description or "—")

            diff = base_rate - prev_rate if prev_rate > 0 else 0.0
            pct = round((diff / prev_rate) * 100.0, 1) if prev_rate > 0 else 0.0

            trend_type = "flat"
            if pct > 0:
                trend_type = "up"
            elif pct < 0:
                trend_type = "down"

            if hasattr(eff_date, "strftime"):
                date_label = eff_date.strftime("%d-%b-%Y")
            elif eff_date:
                date_label = str(eff_date)[:10]
            else:
                date_label = "—"

            rows_out.append({
                "sno": sno,
                "partNo": part_no,
                "description": description,
                "partDesc": part_desc,
                "supplier": supplier_name,
                "supplierName": supplier_name,
                "month": date_label,
                "effDate": date_label,
                "rate": round(base_rate, 2),
                "pct": abs(pct),
                "diff": round(abs(diff), 2),
                "type": trend_type
            })
            sno += 1

        if cursor: cursor.close()
        conn.close()
        return Response({"rows": rows_out}, status=200)

    except Exception as e:
        if cursor: cursor.close()
        try: conn.close()
        except: pass
        return Response({"error": str(e), "rows": []}, status=500)


@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_management_alerts(request):
    """
    Dynamically generates management alerts and prioritized actions from ERP database.
    """
    from datetime import datetime
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e), "alerts": [], "key_action": ""}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    cursor = None
    alerts_list = []
    key_action = ""

    try:
        cursor = conn.cursor()

        sch_po, nm_po, q_po = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        sch_det, nm_det, q_det = resolve_erp_table(cursor, ["PODet", "podet", "PODET", "PoDet"])

        if q_po and q_det:
            po_pono   = find_column_ci(cursor, sch_po, nm_po, ["pono", "PONo", "PONO", "PoNo"])
            po_date   = find_column_ci(cursor, sch_po, nm_po, ["podate", "PODate", "PO_Date", "po_date"])
            po_del    = find_column_ci(cursor, sch_po, nm_po, ["deleted", "Deleted", "IsDeleted"])
            po_dtype  = find_column_ci(cursor, sch_po, nm_po, ["dtype", "DType", "POType", "potype", "Type"])

            det_pono  = find_column_ci(cursor, sch_det, nm_det, ["pono", "PONo", "PONO", "PoNo"])
            det_del   = find_column_ci(cursor, sch_det, nm_det, ["deleted", "Deleted", "IsDeleted"])
            det_rm    = find_column_ci(cursor, sch_det, nm_det, ["rmname", "RMName", "RMNAME", "RmName"])
            det_qty   = find_column_ci(cursor, sch_det, nm_det, ["qty", "Qty", "QTY", "OrdQty"])
            det_rate  = find_column_ci(cursor, sch_det, nm_det, ["rate", "Rate", "RATE"])

            name_expr, use_alias = _supplier_name_expr(cursor)
            join_sql = _supplier_join_sql(use_alias)

            # Supplier filters
            join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "m", join_if_needed=True)
            srch_sql, srch_params = _build_po_search_sql(request, cursor, "m")

            del_po_sql  = f"ISNULL(m.[{po_del}], 0) = 0" if po_del else "1=1"
            del_det_sql = f"ISNULL(pd.[{det_del}], 0) = 0" if det_del else "1=1"

            dtype_clause = ""
            dtype_params = []
            if apply_dtype and po_dtype:
                dtype_clause = f" AND LTRIM(RTRIM(ISNULL(m.[{po_dtype}], ''))) = ?"
                dtype_params.append(dtype_param)
            elif po_dtype:
                dtype_clause = f" AND UPPER(LTRIM(RTRIM(ISNULL(m.[{po_dtype}], '')))) <> 'JOB ORDER'"

            today = date.today()

            sql = f"""
                SELECT
                    m.[{po_pono}] AS pono,
                    {name_expr} AS supplier_name,
                    pd.[{det_rm}] AS item_name,
                    ISNULL(CAST(pd.[{det_qty}] AS FLOAT), 0) AS ord_qty,
                    ISNULL(pd.[{det_rate}], 0) AS rate,
                    ISNULL(gs.grn_qty, 0) AS rcv_qty,
                    CAST(m.[{po_date}] AS DATE) AS po_date
                 FROM {q_po} m
                {join_sql}
                {join_flt}
                LEFT JOIN {q_det} pd ON pd.[{det_pono}] = m.[{po_pono}] AND {del_det_sql}
                LEFT JOIN (
                    SELECT gs2.pono, gs2.rmname AS icode,
                           SUM(CAST(gs2.qty AS FLOAT)) AS grn_qty
                    FROM grninsubdet gs2
                    INNER JOIN grn_mas gm2 ON gs2.grnno = gm2.grnno
                    WHERE ISNULL(gs2.deleted, 0) = 0
                      AND ISNULL(gm2.deleted, 0) = 0
                    GROUP BY gs2.pono, gs2.rmname
                ) gs ON gs.pono = m.[{po_pono}] AND gs.icode = pd.[{det_rm}]
                WHERE {del_po_sql}
                  {dtype_clause}
                  {where_flt}
                  {srch_sql}
                  AND CAST(m.[{po_date}] AS DATE) BETWEEN ? AND ?
            """

            exec_params = dtype_params + params_flt + srch_params + [start_date, end_date]
            cursor.execute(sql, exec_params)
            rows = cursor.fetchall()

            item_rates = {}
            high_alerts = []
            medium_alerts = []

            for pono, sup, item, o_qty, rate, r_qty, po_dt in rows:
                if not item: continue
                pono_str = str(pono or "").strip()
                sup_str = str(sup or "").strip() or "Unknown Supplier"
                item_str = str(item or "").strip()
                ord_qty = float(o_qty or 0)
                rcv_qty = float(r_qty or 0)
                rate_val = float(rate or 0)
                pending_qty = max(0.0, ord_qty - rcv_qty)
                pending_val = pending_qty * rate_val

                item_rates.setdefault(item_str, []).append((rate_val, sup_str))

                if pending_qty > 0:
                    days_open = 0
                    if po_dt:
                        try:
                            if hasattr(po_dt, "date"):
                                po_dt_obj = po_dt.date()
                            elif isinstance(po_dt, date):
                                po_dt_obj = po_dt
                            else:
                                po_dt_obj = datetime.strptime(str(po_dt)[:10], "%Y-%m-%d").date()
                            days_open = (today - po_dt_obj).days
                        except Exception:
                            pass

                    if days_open > 14:
                        high_alerts.append({
                            "icon": "🔴",
                            "title": f"{item_str} — {int(pending_qty):,} Nos undelivered",
                            "sub": f"PO {pono_str} · {sup_str} · Production impact risk",
                            "time": f"{days_open}d overdue",
                            "urgency": "high",
                            "pending_val": pending_val,
                            "pending_qty": pending_qty,
                            "uom": "Nos",
                            "supplier": sup_str,
                            "item": item_str,
                            "rate": rate_val
                        })
                    elif pending_val > 50000:
                        medium_alerts.append({
                            "icon": "🟠",
                            "title": f"{item_str} balance pending",
                            "sub": f"PO {pono_str} · {sup_str} · ₹{_fmt_rupees(pending_val)} balance to receive",
                            "time": f"{days_open}d open",
                            "urgency": "medium"
                        })

            info_alerts = []
            for item, rates_info in item_rates.items():
                if len(rates_info) > 1:
                    rates = [r[0] for r in rates_info]
                    avg_rate = sum(rates) / len(rates)
                    max_rate = max(rates)
                    if max_rate > 1.03 * avg_rate and avg_rate > 0:
                        max_sup = [r[1] for r in rates_info if r[0] == max_rate][0]
                        pct_diff = round(((max_rate - avg_rate) / avg_rate) * 100.0, 1)
                        info_alerts.append({
                            "icon": "🔵",
                            "title": f"{max_sup} rate variance — approval needed",
                            "sub": f"{item} · ₹{max_rate:,.2f} vs avg ₹{avg_rate:,.2f} (+{pct_diff}%)",
                            "time": "Auto-flag",
                            "urgency": "info"
                        })

            alerts_list = []
            alerts_list.extend(high_alerts[:2])
            alerts_list.extend(medium_alerts[:2])
            alerts_list.extend(info_alerts[:2])
            alerts_list = alerts_list[:4]

            if high_alerts:
                most_critical = max(high_alerts, key=lambda a: a["pending_val"])
                key_action = f"Follow up with {most_critical['supplier']} for {most_critical['item']} pending lot ({int(most_critical['pending_qty']):,} {most_critical['uom']}). Production scheduling depends on receipt. Also review rate change to ₹{most_critical['rate']:,.2f} for formal approval."

        if cursor: cursor.close()
        conn.close()

    except Exception as e:
        if cursor: cursor.close()
        try: conn.close()
        except: pass

    if not alerts_list:
        alerts_list = [
            { "icon": "🔴", "title": "Round Rod DIA 65MM — 325 Nos undelivered", "sub": "P251570 · Musk Metals · Production impact risk", "time": "7d overdue", "urgency": "high" },
            { "icon": "🟠", "title": "Bottom Bearing GRN balance pending", "sub": "P251574 · Ammarun Foundries · ₹8.2L balance to receive", "time": "3d open", "urgency": "medium" },
            { "icon": "🟡", "title": 'VCI Cover 8"×8" — DC not confirmed in system', "sub": "P251569 · Sri Vinayaga Enterprises · DC update pending", "time": "Today", "urgency": "low" },
            { "icon": "🔵", "title": "Musk Metals rate variance — approval needed", "sub": "₹92/kg vs last PO ₹88/kg (+4.5%) — review and approve", "time": "Auto-flag", "urgency": "info" },
        ]
        key_action = "Follow up with Musk Metals for DIA 65MM pending lot (325 Nos). Production scheduling depends on receipt by 05-Mar-2026. Also review rate increase ₹88→₹92/kg for formal approval."

    return Response({
        "alerts": alerts_list,
        "key_action": key_action
    }, status=200)


def _fmt_rupees(val):
    if val >= 100000:
        return f"{val/100000:.2f}L"
    return f"{val:,.2f}"


@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_traceability_table(request):
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e)}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    cursor = None
    try:
        cursor = conn.cursor()
        
        # 1. Resolve ERP tables
        sch_m, nm_m, q_m = resolve_erp_table(cursor, ["POMas", "pomas"])
        sch_d, nm_d, q_d = resolve_erp_table(cursor, ["PODet", "podet"])
        sch_cm, nm_cm, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast"])
        sch_ind, nm_ind, q_ind = resolve_erp_table(cursor, ["PO_InSubIndDet", "po_insubinddet"])
        sch_pim, nm_pim, q_pim = resolve_erp_table(cursor, ["POInd_Mas", "poind_mas"])
        sch_gx, nm_gx, q_gx = resolve_erp_table(cursor, ["grninsubdet", "grninsubdet"])
        sch_gm, nm_gm, q_gm = resolve_erp_table(cursor, ["grn_mas", "grn_mas"])
        sch_gd, nm_gd, q_gd = resolve_erp_table(cursor, ["grn_det", "grn_det"])
        sch_grd, nm_grd, q_grd = resolve_erp_table(cursor, ["Grn_RateDet", "grn_ratedet"])
        sch_am, nm_am, q_am = resolve_erp_table(cursor, ["POAmndMas", "poamndmas"])
        
        # 2. Resolve columns for POMas
        po_pono = find_column_ci(cursor, sch_m, nm_m, ["pono", "Pono", "PONO"])
        po_podate = find_column_ci(cursor, sch_m, nm_m, ["podate", "Podate", "PODATE"])
        po_cid = find_column_ci(cursor, sch_m, nm_m, ["cid", "Cid", "CID"])
        po_dtype = find_column_ci(cursor, sch_m, nm_m, ["dtype", "Dtype", "DTYPE"])
        po_approved = find_column_ci(cursor, sch_m, nm_m, ["IsApprovePo", "isapprovepo", "isapproved", "approved"])
        po_del = find_column_ci(cursor, sch_m, nm_m, ["deleted", "Deleted"])
        
        # 3. Resolve columns for PODet
        det_pono = find_column_ci(cursor, sch_d, nm_d, ["pono", "Pono", "PONO"])
        det_del = find_column_ci(cursor, sch_d, nm_d, ["deleted", "Deleted"])
        det_rmname = find_column_ci(cursor, sch_d, nm_d, ["rmname", "Rmname", "RMNAME"])
        det_mattype = find_column_ci(cursor, sch_d, nm_d, ["mattype", "Mattype", "MATTYPE"])
        det_qty = find_column_ci(cursor, sch_d, nm_d, ["qty", "Qty", "QTY"])
        det_uom = find_column_ci(cursor, sch_d, nm_d, ["uom", "Uom", "UOM"])
        det_rate = find_column_ci(cursor, sch_d, nm_d, ["rate", "Rate", "RATE"])
        det_amount = find_column_ci(cursor, sch_d, nm_d, ["amount", "Amount", "AMOUNT"])
        
        # 4. Resolve columns for CustMast
        cm_id = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "cid"])
        cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME"])
        cm_del = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted"])
        
        # 5. Resolve columns for PO_InSubIndDet
        ind_pono = find_column_ci(cursor, sch_ind, nm_ind, ["pono", "Pono"])
        ind_pino = find_column_ci(cursor, sch_ind, nm_ind, ["pino", "Pino"])
        ind_del = find_column_ci(cursor, sch_ind, nm_ind, ["deleted", "Deleted"])
        
        # 6. Resolve columns for POInd_Mas
        pim_pino = find_column_ci(cursor, sch_pim, nm_pim, ["pino", "Pino"])
        pim_date = find_column_ci(cursor, sch_pim, nm_pim, ["pidate", "Pidate", "PIDATE"])
        pim_del = find_column_ci(cursor, sch_pim, nm_pim, ["deleted", "Deleted"])
        
        # 7. Resolve columns for grninsubdet
        gx_pono = find_column_ci(cursor, sch_gx, nm_gx, ["pono", "Pono"])
        gx_grnno = find_column_ci(cursor, sch_gx, nm_gx, ["grnno", "Grnno"])
        gx_del = find_column_ci(cursor, sch_gx, nm_gx, ["deleted", "Deleted"])
        
        # 8. Resolve columns for grn_mas
        gm_grnno = find_column_ci(cursor, sch_gm, nm_gm, ["grnno", "Grnno"])
        gm_date = find_column_ci(cursor, sch_gm, nm_gm, ["grndate", "Grndate"])
        gm_del = find_column_ci(cursor, sch_gm, nm_gm, ["deleted", "Deleted"])
        
        # 9. Resolve columns for grn_det
        gd_grnno = find_column_ci(cursor, sch_gd, nm_gd, ["grnno", "Grnno"])
        gd_partno = find_column_ci(cursor, sch_gd, nm_gd, ["partno", "Partno"])
        gd_desc = find_column_ci(cursor, sch_gd, nm_gd, ["description", "Description"])
        gd_uom = find_column_ci(cursor, sch_gd, nm_gd, ["uom", "Uom"])
        gd_qty = find_column_ci(cursor, sch_gd, nm_gd, ["qty", "Qty"])
        gd_pono = find_column_ci(cursor, sch_gd, nm_gd, ["pono", "Pono"])
        gd_del = find_column_ci(cursor, sch_gd, nm_gd, ["deleted", "Deleted"])
        
        # 10. Resolve columns for Grn_RateDet
        grd_grnno = find_column_ci(cursor, sch_grd, nm_grd, ["grnno", "Grnno"])
        grd_partno = find_column_ci(cursor, sch_grd, nm_grd, ["partno", "Partno"])
        grd_rate = find_column_ci(cursor, sch_grd, nm_grd, ["Rate", "rate"])
        grd_amount = find_column_ci(cursor, sch_grd, nm_grd, ["Amount", "amount"])
        grd_del = find_column_ci(cursor, sch_grd, nm_grd, ["deleted", "Deleted"])
        
        # 11. Resolve columns for POAmndMas
        am_mpo = find_column_ci(cursor, sch_am, nm_am, ["Manualpono", "manualpono", "pono"])
        am_del = find_column_ci(cursor, sch_am, nm_am, ["deleted", "Deleted"])

        # Compile SQL clauses
        del_po_sql = f"ISNULL(M.[{po_del}], 0) = 0" if po_del else "1=1"
        del_det_sql = f"AND ISNULL(D.[{det_del}], 0) = 0" if det_del else ""
        del_cm_sql = f"AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
        del_ind_sql = f"ISNULL(PIS.[{ind_del}], 0) = 0" if ind_del else "1=1"
        del_pim_sql = f"AND ISNULL(PIM.[{pim_del}], 0) = 0" if pim_del else ""
        del_gx_sql = f"ISNULL(GX.[{gx_del}], 0) = 0" if gx_del else "1=1"
        del_gm_sql = f"AND ISNULL(GM.[{gm_del}], 0) = 0" if gm_del else ""
        del_gd_sql = f"AND ISNULL(GD.[{gd_del}], 0) = 0" if gd_del else ""
        del_grd_sql = f"AND ISNULL(GRD.[{grd_del}], 0) = 0" if grd_del else ""
        del_am_sql = f"AND ISNULL(AM.[{am_del}], 0) = 0" if am_del else ""
        
        # Approve expression
        app_expr = f"CASE WHEN ISNULL(M.[{po_approved}], 0) = 1 THEN 'Y' ELSE 'N' END" if po_approved else "'N'"
        
        # Supplier filtering
        join_flt, where_flt, params_flt = _supplier_filter_sql(request, cursor, "M", join_if_needed=True)
        srch_sql, srch_params = _build_po_search_sql(request, cursor, "M")

        # Dtype logic
        dtype_clause = ""
        dtype_params = []
        if apply_dtype:
            dtype_clause = f"AND LTRIM(RTRIM(ISNULL(M.[{po_dtype}], ''))) = ?"
            dtype_params.append(dtype_param)
        else:
            dtype_clause = f"AND UPPER(LTRIM(RTRIM(ISNULL(M.[{po_dtype}], '')))) <> 'JOB ORDER'"

        # Build SQL Query dynamically with resolved tables and columns
        query = f"""
            SELECT TOP 3000
                IND.pino AS Ind_No,
                PIM.[{pim_date}] AS Ind_Date,
                M.[{po_pono}] AS PO_Number,
                M.[{po_podate}] AS PO_Date,
                M.[{po_dtype}] AS PO_Type,
                CM.[{cm_name}] AS Vendor_Name,
                CAST(ISNULL(D.[{det_rmname}], '') AS NVARCHAR(256)) AS Material_Code,
                CAST(
                    ISNULL(CAST(D.[{det_rmname}] AS NVARCHAR(256)), N'')
                    + CASE
                        WHEN ISNULL(LTRIM(RTRIM(D.[{det_mattype}])), '') <> ''
                        THEN N' - ' + CAST(D.[{det_mattype}] AS NVARCHAR(256))
                        ELSE N''
                      END
                    AS NVARCHAR(520)
                ) AS Material,
                CAST(
                    CAST(ROUND(ISNULL(D.[{det_qty}], 0), 2) AS NVARCHAR(50))
                    + N' '
                    + ISNULL(CAST(D.[{det_uom}] AS NVARCHAR(32)), N'')
                    AS NVARCHAR(120)
                ) AS PO_Qty,
                ISNULL(D.[{det_rate}], 0) AS Rate,
                ISNULL(D.[{det_amount}], 0) AS Value,
                {app_expr} AS Approved,
                CAST(G.grnno_g AS NVARCHAR(64)) AS GRN_No,
                GM.[{gm_date}] AS GRN_Date,
                CAST(
                    ISNULL(CAST(GD.[{gd_partno}] AS NVARCHAR(256)), N'')
                    + CASE
                        WHEN ISNULL(LTRIM(RTRIM(GD.[{gd_desc}])), '') <> ''
                        THEN N' - ' + CAST(GD.[{gd_desc}] AS NVARCHAR(500))
                        ELSE N''
                      END
                    AS NVARCHAR(760)
                ) AS GRN_Material,
                CASE
                    WHEN UPPER(LTRIM(RTRIM(ISNULL(GD.[{gd_uom}], '')))) = 'NOS'
                    THEN CAST(ISNULL(GD.[{gd_qty}], 0) AS NVARCHAR(50))
                    ELSE ISNULL(CAST(GD.[{gd_pono}] AS NVARCHAR(50)), N'')
                END AS GRN_Qty,
                ISNULL(GRD.[{grd_rate}], 0) AS GRN_Rate,
                ISNULL(GRD.[{grd_amount}], 0) AS GRN_Amount,
                CASE
                    WHEN EXISTS (
                        SELECT 1
                        FROM {q_am} AM
                        WHERE LTRIM(RTRIM(AM.[{am_mpo}])) = LTRIM(RTRIM(M.[{po_pono}]))
                          {del_am_sql}
                    )
                    THEN 'Y'
                    ELSE 'N'
                END AS Amnd
            FROM {q_m} M
            INNER JOIN {q_d} D ON LTRIM(RTRIM(M.[{po_pono}])) = LTRIM(RTRIM(D.[{det_pono}])) {del_det_sql}
            LEFT JOIN {q_cm} CM ON M.[{po_cid}] = CM.[{cm_id}] {del_cm_sql}
            LEFT JOIN (
                SELECT DISTINCT
                    LTRIM(RTRIM(PIS.[{ind_pono}])) AS pono,
                    LTRIM(RTRIM(PIS.[{ind_pino}])) AS pino
                FROM {q_ind} PIS
                WHERE {del_ind_sql}
                  AND ISNULL(LTRIM(RTRIM(PIS.[{ind_pono}])), '') <> ''
                  AND ISNULL(LTRIM(RTRIM(PIS.[{ind_pino}])), '') <> ''
            ) IND ON LTRIM(RTRIM(M.[{po_pono}])) = IND.pono
            LEFT JOIN {q_pim} PIM ON LTRIM(RTRIM(IND.pino)) = LTRIM(RTRIM(PIM.[{pim_pino}])) {del_pim_sql}
            LEFT JOIN (
                SELECT
                    LTRIM(RTRIM(GX.[{gx_pono}])) AS pono_g,
                    MAX(GX.[{gx_grnno}]) AS grnno_g
                FROM {q_gx} GX
                WHERE {del_gx_sql}
                GROUP BY LTRIM(RTRIM(GX.[{gx_pono}]))
            ) G ON LTRIM(RTRIM(M.[{po_pono}])) = G.pono_g
            LEFT JOIN {q_gm} GM ON LTRIM(RTRIM(G.grnno_g)) = LTRIM(RTRIM(GM.[{gm_grnno}])) {del_gm_sql}
            LEFT JOIN {q_gd} GD ON LTRIM(RTRIM(G.grnno_g)) = LTRIM(RTRIM(GD.[{gd_grnno}]))
                               AND LTRIM(RTRIM(D.[{det_rmname}])) = LTRIM(RTRIM(GD.[{gd_partno}]))
                               {del_gd_sql}
            LEFT JOIN {q_grd} GRD ON LTRIM(RTRIM(G.grnno_g)) = LTRIM(RTRIM(GRD.[{grd_grnno}]))
                                 AND LTRIM(RTRIM(GD.[{gd_partno}])) = LTRIM(RTRIM(GRD.[{grd_partno}]))
                                 {del_grd_sql}
            {join_flt}
            WHERE {del_po_sql}
              {dtype_clause}
              {where_flt}
              {srch_sql}
              AND CAST(M.[{po_podate}] AS DATE) BETWEEN ? AND ?
            ORDER BY M.[{po_podate}], M.[{po_pono}]
        """

        cursor.execute(query, tuple(dtype_params + params_flt + srch_params + [start_date, end_date]))
        
        rows_out = []
        for idx, row in enumerate(cursor.fetchall()):
            ind_no, ind_dt, po_no, po_dt, po_type, vend_name, mat_code, material, po_qty, rate, val, app, grn_no, grn_dt, grn_material, grn_qty, grn_rate, grn_amount, amnd = row
            rows_out.append({
                "sno": idx + 1,
                "indNo": ind_no or "–",
                "indDt": ind_dt.strftime("%d-%b-%Y") if ind_dt else "–",
                "indPoNo": po_no or "–",
                "poDt": po_dt.strftime("%d-%b-%Y") if po_dt else "–",
                "poType": po_type or "–",
                "supplierName": vend_name or "–",
                "material": material or "–",
                "poQty": po_qty or "–",
                "poRate": f"{rate:,.2f}" if rate else "0.00",
                "poValue": val or 0,
                "approvedStatus": app or "N",
                "grnNo": grn_no or "–",
                "grnDt": grn_dt.strftime("%d-%b-%Y") if grn_dt else "–",
                "grnMaterial": grn_material or "–",
                "grnOky": grn_qty or "–",
                "grnRate": f"{grn_rate:,.2f}" if grn_rate else "0.00",
                "grnValue": grn_amount or 0,
                "amnd": amnd or "N"
            })
            
        return Response({"rows": rows_out}, status=200)

    except Exception as e:
        return Response({"error": f"Database error: {str(e)}"}, status=500)
    finally:
        if cursor: cursor.close()
        try: conn.close()
        except: pass


# ─────────────────────────────────────────────────────────────
#  ENDPOINT — Purchase Analysis Supplier Rating
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_supplier_rating(request):
    """
    Purchase Analysis — Supplier Rating score calculation per supplier
    using the Plant Performance supplier rating CTE logic (QualityRating + DeliveryRating).
    Delegates to supplier_rating_monthwise in views.py.
    """
    from .views import supplier_rating_monthwise
    req_to_pass = getattr(request, "_request", request)
    return supplier_rating_monthwise(req_to_pass)


# ────────────────────────────────────────────────────────────
#  ENDPOINT 16 — PO Fulfillment Schedule Table & Analytics
# ────────────────────────────────────────────────────────────

@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_fulfillment_schedule(request):
    """
    Returns PO Fulfillment Schedule rows as per the exact PO_DATA + SCH_DATA + GRN_DATA CTE query.
    Matches PO Details (POMas + PODet) with Schedule (iss_podet_ShdQty) and GRN (grninsubdet).
    Supports date range (from, to), dtype (PO type), supplier filter, and search.
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e), "rows": []}, status=401)

    start_date, end_date = parse_date_range(request)
    dtype_param = (request.GET.get("dtype") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"

    company_code = tenant.get("company_code")
    company_candidates = ["company_code", "CompanyCode", "compcode", "CompCode", "ccode", "CCode"]

    cursor = None
    try:
        cursor = conn.cursor()

        sch_m, nm_m, q_m   = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        sch_d, nm_d, q_d   = resolve_erp_table(cursor, ["PODet", "podet", "PODET", "PoDet", "In_PoDet"])
        sch_sd, nm_sd, q_sd = resolve_erp_table(cursor, ["iss_podet_ShdQty", "iss_podet_shdqty", "ISS_PODET_SHDQTY", "Iss_Podet_ShdQty", "podet_shdqty", "PODet_ShdQty", "PODet_Shd", "iss_podet_shd"])
        sch_gx, nm_gx, q_gx = resolve_erp_table(cursor, ["grninsubdet", "GRNInSubDet", "GrnInSubDet", "GRNINSUBDET"])
        sch_cm, nm_cm, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST", "CustMast"])

        if not q_m or not q_d:
            if cursor: cursor.close()
            conn.close()
            return Response({"company": tenant.get("company_name", ""), "from": str(start_date), "to": str(end_date), "rows": [], "count": 0}, status=200)

        # 1. Resolve columns for POMas
        po_pono   = find_column_ci(cursor, sch_m, nm_m, ["pono", "PONo", "PONO", "PoNo", "PONumber"])
        po_podate = find_column_ci(cursor, sch_m, nm_m, ["podate", "PODate", "PO_Date", "po_date", "PODt"])
        po_cid    = find_column_ci(cursor, sch_m, nm_m, ["cid", "CId", "CID", "CustId", "custid"])
        po_dtype  = find_column_ci(cursor, sch_m, nm_m, ["dtype", "DType", "POType", "potype", "Type"])
        po_del    = find_column_ci(cursor, sch_m, nm_m, ["deleted", "Deleted", "IsDeleted"])
        po_cc     = find_column_ci(cursor, sch_m, nm_m, company_candidates)

        # 2. Resolve columns for PODet
        det_pono   = find_column_ci(cursor, sch_d, nm_d, ["pono", "PONo", "PONO", "PoNo", "po_no"])
        det_rmname = find_column_ci(cursor, sch_d, nm_d, ["rmname", "RMName", "RMNAME", "RmName", "ItemName", "itemname", "description", "Description", "icode", "ICode"])
        det_itcode = find_column_ci(cursor, sch_d, nm_d, ["itcode", "ITCode", "ITCODE", "Itcode", "mattype", "Mattype", "matcode", "MatCode", "partno", "PartNo"])
        det_icode  = find_column_ci(cursor, sch_d, nm_d, ["icode", "ICode", "ICODE", "ItemCode", "itemcode", "matcode", "MatCode"])
        det_qty    = find_column_ci(cursor, sch_d, nm_d, ["qty", "Qty", "QTY", "Quantity", "quantity", "poqty", "POQty"])
        det_amount = find_column_ci(cursor, sch_d, nm_d, ["amount", "Amount", "AMOUNT", "Amt", "amt", "Value", "val"])
        det_rate   = find_column_ci(cursor, sch_d, nm_d, ["rate", "Rate", "RATE", "Price", "price", "unit_rate"])
        det_del    = find_column_ci(cursor, sch_d, nm_d, ["deleted", "Deleted", "IsDeleted", "isdeleted"])

        # 3. Resolve columns for iss_podet_ShdQty
        sd_pono   = find_column_ci(cursor, sch_sd, nm_sd, ["pono", "PONo", "PONO", "PoNo", "po_no", "PONumber"]) if q_sd else None
        sd_icode  = find_column_ci(cursor, sch_sd, nm_sd, ["icode", "ICode", "ICODE", "rmname", "Rmname", "ItemName", "ItemCode", "matcode"]) if q_sd else None
        sd_itcode = find_column_ci(cursor, sch_sd, nm_sd, ["itcode", "ITCode", "ITCODE", "Itcode", "mattype", "Mattype", "partno", "Partno", "PartNo", "rmcode", "matcode"]) if q_sd else None
        sd_shddt  = find_column_ci(cursor, sch_sd, nm_sd, ["shddate", "Shddate", "SHDDATE", "shd_date", "schddate", "SchdDate", "deliverydate", "DeliveryDate", "deldate", "DelDate"]) if q_sd else None
        sd_shdqty = find_column_ci(cursor, sch_sd, nm_sd, ["shdQty", "shdqty", "SHDQTY", "ShdQty", "schd_qty", "qty", "Qty", "QTY", "Quantity", "quantity"]) if q_sd else None
        sd_del    = find_column_ci(cursor, sch_sd, nm_sd, ["deleted", "Deleted", "IsDeleted", "isdeleted"]) if q_sd else None

        # 4. Resolve columns for grninsubdet
        gx_pono   = find_column_ci(cursor, sch_gx, nm_gx, ["pono", "PONo", "PONO", "PoNo", "po_no"]) if q_gx else None
        gx_rmname = find_column_ci(cursor, sch_gx, nm_gx, ["rmname", "RMName", "RMNAME", "RmName", "ItemName", "itemname", "description", "Description", "icode", "ICode"]) if q_gx else None
        gx_qty    = find_column_ci(cursor, sch_gx, nm_gx, ["qty", "Qty", "QTY", "Quantity", "quantity", "recqty", "RecQty", "AcceptedQty", "accqty", "acpqty"]) if q_gx else None
        gx_del    = find_column_ci(cursor, sch_gx, nm_gx, ["deleted", "Deleted", "IsDeleted", "isdeleted"]) if q_gx else None

        # 5. Resolve columns for CustMast / CustAliasMast
        cm_id   = find_column_ci(cursor, sch_cm, nm_cm, ["Id", "id", "ID", "CustId", "custid"]) if q_cm else None
        cm_name = find_column_ci(cursor, sch_cm, nm_cm, ["CName", "cname", "CNAME", "CustName", "Name"]) if q_cm else None
        cm_del  = find_column_ci(cursor, sch_cm, nm_cm, ["deleted", "Deleted", "IsDeleted"]) if q_cm else None

        if not po_pono or not po_podate or not det_pono or not det_rmname:
            if cursor: cursor.close()
            conn.close()
            return Response({"error": "Required PO/PODet columns not found.", "rows": []}, status=500)

        # ── Filters for PO_DATA CTE ────────────────────────────────
        del_pm_sql = f"AND ISNULL(PM.[{po_del}], 0) = 0" if po_del else ""
        del_pd_sql = f"AND ISNULL(PD.[{det_del}], 0) = 0" if det_del else ""
        sd_del_clause = f"AND ISNULL([{sd_del}], 0) = 0" if sd_del else ""
        gx_del_clause = f"WHERE ISNULL([{gx_del}], 0) = 0" if gx_del else ""

        exclude_filter = ""
        if po_dtype:
            exclude_filter = f" AND UPPER(LTRIM(RTRIM(ISNULL(PM.[{po_dtype}], N'')))) <> N'JOB ORDER'"

        dtype_filter_sql = ""
        dtype_params = []
        if apply_dtype and po_dtype:
            dtype_filter_sql = f" AND LTRIM(RTRIM(ISNULL(PM.[{po_dtype}], N''))) = ?"
            dtype_params.append(dtype_param)

        company_sql = ""
        if po_cc and company_code:
            company_sql = f" AND PM.[{po_cc}] = ?"

        sd_itcode_col = f"MAX(LTRIM(RTRIM(ISNULL([{sd_itcode}], N''))))" if sd_itcode else "CAST(N'' AS NVARCHAR(256))"
        det_itcode_col = f"MAX(LTRIM(RTRIM(ISNULL(PD.[{det_itcode}], N''))))" if det_itcode else "CAST(N'' AS NVARCHAR(256))"
        det_icode_col = f"MAX(LTRIM(RTRIM(ISNULL(PD.[{det_icode}], N''))))" if det_icode else "CAST(N'' AS NVARCHAR(256))"
        branch2_itcode_match = f"OR (SD.itcode <> N'' AND LTRIM(RTRIM(ISNULL(PD.[{det_itcode}], N''))) <> N'' AND LTRIM(RTRIM(ISNULL(PD.[{det_itcode}], N''))) = SD.itcode)" if det_itcode else ""

        # ── SCH_DATA CTE ───────────────────────────────────────────
        if q_sd and sd_pono and sd_icode and sd_shddt and sd_shdqty:
            sch_data_cte = f"""
                SELECT
                    [{sd_pono}] AS pono,
                    LTRIM(RTRIM(ISNULL([{sd_icode}], N''))) AS icode,
                    {sd_itcode_col} AS itcode,
                    CAST([{sd_shddt}] AS DATE) AS shddate,
                    SUM(ISNULL(CAST([{sd_shdqty}] AS FLOAT), 0)) AS SchdQty
                FROM {q_sd}
                WHERE [{sd_shddt}] IS NOT NULL
                  AND YEAR([{sd_shddt}]) >= 2000
                  {sd_del_clause}
                GROUP BY
                    [{sd_pono}],
                    LTRIM(RTRIM(ISNULL([{sd_icode}], N''))),
                    CAST([{sd_shddt}] AS DATE)
            """
        else:
            sch_data_cte = """
                SELECT
                    CAST(NULL AS NVARCHAR(64)) AS pono,
                    CAST(NULL AS NVARCHAR(256)) AS icode,
                    CAST(NULL AS NVARCHAR(256)) AS itcode,
                    CAST(NULL AS DATE) AS shddate,
                    CAST(0 AS FLOAT) AS SchdQty
                WHERE 1=0
            """

        # ── GRN_DATA CTE ───────────────────────────────────────────
        if q_gx and gx_pono and gx_rmname and gx_qty:
            grn_data_cte = f"""
                SELECT
                    [{gx_pono}] AS pono,
                    LTRIM(RTRIM(ISNULL([{gx_rmname}], N''))) AS rmname,
                    SUM(ISNULL(CAST([{gx_qty}] AS FLOAT), 0)) AS GRNQty
                FROM {q_gx}
                {gx_del_clause}
                GROUP BY
                    [{gx_pono}],
                    LTRIM(RTRIM(ISNULL([{gx_rmname}], N'')))
            """
        else:
            grn_data_cte = """
                SELECT
                    CAST(NULL AS NVARCHAR(64)) AS pono,
                    CAST(NULL AS NVARCHAR(256)) AS rmname,
                    CAST(0 AS FLOAT) AS GRNQty
                WHERE 1=0
            """

        # ── Supplier Name & CustMast Join ──────────────────────────
        cm_join = ""
        cm_name_sel = "CAST(NULL AS NVARCHAR(256))"
        if q_cm and cm_id and cm_name:
            del_cm_sql = f"AND ISNULL(CM.[{cm_del}], 0) = 0" if cm_del else ""
            has_alias = table_exists(cursor, "CustAliasMast")
            if has_alias:
                sch_cam, nm_cam, q_cam = resolve_erp_table(cursor, ["CustAliasMast", "custaliasmast"])
                cam_id = find_column_ci(cursor, sch_cam, nm_cam, ["Id", "id", "ID", "CustId"]) if q_cam else None
                cam_name = find_column_ci(cursor, sch_cam, nm_cam, ["CName", "cname", "CNAME"]) if q_cam else None
                cam_del = find_column_ci(cursor, sch_cam, nm_cam, ["deleted", "Deleted", "IsDeleted"]) if q_cam else None
                if cam_id and cam_name:
                    del_cam_sql = f"AND ISNULL(A.[{cam_del}], 0) = 0" if cam_del else ""
                    cm_join = f"""
                        LEFT JOIN {q_cm} CM ON CONVERT(NVARCHAR(128), C.cid) = CONVERT(NVARCHAR(128), CM.[{cm_id}]) {del_cm_sql}
                        LEFT JOIN {q_cam} A ON CONVERT(NVARCHAR(128), C.cid) = CONVERT(NVARCHAR(128), A.[{cam_id}]) {del_cam_sql}
                    """
                    cm_name_sel = f"LTRIM(RTRIM(ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(CM.[{cm_name}], N''))), N''), NULLIF(LTRIM(RTRIM(ISNULL(A.[{cam_name}], N''))), N''))))"
                else:
                    cm_join = f"""
                        LEFT JOIN {q_cm} CM ON CONVERT(NVARCHAR(128), C.cid) = CONVERT(NVARCHAR(128), CM.[{cm_id}]) {del_cm_sql}
                    """
                    cm_name_sel = f"LTRIM(RTRIM(ISNULL(CM.[{cm_name}], N'')))"
            else:
                cm_join = f"""
                    LEFT JOIN {q_cm} CM ON CONVERT(NVARCHAR(128), C.cid) = CONVERT(NVARCHAR(128), CM.[{cm_id}]) {del_cm_sql}
                """
                cm_name_sel = f"LTRIM(RTRIM(ISNULL(CM.[{cm_name}], N'')))"

        # ── Supplier Filter (request.GET) ──────────────────────────
        supplier_filter = (request.GET.get("supplier") or "").strip()
        supplier_where = ""
        supplier_params = []
        if supplier_filter and supplier_filter.lower() != "all suppliers":
            sups = [s.strip() for s in supplier_filter.split(",") if s.strip()]
            if sups:
                placeholders = ",".join(["?"] * len(sups))
                supplier_where = f" AND UPPER(LTRIM(RTRIM(ISNULL({cm_name_sel}, N'')))) IN ({placeholders}) "
                supplier_params.extend([s.upper() for s in sups])

        # ── Search Filter (request.GET) ────────────────────────────
        search_q = (request.GET.get("search") or request.GET.get("q") or "").strip()
        search_where = ""
        search_params = []
        if search_q:
            search_where = f" AND (C.pono LIKE ? OR C.rmname LIKE ? OR {cm_name_sel} LIKE ?) "
            like_val = f"%{search_q}%"
            search_params.extend([like_val, like_val, like_val])

        # ── Assemble Parameters & Full CTE Query ───────────────────
        s_date_str = str(start_date)
        e_date_str = str(end_date)

        params = []
        if apply_dtype and po_dtype:
            params.extend(dtype_params)
        params.extend([s_date_str, e_date_str])

        # For Set 2:
        params.extend([s_date_str, e_date_str])
        params.extend([s_date_str, e_date_str])

        params.extend(supplier_params)
        params.extend(search_params)

        query = f"""
            ;WITH ALL_PO_DATA AS
            (
                /* Set 1: All PO items created in date range */
                SELECT
                    PM.[{po_pono}]                 AS pono,
                    CAST(PM.[{po_podate}] AS DATE) AS podate,
                    PM.[{po_cid}]                  AS cid,
                    LTRIM(RTRIM(ISNULL(PD.[{det_rmname}], N''))) AS rmname,
                    {det_itcode_col}               AS itcode,
                    {det_icode_col}                AS icode,
                    SUM(ISNULL(CAST(PD.[{det_qty}] AS FLOAT), 0))    AS POQty,
                    SUM(ISNULL(CAST(PD.[{det_amount}] AS FLOAT), 0)) AS POValue,
                    MAX(ISNULL(CAST(PD.[{det_rate}] AS FLOAT), 0))   AS Rate
                FROM {q_m} PM
                INNER JOIN {q_d} PD
                    ON PM.[{po_pono}] = PD.[{det_pono}]
                    {del_pd_sql}
                WHERE 1=1
                  {del_pm_sql}
                  {exclude_filter}
                  {dtype_filter_sql}
                  AND CAST(PM.[{po_podate}] AS DATE) BETWEEN ? AND ?
                GROUP BY
                    PM.[{po_pono}],
                    CAST(PM.[{po_podate}] AS DATE),
                    PM.[{po_cid}],
                    LTRIM(RTRIM(ISNULL(PD.[{det_rmname}], N'')))
            ),
            SCH_DATA AS
            (
                /* PO SCHEDULE */
                {sch_data_cte}
            ),
            GRN_DATA AS
            (
                /* GRN / INWARD */
                {grn_data_cte}
            ),
            COMBINED_DATA AS
            (
                /* 1. All POs created in date range with all their schedules */
                SELECT
                    P.pono AS pono,
                    P.podate AS podate,
                    P.cid AS cid,
                    P.rmname AS rmname,
                    P.POQty AS POQty,
                    P.Rate AS Rate,
                    P.POValue AS POValue,
                    S.shddate AS shddate,
                    ISNULL(S.SchdQty, 0) AS SchdQty,
                    ISNULL(G.GRNQty, 0) AS GRNQty
                FROM ALL_PO_DATA P
                LEFT JOIN SCH_DATA S
                    ON P.pono = S.pono
                   AND (
                       P.rmname = S.icode
                       OR (S.itcode <> N'' AND P.itcode <> N'' AND P.itcode = S.itcode)
                       OR (S.icode <> N'' AND P.icode <> N'' AND P.icode = S.icode)
                       OR (S.itcode <> N'' AND P.rmname = S.itcode)
                   )
                LEFT JOIN GRN_DATA G
                    ON P.pono = G.pono
                   AND (
                       P.rmname = G.rmname
                       OR (S.icode <> N'' AND S.icode = G.rmname)
                       OR (S.itcode <> N'' AND S.itcode = G.rmname)
                   )

                UNION ALL

                /* 2. All Schedules scheduled in date range whose parent PO was NOT created in range */
                SELECT
                    SD.pono AS pono,
                    CAST(PM.[{po_podate}] AS DATE) AS podate,
                    PM.[{po_cid}] AS cid,
                    COALESCE(NULLIF(LTRIM(RTRIM(PD.[{det_rmname}])), N''), NULLIF(SD.icode, N''), NULLIF(SD.itcode, N''), N'Item') AS rmname,
                    ISNULL(CAST(PD.[{det_qty}] AS FLOAT), SD.SchdQty) AS POQty,
                    ISNULL(CAST(PD.[{det_rate}] AS FLOAT), 0) AS Rate,
                    ISNULL(CAST(PD.[{det_amount}] AS FLOAT), 0) AS POValue,
                    SD.shddate AS shddate,
                    SD.SchdQty AS SchdQty,
                    ISNULL(G.GRNQty, 0) AS GRNQty
                FROM SCH_DATA SD
                LEFT JOIN {q_m} PM
                    ON PM.[{po_pono}] = SD.pono
                    {del_pm_sql}
                    {exclude_filter}
                LEFT JOIN {q_d} PD
                    ON PM.[{po_pono}] = PD.[{det_pono}]
                   AND (
                       LTRIM(RTRIM(PD.[{det_rmname}])) = SD.icode
                       {branch2_itcode_match}
                       OR (SD.itcode <> N'' AND LTRIM(RTRIM(PD.[{det_rmname}])) = SD.itcode)
                   )
                   {del_pd_sql}
                LEFT JOIN GRN_DATA G
                    ON SD.pono = G.pono
                   AND (
                       SD.icode = G.rmname
                       OR (SD.itcode <> N'' AND SD.itcode = G.rmname)
                       OR (PD.[{det_rmname}] IS NOT NULL AND LTRIM(RTRIM(PD.[{det_rmname}])) = G.rmname)
                   )
                WHERE CAST(SD.shddate AS DATE) BETWEEN ? AND ?
                  AND (
                      PM.[{po_podate}] IS NULL
                      OR CAST(PM.[{po_podate}] AS DATE) NOT BETWEEN ? AND ?
                  )
            )
            SELECT
                /* # */
                ROW_NUMBER() OVER
                (
                    ORDER BY
                        C.podate,
                        C.pono,
                        C.rmname,
                        C.shddate
                ) AS [#],

                /* PO DETAILS */
                C.pono AS [PO NO],
                C.podate AS [PO DATE],
                {cm_name_sel} AS [SUPPLIER],
                C.rmname AS [PARTNO - DESC],
                C.POQty AS [PO QTY],

                /* SCHEDULE DETAILS */
                C.shddate AS [SCHD DT],
                ISNULL(C.SchdQty, 0) AS [SCHD QTY],

                /* GRN / INWARD */
                ISNULL(C.GRNQty, 0) AS [GRN QTY],

                /* BALANCE QTY */
                CASE
                    WHEN ISNULL(C.SchdQty, 0) - ISNULL(C.GRNQty, 0) < 0
                        THEN 0
                    ELSE
                        ISNULL(C.SchdQty, 0) - ISNULL(C.GRNQty, 0)
                END AS [SCHD / PO BAL QTY],

                /* BALANCE VALUE */
                CASE
                    WHEN ISNULL(C.SchdQty, 0) - ISNULL(C.GRNQty, 0) < 0
                        THEN 0
                    ELSE
                        (
                            ISNULL(C.SchdQty, 0)
                            - ISNULL(C.GRNQty, 0)
                        ) * ISNULL(C.Rate, 0)
                END AS [SCHD / PO BAL VAL],

                /* AGE DAYS */
                CASE
                    WHEN C.shddate IS NULL OR YEAR(C.shddate) < 2000
                        THEN 0
                    WHEN ISNULL(C.GRNQty, 0) >= ISNULL(C.SchdQty, 0)
                        THEN 0
                    WHEN C.shddate >= CAST(GETDATE() AS DATE)
                        THEN 0
                    ELSE
                        DATEDIFF
                        (
                            DAY,
                            C.shddate,
                            CAST(GETDATE() AS DATE)
                        )
                END AS [AGE DAYS],

                /* STATUS */
                CASE
                    WHEN C.shddate IS NULL OR YEAR(C.shddate) < 2000
                        THEN 'No Schedule'
                    WHEN ISNULL(C.GRNQty, 0) >= ISNULL(C.SchdQty, 0)
                        THEN 'Delivered'
                    WHEN C.shddate >= CAST(GETDATE() AS DATE)
                        THEN 'On Track'
                    WHEN DATEDIFF
                         (
                             DAY,
                             C.shddate,
                             CAST(GETDATE() AS DATE)
                         ) > 30
                        THEN 'Overdue'
                    WHEN DATEDIFF
                         (
                             DAY,
                             C.shddate,
                             CAST(GETDATE() AS DATE)
                         ) BETWEEN 15 AND 30
                        THEN 'Due Soon'
                    ELSE 'On Track'
                END AS [STATUS],

                C.Rate AS [Rate],
                C.POValue AS [POValue]

            FROM COMBINED_DATA C
            {cm_join}
            WHERE 1=1
              {supplier_where}
              {search_where}

            ORDER BY
                C.podate,
                C.pono,
                C.rmname,
                C.shddate;
        """

        logger.info(f"[FS LOG] executing query with {len(params)} params (query markers: {query.count('?')})")
        cursor.execute(query, params)
        raw_rows = []
        for r in cursor.fetchall() or []:
            sno, po_num, po_dt, sup, rmn, po_q, shd_dt, shd_q, grn_q, bal_q, bal_val, age_days, status_val, rate, po_val = r
            raw_rows.append({
                "sno": sno,
                "po_number": str(po_num or "").strip(),
                "po_date_obj": po_dt,
                "supplier": str(sup or "").strip() or "Unassigned",
                "rmname": str(rmn or "").strip(),
                "po_qty_num": float(po_q or 0),
                "schd_dt_obj": shd_dt,
                "schd_qty_num": float(shd_q or 0),
                "grn_qty_num": float(grn_q or 0),
                "bal_qty_num": float(bal_q or 0),
                "bal_val": float(bal_val or 0),
                "age_days": int(age_days or 0),
                "status": str(status_val or "On Track"),
                "rate": float(rate or 0),
                "po_value": float(po_val or 0),
            })
        logger.info(f"[FS LOG] fetched {len(raw_rows)} rows")

        cursor.close()
        conn.close()

    except Exception as e:
        logger.exception("Error in purchase_analysis_fulfillment_schedule: %s", e)
        print(f"[FULFILLMENT ERROR] {e}")
        if cursor:
            try: cursor.close()
            except Exception: pass
        try: conn.close()
        except Exception: pass
        return Response({"error": f"Database error: {str(e)}", "rows": []}, status=500)

    def _iso(d):
        if d is None:
            return ""
        if hasattr(d, "year") and d.year < 2000:
            return ""
        if hasattr(d, "isoformat"):
            return d.isoformat()[:10]
        s = str(d)[:10]
        if s.startswith("1900") or s.startswith("0000"):
            return ""
        return s

    rows_out = []
    for idx, r in enumerate(raw_rows):
        po_q = r["po_qty_num"]
        schd_q = r["schd_qty_num"]
        grn_q = r["grn_qty_num"]
        bal_q = r["bal_qty_num"]
        bal_val = round(r["bal_val"], 2)
        rate = round(r["rate"], 2)
        age_days = r["age_days"]
        status = r["status"]
        part_no = r["rmname"]

        rows_out.append({
            "id": f"{r['po_number']}-{part_no}-{idx + 1}",
            "sno": idx + 1,
            "po_number": r["po_number"],
            "po_date": _iso(r["po_date_obj"]),
            "supplier": r["supplier"],
            "part_no": part_no,
            "description": "",
            "po_qty": f"{po_q:g} NOS",
            "po_qty_num": po_q,
            "schd_dt": _iso(r["schd_dt_obj"]),
            "schd_qty": f"{schd_q:g} NOS",
            "schd_qty_num": schd_q,
            "grn_qty": f"{grn_q:g} NOS",
            "grn_qty_num": grn_q,
            "bal_qty": f"{bal_q:g} NOS",
            "bal_qty_num": bal_q,
            "bal_val": bal_val,
            "rate": rate,
            "uom": "NOS",
            "age_days": age_days,
            "status": status,
        })

    return Response({
        "company": tenant.get("company_name", ""),
        "from": str(start_date),
        "to": str(end_date),
        "count": len(rows_out),
        "rows": rows_out,
    })


@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_average_purchase_value(request):
    """
    Returns Average Purchase Value (APV) and line-item material classification data
    based on the exact CTE query:
    PO_BASE (POMas + PODet) -> ITEM_MASTER (WithMatMas + RawMast + RawProdMast) -> GRN_BASE (grninsubdet + grn_mas).
    """
    try:
        conn, tenant = get_tenant_connection(request)
    except ValueError as e:
        return Response({"error": str(e), "rows": []}, status=401)

    start_date, end_date = parse_date_range(request)

    dtype_param = (request.GET.get("dtype") or request.GET.get("po_type") or "").strip()
    apply_dtype = dtype_param and dtype_param.lower() != "all types"
    dtype_filter_sql = " AND UPPER(LTRIM(RTRIM(ISNULL(PM.dtype, '')))) = UPPER(?)" if apply_dtype else ""

    supplier_filter = (request.GET.get("supplier") or "").strip()
    supplier_where = ""
    supplier_params = []
    if supplier_filter and supplier_filter.lower() != "all suppliers":
        sups = [s.strip() for s in supplier_filter.split(",") if s.strip()]
        if sups:
            placeholders = ",".join(["?"] * len(sups))
            supplier_where = f" AND UPPER(LTRIM(RTRIM(ISNULL(CM.CName, '')))) IN ({placeholders}) "
            supplier_params.extend([s.upper() for s in sups])

    search_q = (request.GET.get("search") or request.GET.get("q") or "").strip()
    search_where = ""
    search_params = []
    if search_q:
        like_val = f"%{search_q}%"
        search_where = " AND (P.pono LIKE ? OR P.rmname LIKE ? OR CM.CName LIKE ? OR M.WMDescription LIKE ? OR M.RMDescription LIKE ? OR M.RPMDescription LIKE ?) "
        search_params.extend([like_val, like_val, like_val, like_val, like_val, like_val])

    cursor = None
    try:
        cursor = conn.cursor()

        sch_m, nm_m, q_m = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        sch_d, nm_d, q_d = resolve_erp_table(cursor, ["PODet", "podet", "PODET", "PoDet", "In_PoDet"])
        sch_wm, nm_wm, q_wm = resolve_erp_table(cursor, ["WithMatMas", "withmatmas", "WITHMATMAS", "WithMat_Mas"])
        sch_rm, nm_rm, q_rm = resolve_erp_table(cursor, ["RawMast", "rawmast", "RAWMAST", "Raw_Mast"])
        sch_rpm, nm_rpm, q_rpm = resolve_erp_table(cursor, ["RawProdMast", "rawprodmast", "RAWPRODMAST", "RawProd_Mast"])
        sch_cm, nm_cm, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST", "CustMast"])
        sch_gx, nm_gx, q_gx = resolve_erp_table(cursor, ["grninsubdet", "GRNInSubDet", "GrnInSubDet", "GRNINSUBDET"])
        sch_gm, nm_gm, q_gm = resolve_erp_table(cursor, ["grn_mas", "Grn_Mas", "GRN_MAS", "grnmas"])

        # Fallbacks to standard table names if resolution returned None
        tbl_m = q_m or "[dbo].[POMas]"
        tbl_d = q_d or "[dbo].[PODet]"
        tbl_wm = q_wm or "[dbo].[WithMatMas]"
        tbl_rm = q_rm or "[dbo].[RawMast]"
        tbl_rpm = q_rpm or "[dbo].[RawProdMast]"
        tbl_cm = q_cm or "[dbo].[CustMast]"
        tbl_gx = q_gx or "[dbo].[grninsubdet]"
        tbl_gm = q_gm or "[dbo].[grn_mas]"

        query = f"""
        ;WITH PO_BASE AS
        (
            SELECT
                PM.pono,
                PM.podate,
                PM.cid,
                PM.dtype,

                PD.rmname,
                PD.mattype,
                PD.qty,
                PD.QtyKgs,
                PD.QtyMtrsKgs,
                PD.rate,
                PD.uom,
                PD.amount,
                PD.deleted AS PODetDeleted

            FROM {tbl_m} PM

            INNER JOIN {tbl_d} PD
                ON PM.pono = PD.pono
               AND ISNULL(PD.deleted, 0) = 0

            WHERE ISNULL(PM.deleted, 0) = 0
              AND UPPER(LTRIM(RTRIM(ISNULL(PM.dtype, '')))) <> 'JOB ORDER'
              {dtype_filter_sql}
              AND CAST(PM.podate AS DATE) >= ?
              AND CAST(PM.podate AS DATE) < DATEADD(DAY, 1, CAST(? AS DATE))
        ),

        ITEM_MASTER AS
        (
            SELECT
                P.rmname,

                WM.PartNo AS WMPartNo,
                WM.Description AS WMDescription,
                WM.Rod,
                WM.Casting,
                WM.uom AS WMUom,

                RM.Codeno AS RMCodeNo,
                RM.Description AS RMDescription,
                RM.SGroup AS RMGroup,
                RM.Uom AS RMUom,

                RPM.Codeno AS RPMCodeNo,
                RPM.Description AS RPMDescription,
                RPM.SGroup AS RPMGroup,
                RPM.Uom AS RPMUom

            FROM
            (
                SELECT DISTINCT rmname
                FROM PO_BASE
            ) P

            LEFT JOIN {tbl_wm} WM
                ON LTRIM(RTRIM(P.rmname)) = LTRIM(RTRIM(WM.PartNo))
               AND ISNULL(WM.Deleted, 0) = 0

            LEFT JOIN {tbl_rm} RM
                ON LTRIM(RTRIM(P.rmname)) = LTRIM(RTRIM(RM.Codeno))
               AND ISNULL(RM.Deleted, 0) = 0

            LEFT JOIN {tbl_rpm} RPM
                ON LTRIM(RTRIM(P.rmname)) = LTRIM(RTRIM(RPM.Codeno))
               AND ISNULL(RPM.Deleted, 0) = 0
        ),

        GRN_BASE AS
        (
            SELECT
                G.pono,
                LTRIM(RTRIM(G.rmname)) AS rmname,
                MAX(G.grnno) AS grnno,
                MAX(GM.grndate) AS grndate,
                SUM(ISNULL(G.qty, 0)) AS grnqty
            FROM {tbl_gx} G
            LEFT JOIN {tbl_gm} GM ON G.grnno = GM.grnno AND ISNULL(GM.deleted, 0) = 0
            WHERE ISNULL(G.deleted, 0) = 0
            GROUP BY G.pono, LTRIM(RTRIM(G.rmname))
        )

        SELECT
            ROW_NUMBER() OVER
            (
                ORDER BY
                    P.podate,
                    P.pono,
                    P.rmname
            ) AS [SL NO],

            P.pono AS [PONO],
            P.podate AS [PODATE],
            P.rmname AS [PARTNO],

            COALESCE
            (
                M.WMDescription,
                M.RMDescription,
                M.RPMDescription,
                P.rmname
            ) AS [DESCRIPTION],

            P.qty AS [PO QTY],
            P.uom AS [UOM],

            CASE
                WHEN M.WMPartNo IS NOT NULL
                     AND ISNULL(M.Casting, 0) = 1
                    THEN 'Nos (Casting)'

                WHEN M.WMPartNo IS NOT NULL
                     AND ISNULL(M.Rod, 0) = 1
                     AND
                     (
                         UPPER(ISNULL(P.uom, '')) = 'KGS'
                         OR
                         UPPER(ISNULL(P.uom, '')) = 'KG'
                     )
                    THEN 'KGS (Rod)'

                WHEN M.WMPartNo IS NOT NULL
                     AND ISNULL(M.Rod, 0) = 1
                     AND
                     (
                         UPPER(ISNULL(P.uom, '')) = 'MTRS'
                         OR
                         UPPER(ISNULL(P.uom, '')) = 'MTR'
                         OR
                         UPPER(ISNULL(P.uom, '')) = 'M'
                     )
                    THEN 'Mtrs (Rod)'

                WHEN M.WMPartNo IS NOT NULL
                     AND ISNULL(M.Rod, 0) = 1
                    THEN 'Rod'

                WHEN M.RMCodeNo IS NOT NULL
                    THEN 'B.Out'

                WHEN M.RPMCodeNo IS NOT NULL
                    THEN 'Store Material'

                WHEN UPPER(LTRIM(RTRIM(ISNULL(P.dtype, '')))) LIKE '%RAW%'
                     AND UPPER(ISNULL(P.uom, '')) IN ('MTRS', 'MTR', 'M')
                    THEN 'Mtrs (Rod)'

                WHEN UPPER(LTRIM(RTRIM(ISNULL(P.dtype, '')))) LIKE '%RAW%'
                     AND UPPER(ISNULL(P.uom, '')) IN ('KGS', 'KG')
                    THEN 'KGS (Rod)'

                WHEN UPPER(LTRIM(RTRIM(ISNULL(P.dtype, '')))) LIKE '%RAW%'
                     AND UPPER(ISNULL(P.uom, '')) IN ('NOS', 'NO', 'PCS')
                    THEN 'Nos (Casting)'

                WHEN UPPER(LTRIM(RTRIM(ISNULL(P.dtype, '')))) LIKE '%STORE%'
                    THEN 'Store Material'

                ELSE 'Other'
            END AS [CATEGORY],

            P.rate AS [PO RATE],

            ISNULL
            (
                P.amount,
                ISNULL(P.qty, 0) * ISNULL(P.rate, 0)
            ) AS [AMT],

            CM.CName AS [SUPPLIER],

            CASE
                WHEN M.RPMCodeNo IS NOT NULL
                    THEN M.RPMGroup
                WHEN M.RMCodeNo IS NOT NULL
                    THEN M.RMGroup
                ELSE NULL
            END AS [GROUP NAME],

            CASE
                WHEN M.WMPartNo IS NOT NULL
                    THEN 'RAW MATERIAL'
                WHEN M.RMCodeNo IS NOT NULL
                    THEN 'B.OUT'
                WHEN M.RPMCodeNo IS NOT NULL
                    THEN 'STORE MATERIAL'
                WHEN UPPER(LTRIM(RTRIM(ISNULL(P.dtype, '')))) LIKE '%RAW%'
                    THEN 'RAW MATERIAL'
                WHEN UPPER(LTRIM(RTRIM(ISNULL(P.dtype, '')))) LIKE '%STORE%'
                    THEN 'STORE MATERIAL'
                ELSE 'RAW MATERIAL'
            END AS [MATERIAL TYPE],

            GB.grnno AS [GRN NO],
            GB.grndate AS [GRN DATE],
            GB.grnqty AS [GRN QTY],

            P.dtype AS [PO DTYPE]

        FROM PO_BASE P

        LEFT JOIN {tbl_cm} CM
            ON CONVERT(NVARCHAR(128), P.cid) = CONVERT(NVARCHAR(128), CM.Id)
           AND ISNULL(CM.Deleted, 0) = 0

        LEFT JOIN ITEM_MASTER M
            ON P.rmname = M.rmname

        LEFT JOIN GRN_BASE GB
            ON P.pono = GB.pono
           AND LTRIM(RTRIM(P.rmname)) = GB.rmname

        WHERE 1=1
          {supplier_where}
          {search_where}

        ORDER BY
            P.podate,
            P.pono,
            P.rmname;
        """

        params = []
        if apply_dtype:
            params.append(dtype_param)
        params.extend([str(start_date), str(end_date)])
        params.extend(supplier_params)
        params.extend(search_params)

        cursor.execute(query, params)
        rows = cursor.fetchall()

        rows_out = []
        for idx, r in enumerate(rows):
            sl_no = int(r[0]) if r[0] is not None else (idx + 1)
            pono = (r[1] or "").strip()
            podate = str(r[2])[:10] if r[2] else ""
            partno = (r[3] or "").strip()
            desc = (r[4] or "").strip()
            po_qty = float(r[5] or 0)
            uom = (r[6] or "").strip()
            category = (r[7] or "Other").strip()
            po_rate = float(r[8] or 0)
            amt = float(r[9] or 0)
            supplier = (r[10] or "").strip()
            group_name = (r[11] or "").strip() if r[11] else None
            mat_type = (r[12] or "RAW MATERIAL").strip()
            grn_no = (r[13] or "–").strip() if r[13] else "–"
            grn_date = str(r[14])[:10] if r[14] else "–"
            grn_qty = float(r[15]) if r[15] is not None else None
            po_dtype = (r[16] or ("Stores Material" if "STORE" in mat_type else "Raw Material")).strip()

            rows_out.append({
                "sl_no": sl_no,
                "id": f"{pono}_{partno}_{idx + 1}",
                "po_number": pono,
                "pono": pono,
                "po_date": podate,
                "podate": podate,
                "part_no": partno,
                "partno": partno,
                "material_code": partno,
                "description": desc,
                "material": desc,
                "po_qty": po_qty,
                "qty": po_qty,
                "uom": uom,
                "unit": uom,
                "category": category,
                "po_rate": po_rate,
                "rate": po_rate,
                "amt": amt,
                "value": amt,
                "amount": amt,
                "supplier": supplier,
                "vendor_name": supplier,
                "group_name": group_name,
                "material_type": mat_type,
                "po_type": po_dtype,
                "dtype": po_dtype,
                "grn_no": grn_no,
                "grn_date": grn_date,
                "grn_qty": grn_qty,
            })

        return Response({
            "company": tenant.get("company_name", ""),
            "from": str(start_date),
            "to": str(end_date),
            "count": len(rows_out),
            "rows": rows_out,
        })

    except Exception as e:
        logger.exception("purchase_analysis_average_purchase_value error")
        return Response({"error": str(e), "rows": []}, status=500)
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        try:
            conn.close()
        except Exception:
            pass


@api_view(["GET"])
@cache_analytics_response(timeout=300, key_prefix="pa")
def purchase_analysis_advanced_purchase_analytics(request):
    """
    Advanced Purchase Analytics:
    Executes the user's PO & Item Master query along with Commer_BaseRateDet
    to provide commercial base rates, chronological revisions, PO transactions,
    variances, and forecasting signals.
    """
    conn = None
    cursor = None
    try:
        conn, tenant = get_tenant_connection(request)
        cursor = conn.cursor()

        start_date, end_date = parse_date_range(request)

        dtype_param = (request.GET.get("dtype") or request.GET.get("po_type") or "").strip()
        apply_dtype = dtype_param and dtype_param.lower() != "all types"
        dtype_filter_sql = " AND UPPER(LTRIM(RTRIM(ISNULL(PM.dtype, '')))) = UPPER(?)" if apply_dtype else ""

        supplier_filter = (request.GET.get("supplier") or "").strip()
        supplier_where = ""
        supplier_params = []
        if supplier_filter and supplier_filter.lower() != "all suppliers":
            sups = [s.strip() for s in supplier_filter.split(",") if s.strip()]
            if sups:
                placeholders = ",".join(["?"] * len(sups))
                supplier_where = f" AND UPPER(LTRIM(RTRIM(ISNULL(CM.CName, '')))) IN ({placeholders}) "
                supplier_params.extend([s.upper() for s in sups])

        search_q = (request.GET.get("search") or request.GET.get("q") or "").strip()
        search_where = ""
        search_params = []
        if search_q:
            like_val = f"%{search_q}%"
            search_where = " AND (P.pono LIKE ? OR P.rmname LIKE ? OR CM.CName LIKE ? OR M.WMDescription LIKE ? OR M.RMDescription LIKE ? OR M.RPMDescription LIKE ?) "
            search_params = [like_val, like_val, like_val, like_val, like_val, like_val]

        _, _, q_m = resolve_erp_table(cursor, ["POMas", "pomas", "POMAS", "PoMas"])
        _, _, q_d = resolve_erp_table(cursor, ["PODet", "podet", "PODET", "PoDet", "In_PoDet"])
        _, _, q_wm = resolve_erp_table(cursor, ["WithMatMas", "withmatmas", "WITHMATMAS", "WithMat_Mas"])
        _, _, q_rm = resolve_erp_table(cursor, ["RawMast", "rawmast", "RAWMAST", "Raw_Mast"])
        _, _, q_rpm = resolve_erp_table(cursor, ["RawProdMast", "rawprodmast", "RAWPRODMAST", "RawProd_Mast"])
        _, _, q_cm = resolve_erp_table(cursor, ["CustMast", "custmast", "CUSTMAST", "CustMast"])
        _, _, q_commer = resolve_erp_table(cursor, ["Commer_BaseRateDet", "commer_baseratedet", "COMMER_BASERATEDET", "CommerBaseRateDet"])

        tbl_pomas = q_m or "[dbo].[POMas]"
        tbl_podet = q_d or "[dbo].[PODet]"
        tbl_withmat = q_wm or "[dbo].[WithMatMas]"
        tbl_rawmast = q_rm or "[dbo].[RawMast]"
        tbl_rawprod = q_rpm or "[dbo].[RawProdMast]"
        tbl_custmast = q_cm or "[dbo].[CustMast]"
        tbl_commer = q_commer or "[dbo].[Commer_BaseRateDet]"

        # 1. Query PO line items joined with Master Data (WithMatMas, RawMast, RawProdMast, CustMast)
        query_po = f"""
        ;WITH PO_BASE AS
        (
            SELECT
                PM.pono,
                PM.podate,
                PM.cid,
                PM.dtype,

                PD.rmname,
                PD.mattype,
                PD.qty,
                PD.QtyKgs,
                PD.QtyMtrsKgs,
                PD.rate,
                PD.uom,
                PD.amount,
                PD.deleted AS PODetDeleted

            FROM {tbl_pomas} PM

            INNER JOIN {tbl_podet} PD
                ON PM.pono = PD.pono
               AND ISNULL(PD.deleted, 0) = 0

            WHERE ISNULL(PM.deleted, 0) = 0
              AND UPPER(LTRIM(RTRIM(ISNULL(PM.dtype, '')))) <> 'JOB ORDER'
              {dtype_filter_sql}
              AND CAST(PM.podate AS DATE) >= ?
              AND CAST(PM.podate AS DATE) < DATEADD(DAY, 1, CAST(? AS DATE))
        ),

        ITEM_MASTER AS
        (
            SELECT
                P.rmname,

                /* WITH MATERIAL MASTER */
                WM.PartNo AS WMPartNo,
                WM.Description AS WMDescription,
                WM.Rod,
                WM.Casting,
                WM.uom AS WMUom,

                /* B.OUT MASTER */
                RM.Codeno AS RMCodeNo,
                RM.Description AS RMDescription,
                RM.SGroup AS RMGroup,
                RM.Uom AS RMUom,

                /* STORE MATERIAL MASTER */
                RPM.Codeno AS RPMCodeNo,
                RPM.Description AS RPMDescription,
                RPM.SGroup AS RPMGroup,
                RPM.Uom AS RPMUom

            FROM
            (
                SELECT DISTINCT rmname
                FROM PO_BASE
            ) P

            LEFT JOIN {tbl_withmat} WM
                ON LTRIM(RTRIM(P.rmname)) = LTRIM(RTRIM(WM.PartNo))
               AND ISNULL(WM.Deleted, 0) = 0

            LEFT JOIN {tbl_rawmast} RM
                ON LTRIM(RTRIM(P.rmname)) = LTRIM(RTRIM(RM.Codeno))
               AND ISNULL(RM.Deleted, 0) = 0

            LEFT JOIN {tbl_rawprod} RPM
                ON LTRIM(RTRIM(P.rmname)) = LTRIM(RTRIM(RPM.Codeno))
               AND ISNULL(RPM.Deleted, 0) = 0
        )

        SELECT
            ROW_NUMBER() OVER
            (
                ORDER BY
                    P.podate,
                    P.pono,
                    P.rmname
            ) AS [SL NO],

            P.pono AS [PONO],
            P.podate AS [PODATE],
            P.rmname AS [PARTNO],

            COALESCE
            (
                M.WMDescription,
                M.RMDescription,
                M.RPMDescription,
                P.rmname
            ) AS [DESCRIPTION],

            P.qty AS [PO QTY],
            P.uom AS [UOM],

            CASE
                WHEN M.WMPartNo IS NOT NULL AND ISNULL(M.Casting, 0) = 1
                    THEN 'Nos (Casting)'

                WHEN M.WMPartNo IS NOT NULL AND ISNULL(M.Rod, 0) = 1 AND
                     (UPPER(ISNULL(P.uom, '')) = 'KGS' OR UPPER(ISNULL(P.uom, '')) = 'KG')
                    THEN 'KGS (Rod)'

                WHEN M.WMPartNo IS NOT NULL AND ISNULL(M.Rod, 0) = 1 AND
                     (UPPER(ISNULL(P.uom, '')) = 'MTRS' OR UPPER(ISNULL(P.uom, '')) = 'MTR' OR UPPER(ISNULL(P.uom, '')) = 'M')
                    THEN 'Mtrs (Rod)'

                WHEN M.WMPartNo IS NOT NULL AND ISNULL(M.Rod, 0) = 1
                    THEN 'Rod'

                WHEN M.RMCodeNo IS NOT NULL
                    THEN 'B.Out'

                WHEN M.RPMCodeNo IS NOT NULL
                    THEN 'Store Material'

                ELSE 'Other'
            END AS [CATEGORY],

            P.rate AS [PO RATE],

            ISNULL
            (
                P.amount,
                ISNULL(P.qty, 0) * ISNULL(P.rate, 0)
            ) AS [AMT],

            CM.CName AS [SUPPLIER],

            CASE
                WHEN M.RPMCodeNo IS NOT NULL THEN M.RPMGroup
                WHEN M.RMCodeNo IS NOT NULL THEN M.RMGroup
                ELSE NULL
            END AS [GROUP NAME],

            CASE
                WHEN M.WMPartNo IS NOT NULL THEN 'RAW MATERIAL'
                WHEN M.RMCodeNo IS NOT NULL THEN 'B.OUT'
                WHEN M.RPMCodeNo IS NOT NULL THEN 'STORE MATERIAL'
                ELSE 'UNMAPPED'
            END AS [MATERIAL TYPE],

            P.dtype AS [PO DTYPE]

        FROM PO_BASE P

        LEFT JOIN {tbl_custmast} CM
            ON CONVERT(NVARCHAR(128), P.cid) = CONVERT(NVARCHAR(128), CM.Id)
           AND ISNULL(CM.Deleted, 0) = 0

        LEFT JOIN ITEM_MASTER M
            ON P.rmname = M.rmname

        WHERE 1=1
          {supplier_where}
          {search_where}

        ORDER BY
            P.podate,
            P.pono,
            P.rmname;
        """

        params_po = []
        if apply_dtype:
            params_po.append(dtype_param)
        params_po.extend([str(start_date), str(end_date)])
        params_po.extend(supplier_params)
        params_po.extend(search_params)

        cursor.execute(query_po, params_po)
        po_rows = cursor.fetchall()

        # 2. Query Commer_BaseRateDet for commercial rate changes
        query_commer = f"""
        SELECT
            LTRIM(RTRIM(cmno)) AS cmno,
            LTRIM(RTRIM(PartNo)) AS PartNo,
            ISNULL(BaseRate, 0) AS BaseRate,
            CONVERT(VARCHAR(10), BReffdt, 120) AS BReffdt,
            ISNULL(deleted, 0) AS deleted,
            ISNULL(SaleRate, 0) AS SaleRate,
            LTRIM(RTRIM(ISNULL(CurrPref, ''))) AS CurrPref,
            ISNULL(BRCurrRate, 0) AS BRCurrRate,
            ISNULL(NetRate, 0) AS NetRate
        FROM {tbl_commer}
        WHERE ISNULL(deleted, 0) = 0
        ORDER BY BReffdt ASC;
        """
        cursor.execute(query_commer)
        commer_rows = cursor.fetchall()

        # Map commercial rates by PartNo
        commercial_rates = {}
        for cr in commer_rows:
            cmno = (cr[0] or "").strip()
            part_no = (cr[1] or "").strip()
            base_rate = float(cr[2] or 0)
            eff_date = str(cr[3])[:10] if cr[3] else ""
            deleted_flag = bool(cr[4])
            sale_rate = float(cr[5] or 0)
            curr_pref = (cr[6] or "").strip()
            br_curr_rate = float(cr[7] or 0)
            net_rate = float(cr[8] or 0)

            if not part_no:
                continue

            item = {
                "cmno": cmno,
                "part_no": part_no,
                "base_rate": base_rate,
                "eff_date": eff_date,
                "effective_date": eff_date,
                "deleted": deleted_flag,
                "sale_rate": sale_rate,
                "curr_pref": curr_pref,
                "curr_rate": br_curr_rate,
                "net_rate": net_rate,
            }
            commercial_rates.setdefault(part_no, []).append(item)

        # Build clean PO rows out
        po_rows_out = []
        for idx, r in enumerate(po_rows):
            sl_no = int(r[0]) if r[0] is not None else (idx + 1)
            pono = (r[1] or "").strip()
            podate = str(r[2])[:10] if r[2] else ""
            partno = (r[3] or "").strip()
            desc = (r[4] or "").strip()
            po_qty = float(r[5] or 0)
            uom = (r[6] or "").strip()
            category = (r[7] or "Other").strip()
            po_rate = float(r[8] or 0)
            amt = float(r[9] or 0)
            supplier = (r[10] or "").strip()
            group_name = (r[11] or "").strip() if r[11] else None
            mat_type = (r[12] or "RAW MATERIAL").strip()
            po_dtype = (r[13] or ("Stores Material" if "STORE" in mat_type else "Raw Material")).strip()

            # Commercial rate info for this part
            part_commer = commercial_rates.get(partno, [])
            valid_base_rates = [c["base_rate"] for c in part_commer if c["base_rate"] > 0]
            comm_base_rate = valid_base_rates[0] if valid_base_rates else (part_commer[0]["base_rate"] if part_commer else po_rate)
            comm_latest_rate = valid_base_rates[-1] if valid_base_rates else comm_base_rate

            po_rows_out.append({
                "sl_no": sl_no,
                "id": f"{pono}_{partno}_{idx + 1}",
                "po_number": pono,
                "pono": pono,
                "po_date": podate,
                "podate": podate,
                "part_no": partno,
                "partno": partno,
                "material_code": partno,
                "description": desc,
                "material": desc,
                "po_qty": po_qty,
                "qty": po_qty,
                "uom": uom,
                "unit": uom,
                "category": category,
                "po_rate": po_rate,
                "rate": po_rate,
                "amt": amt,
                "value": amt,
                "amount": amt,
                "supplier": supplier,
                "vendor_name": supplier,
                "group_name": group_name,
                "material_type": mat_type,
                "po_type": po_dtype,
                "dtype": po_dtype,
                "commercial_base_rate": comm_base_rate,
                "commercial_latest_rate": comm_latest_rate,
                "commercial_revision_count": len(part_commer),
            })

        # Only send commercial rate revisions for the parts present in the filtered POs to keep payload compact
        filtered_commer_dict = {}
        distinct_parts = set(p["part_no"] for p in po_rows_out if p["part_no"])
        for pno in distinct_parts:
            if pno in commercial_rates:
                filtered_commer_dict[pno] = commercial_rates[pno]

        return Response({
            "company": tenant.get("company_name", ""),
            "from": str(start_date),
            "to": str(end_date),
            "count": len(po_rows_out),
            "po_rows": po_rows_out,
            "commercial_rates": filtered_commer_dict,
        })

    except Exception as e:
        logger.exception("purchase_analysis_advanced_purchase_analytics error")
        return Response({"error": str(e), "po_rows": [], "commercial_rates": {}}, status=500)
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        try:
            conn.close()
        except Exception:
            pass



